package dev.ages.gui;

import dev.ages.AgesPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/** Routes clicks to Menu actions, blocks item movement, and drives live refresh (timers) for open menus. */
public final class MenuListener implements Listener {
    public MenuListener(AgesPlugin plugin) {
        // one cheap task: only touches players who currently have a plugin menu open
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                InventoryHolder h = p.getOpenInventory().getTopInventory().getHolder(false);
                if (h instanceof Menu m && m.refresher != null) m.refresher.run();
            }
        }, 20L, 20L);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder(false) instanceof Menu m)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getRawSlot() < 0 || e.getRawSlot() >= m.size()) return;
        m.click(p, e.getRawSlot());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof Menu) e.setCancelled(true);
    }
}
