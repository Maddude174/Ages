package dev.ages.gui;

import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/** A chest GUI whose slots run actions. One generic holder serves every menu in the plugin (see MenuListener). */
public final class Menu implements InventoryHolder {
    private final Inventory inv;
    private final Map<Integer, Consumer<Player>> actions = new HashMap<>();
    Runnable refresher;

    public Menu(int size, String title) { this.inv = Bukkit.createInventory(this, size, Text.c(title)); }

    @Override public Inventory getInventory() { return inv; }

    public Menu set(int slot, ItemStack item, Consumer<Player> click) {
        if (slot < 0 || slot >= inv.getSize()) return this;
        inv.setItem(slot, item);
        if (click != null) actions.put(slot, click); else actions.remove(slot);
        return this;
    }

    public Menu set(int slot, ItemStack item) { return set(slot, item, null); }

    /** Called once a second while this menu is open (live timers). */
    public Menu onRefresh(Runnable r) { this.refresher = r; return this; }

    public int size() { return inv.getSize(); }

    public void open(Player p) { p.openInventory(inv); }

    void click(Player p, int slot) {
        Consumer<Player> a = actions.get(slot);
        if (a != null) a.accept(p);
    }
}
