package dev.ages.gui;

import dev.ages.AgesPlugin;
import dev.ages.config.*;
import dev.ages.hook.Eco;
import dev.ages.manager.Progress;
import dev.ages.model.*;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;
import java.util.function.Consumer;

/**
 * The /ages overview: civilization, age and advancement checklist, buildings, treasury and ledger, government, economy,
 * members and roles. Every control that cannot be used says why (missing permission, requirement, funds, limit, cooldown).
 */
public final class CivMenu {
    private final AgesPlugin plugin;

    public CivMenu(AgesPlugin plugin) { this.plugin = plugin; }

    private Registries reg() { return plugin.reg(); }

    public void open(Player p) {
        Town t = plugin.towns().of(p.getUniqueId());
        if (t == null) {
            Text.msg(p, "&7You do not belong to a civilization. Craft a founding core (see /ages help) and place it to start one,");
            Text.msg(p, "&7or ask a member to &e/ages invite&7 you.");
            return;
        }
        home(p, t);
    }

    // ------------------------------------------------------------------ helpers

    private String permBlocker(Town t, Player p, Perm perm) {
        if (t.can(p.getUniqueId(), perm)) return null;
        Rank r = t.rankOf(p.getUniqueId());
        return "Your role (" + (r == null ? "none" : r.title) + ") cannot: " + perm.description.toLowerCase() + ".";
    }

    private String name(UUID u) {
        if (u == null) return "nobody";
        String n = Bukkit.getOfflinePlayer(u).getName();
        return n == null ? "?" : n;
    }

    private ItemStack head(UUID u, String title, List<String> lore) {
        ItemStack it = Gui.item(Material.PLAYER_HEAD, title, lore);
        if (it.getItemMeta() instanceof SkullMeta sm) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(u);
            sm.setOwningPlayer(op);
            it.setItemMeta(sm);
        }
        return it;
    }

    private void back(Menu m, int slot, Player p, Town t) { m.set(slot, Gui.item(Material.ARROW, "&eBack to overview"), pl -> home(pl, t)); }

    private String effectLine(String k, double v) {
        String label = switch (k) {
            case "building_cost_mult" -> "Building costs";
            case "points_output_mult" -> "Resource point output";
            case "money_output_mult" -> "Treasury income";
            case "production_speed_mult" -> "Production speed";
            case "contribution_rate_mult" -> "Value of contributions";
            case "housing_mult" -> "Housing";
            case "claim_radius_add" -> "Border radius";
            case "withdraw_limit_add" -> "Daily withdrawal limit";
            default -> Text.pretty(k.replace('.', '_'));
        };
        boolean good = k.equals("building_cost_mult") ? v < 1 : k.endsWith("_mult") ? v > 1 : v > 0;
        String val = k.endsWith("_mult") ? (v >= 1 ? "+" : "") + Math.round((v - 1) * 100) + "%" : (v >= 0 ? "+" : "") + Text.num(v);
        return "  " + (good ? "&a" : "&c") + val + " &7" + label;
    }

    private List<String> effects(Map<String, Double> m) {
        List<String> out = new ArrayList<>();
        new TreeMap<>(m).forEach((k, v) -> out.add(effectLine(k, v)));
        return out;
    }

    // ------------------------------------------------------------------ home

    private void home(Player p, Town t) {
        Registries reg = reg();
        UUID u = p.getUniqueId();
        AgeDef age = reg.age(t.ageId);
        GovernmentDef gov = reg.government(t.govId);
        EconomyDef eco = reg.economy(t.econId);
        Menu m = new Menu(45, "&8" + t.name);

        List<String> ov = new ArrayList<>();
        ov.add("&7Age: &f" + Text.plain(age.name));
        ov.add("&7Government: &f" + Text.plain(gov.name));
        ov.add("&7" + gov.leaderTitle + ": &f" + name(t.leader) + "   &7Owner: &f" + name(t.owner));
        ov.add("&7Economy: &f" + Text.plain(eco.name));
        ov.add("&7Members: &f" + t.members.size() + "   &7Villagers: &f" + t.villagers + "   &7Housing: &f" + plugin.towns().housing(t));
        ov.add("&7Buildings: &f" + t.buildings.size() + "   &7Land: &f" + plugin.towns().claimedChunks(t) + " chunks");
        ov.add("&7Resource points: &f" + Text.num(t.points));
        if (t.can(u, Perm.VIEW_FINANCES)) ov.add("&7Treasury: &f" + Text.num(t.money));
        if (!t.policies.isEmpty()) {
            List<String> names = new ArrayList<>();
            for (String id : t.policies) { PolicyDef pd = reg.policy(id); names.add(pd == null ? id : Text.plain(pd.name)); }
            ov.add("&7Policies: &f" + String.join(", ", names));
        }
        Rank r = t.rankOf(u);
        ov.add("");
        ov.add("&7Your role: &f" + (r == null ? "none" : r.title) + (t.isOwner(u) ? " &8(technical owner)" : ""));
        m.set(4, Gui.item(Material.PAPER, "&6&l" + t.name, ov));

        // advancement summary
        AgeDef next = reg.nextAge(age);
        List<String> adv = new ArrayList<>();
        if (next == null) adv.add("&aYour civilization has reached the final age.");
        else {
            Progress.Node n = plugin.progress().eval(t, next.requirements);
            adv.add("&7Next: &f" + Text.plain(next.name) + (n.met() ? " &a(requirements met)" : ""));
            adv.addAll(plugin.progress().lines(n, 0));
        }
        m.set(10, Gui.item(Material.WRITABLE_BOOK, "&eAdvancement", adv), pl -> advancement(pl, t));
        m.set(11, Gui.item(Material.BRICKS, "&eBuildings", "&7" + t.buildings.size() + " buildings", "&7Status, timers, upgrades and relocation."), pl -> buildings(pl, t, 0));
        String shopWhy = permBlocker(t, p, Perm.USE_SHOP);
        m.set(12, Gui.item(Material.CHEST, "&eCatalogue", "&7Browse buildings and costs.",
                reg.settings.shopRemotePurchase ? "&7You can buy from here." : "&7To buy, right-click your core.", "", Gui.action(shopWhy, "Click to browse")),
                pl -> { if (shopWhy == null) plugin.shop().openMain(pl, t, true); });
        String finWhy = permBlocker(t, p, Perm.VIEW_FINANCES);
        m.set(13, Gui.item(Material.GOLD_INGOT, "&eTreasury & contributions", "&7Points: &f" + Text.num(t.points), finWhy == null ? "&7Treasury: &f" + Text.num(t.money) : "&8Treasury hidden", "", Gui.action(finWhy, "Click to open")),
                pl -> { if (finWhy == null) treasury(pl, t); else Text.msg(pl, "&c" + finWhy); });
        m.set(14, Gui.item(gov.icon, "&eGovernment", "&7" + Text.plain(gov.name), "&7" + gov.leaderTitle + ": &f" + name(t.leader)), pl -> government(pl, t));
        m.set(15, Gui.item(eco.icon, "&eEconomy", "&7" + Text.plain(eco.name), "&7Money " + (eco.moneyEnabled ? "&aenabled" : "&cdisabled")), pl -> economy(pl, t));
        m.set(16, Gui.item(Material.PLAYER_HEAD, "&eMembers & roles", "&7" + t.members.size() + " members"), pl -> members(pl, t));
        m.set(22, Gui.item(Material.HOPPER, "&eContribute", "&7Give materials or money to the civilization.", "&7Opens the treasury page."),
                pl -> { if (finWhy == null) treasury(pl, t); else Text.msg(pl, "&c" + finWhy); });

        String dis = permBlocker(t, p, Perm.DISBAND);
        m.set(40, Gui.item(Material.TNT, "&cDisband civilization", "&7Removes the civilization, its buildings' records,", "&7ledger and villagers. Blocks stay in the world.", "", Gui.action(dis, "Click to review")),
                pl -> { if (dis == null) confirmDisband(pl, t); });
        m.set(44, Gui.item(Material.BARRIER, "&cClose"), Player::closeInventory);
        m.open(p);
    }

    // ------------------------------------------------------------------ advancement

    private void advancement(Player p, Town t) {
        Registries reg = reg();
        AgeDef age = reg.age(t.ageId);
        AgeDef next = reg.nextAge(age);
        Menu m = new Menu(54, "&8Advancement");
        back(m, 49, p, t);
        if (next == null) {
            m.set(22, Gui.item(Material.NETHER_STAR, "&6Final age", "&7Nothing further to unlock."));
            m.open(p);
            return;
        }
        Progress.Node n = plugin.progress().eval(t, next.requirements);
        m.set(4, Gui.item(Material.ARROW, "&6" + Text.plain(age.name) + " &7-> &6" + Text.plain(next.name), n.met() ? "&aAll requirements met." : "&7Complete the checklist below."));

        List<String> list = new ArrayList<>(plugin.progress().lines(n, 0));
        m.set(20, Gui.item(n.met() ? Material.LIME_DYE : Material.RED_DYE, "&eRequirements", list));

        BuildingDef.Cost cost = plugin.finance().scaled(t, next.advanceCost);
        List<String> cl = new ArrayList<>();
        if (cost.isFree()) cl.add("&7Free");
        if (cost.points() > 0) cl.add((t.points >= cost.points() ? "&a✔ " : "&c✘ ") + "&f" + Text.num(cost.points()) + " &7resource points (shared: " + Text.num(t.points) + ")");
        if (cost.money() > 0) cl.add((t.money >= cost.money() ? "&a✔ " : "&c✘ ") + "&f" + Text.num(cost.money()) + " &7treasury money (shared: " + Text.num(t.money) + ")");
        cost.items().forEach((mat, c) -> cl.add((dev.ages.util.InvUtil.countPlain(p.getInventory(), mat) >= c ? "&a✔ " : "&c✘ ") + "&f" + c + "x " + Text.pretty(mat) + " &7(from your inventory)"));
        cl.add("");
        double mult = plugin.governance().effects(t).mult("building_cost_mult");
        if (mult != 1.0) cl.add("&8Includes your cost modifier (x" + Text.num(Math.round(mult * 100) / 100.0) + ").");
        m.set(22, Gui.item(Material.GOLD_INGOT, "&eAdvancement cost", cl));

        BuildingDef core = reg.buildings.get(next.coreBuilding);
        List<String> kl = new ArrayList<>();
        if (core != null) {
            kl.add("&7Buy this core, build it, then place it.");
            if (!next.retire.isEmpty()) {
                List<String> names = new ArrayList<>();
                for (String r : next.retire) { BuildingDef rd = reg.building(r); names.add(rd == null ? r : Text.plain(rd.name)); }
                kl.add("&7Phased out when you enter: &f" + String.join(", ", names));
            }
            kl.add("&8The old core stays until the new one is placed and validated.");
            kl.add("");
            kl.add(Gui.action(plugin.buildings().purchaseBlocker(p, t, core), "Open the catalogue"));
        }
        m.set(24, Gui.item(core == null ? Material.BARRIER : core.icon, "&eNext core: " + (core == null ? "?" : core.name), kl),
                pl -> plugin.shop().openMain(pl, t, true));
        m.open(p);
    }

    // ------------------------------------------------------------------ buildings

    private void buildings(Player p, Town t, int page) {
        List<PlacedBuilding> list = new ArrayList<>(t.buildings);
        Registries reg = reg();
        list.sort(Comparator.comparing((PlacedBuilding b) -> { BuildingDef d = reg.building(b.defId); return d == null ? b.defId : d.category; })
                .thenComparing(b -> { BuildingDef d = reg.building(b.defId); return d == null ? b.defId : Text.plain(d.name); }));
        int per = 45;
        int pages = Math.max(1, (list.size() + per - 1) / per);
        int pg = Math.max(0, Math.min(page, pages - 1));
        Menu m = new Menu(54, "&8Buildings (" + (pg + 1) + "/" + pages + ")");
        for (int i = 0; i < per && pg * per + i < list.size(); i++) {
            PlacedBuilding pb = list.get(pg * per + i);
            m.set(i, buildingItem(pb), pl -> plugin.buildingMenu().open(pl, t, pb));
        }
        m.onRefresh(() -> {
            for (int i = 0; i < per && pg * per + i < list.size(); i++) m.set(i, buildingItem(list.get(pg * per + i)), null);
        });
        back(m, 49, p, t);
        if (pg > 0) m.set(48, Gui.item(Material.SPECTRAL_ARROW, "&ePrevious page"), pl -> buildings(pl, t, pg - 1));
        if (pg < pages - 1) m.set(50, Gui.item(Material.SPECTRAL_ARROW, "&eNext page"), pl -> buildings(pl, t, pg + 1));
        m.open(p);
    }

    private ItemStack buildingItem(PlacedBuilding pb) {
        BuildingDef d = reg().effective(pb);
        if (d == null) return Gui.item(Material.BARRIER, "&c" + pb.defId, "&7Definition missing from the configuration.");
        List<String> lore = new ArrayList<>();
        lore.add("&7Owner: &f" + name(pb.owner) + "   &7Level: &f" + pb.level);
        lore.add("&7Location: &f" + pb.core.x() + ", " + pb.core.y() + ", " + pb.core.z());
        if (pb.damaged) lore.add("&cDamaged: production paused");
        else if (d.function != null && pb.nextRun > 0) {
            long left = pb.nextRun - System.currentTimeMillis();
            lore.add("&6Next production: &f" + (left <= 0 ? "due now" : "in " + Text.remaining(left)));
            if (!pb.lastStatus.isEmpty() && !pb.lastStatus.equals("Running")) lore.add("&e" + pb.lastStatus);
        } else lore.add("&aWorking");
        lore.add("");
        lore.add("&a> Click for details");
        return Gui.item(d.icon, d.name, lore);
    }

    // ------------------------------------------------------------------ treasury

    private void treasury(Player p, Town t) {
        UUID u = p.getUniqueId();
        EconomyDef econ = reg().economy(t.econId);
        Eco eco = plugin.eco();
        Menu m = new Menu(54, "&8Treasury & contributions");
        back(m, 49, p, t);

        double limit = plugin.finance().withdrawLimit(t);
        List<String> sum = new ArrayList<>();
        sum.add("&7Resource points: &f" + Text.num(t.points));
        sum.add("&7Treasury money: &f" + Text.num(t.money) + (econ.moneyEnabled ? "" : " &8(economy has no money)"));
        sum.add("&7Your personal funds: &f" + (eco == null ? "n/a (no Vault)" : eco.fmt(eco.has(p, 0) ? balance(p, eco) : 0)));
        if (limit > 0) sum.add("&7Daily withdrawal limit: &f" + Text.num(limit) + " &7(you used " + Text.num(plugin.finance().withdrawnLast24h(t, u)) + ")");
        m.set(4, Gui.item(Material.GOLD_BLOCK, "&6Finances", sum));

        String cWhy = permBlocker(t, p, Perm.CONTRIBUTE);
        m.set(10, Gui.item(Material.OAK_LOG, "&eContribute held item",
                "&7Converts the stack in your hand to resource points", "&7at the rates in settings.yml.", "", Gui.action(cWhy, "Click")), pl -> act(pl, t, plugin.finance().contributeItems(pl, t, false)));
        m.set(11, Gui.item(Material.CHEST_MINECART, "&eContribute all accepted items",
                "&7Every accepted plain item in your inventory.", "", Gui.action(cWhy, "Click")), pl -> act(pl, t, plugin.finance().contributeItems(pl, t, true)));
        String mWhy = cWhy != null ? cWhy : !econ.moneyEnabled || !econ.contributionMoney ? "Your economic system does not accept money contributions." : eco == null ? "No economy plugin (Vault)." : null;
        for (int i = 0; i < 2; i++) {
            double amt = i == 0 ? 100 : 1000;
            m.set(12 + i, Gui.item(Material.EMERALD, "&eContribute " + Text.num(amt) + " money", "&7From your personal funds to the treasury.", "", Gui.action(mWhy, "Click")),
                    pl -> act(pl, t, plugin.finance().contributeMoney(pl, t, amt)));
        }
        String vWhy = permBlocker(t, p, Perm.SPEND_TREASURY);
        if (vWhy == null && econ.exchangeRate <= 0) vWhy = "Your economic system does not convert money to points.";
        m.set(14, Gui.item(Material.EXPERIENCE_BOTTLE, "&eConvert 100 money -> points",
                "&7Rate: &f" + (econ.exchangeRate > 0 ? "x" + Text.num(econ.exchangeRate) : "n/a"), "", Gui.action(vWhy, "Click")), pl -> act(pl, t, plugin.finance().convert(pl, t, 100)));
        String wWhy = permBlocker(t, p, Perm.WITHDRAW_TREASURY);
        if (wWhy == null && limit <= 0) wWhy = "Your economic system does not allow withdrawals.";
        if (wWhy == null && eco == null) wWhy = "No economy plugin (Vault).";
        for (int i = 0; i < 2; i++) {
            double amt = i == 0 ? 100 : 1000;
            m.set(15 + i, Gui.item(Material.GOLD_NUGGET, "&eWithdraw " + Text.num(amt), "&7Treasury -> your personal funds.", "&7Recorded in the ledger.", "", Gui.action(wWhy, "Click")),
                    pl -> act(pl, t, plugin.finance().withdraw(pl, t, amt)));
        }

        // ledger
        List<String> led = new ArrayList<>();
        long now = System.currentTimeMillis();
        int n = 0;
        for (Tx x : t.ledger) {
            if (n++ >= 16) break;
            String who = x.actor == null ? "Civilization" : name(x.actor);
            led.add("&8" + Text.remaining(now - x.ts) + " ago &7" + who + " &f" + x.type.toLowerCase().replace('_', ' ') + " "
                    + (x.amount >= 0 ? "&a+" : "&c") + Text.num(x.amount) + (x.currency.equals("POINTS") ? " pts" : " $") + " &8" + x.note);
        }
        if (led.isEmpty()) led.add("&7No transactions yet.");
        m.set(28, Gui.item(Material.BOOK, "&eLedger (latest)", led));

        List<Map.Entry<UUID, double[]>> top = new ArrayList<>(t.contributions.entrySet());
        top.sort((a, b) -> Double.compare(b.getValue()[0] + b.getValue()[1], a.getValue()[0] + a.getValue()[1]));
        List<String> tl = new ArrayList<>();
        for (int i = 0; i < Math.min(8, top.size()); i++)
            tl.add("&7" + (i + 1) + ". &f" + name(top.get(i).getKey()) + " &8- &f" + Text.num(top.get(i).getValue()[0]) + " pts, " + Text.num(top.get(i).getValue()[1]) + " money");
        if (tl.isEmpty()) tl.add("&7No contributions yet.");
        tl.add("");
        tl.add("&8Contributing does not grant political authority.");
        m.set(30, Gui.item(Material.PLAYER_HEAD, "&eTop contributors", tl));
        m.set(32, Gui.item(Material.PAPER, "&eAccepted materials", acceptedLines()));
        m.open(p);
    }

    private double balance(Player p, Eco eco) {
        double lo = 0, hi = 1;           // Eco has no balance getter: probe with has() to stay Vault-agnostic
        while (eco.has(p, hi) && hi < 1e12) hi *= 2;
        for (int i = 0; i < 30; i++) { double mid = (lo + hi) / 2; if (eco.has(p, mid)) lo = mid; else hi = mid; }
        return Math.floor(lo * 100) / 100;
    }

    private List<String> acceptedLines() {
        List<String> out = new ArrayList<>();
        out.add("&7Resource points per item:");
        int n = 0;
        for (var e : reg().settings.contributionValues.entrySet()) {
            if (n++ >= 14) { out.add("&8... and more (settings.yml)"); break; }
            out.add("  &f" + Text.pretty(e.getKey()) + " &7= " + Text.num(e.getValue()));
        }
        if (reg().settings.contributionValues.isEmpty()) out.add("  &8none configured");
        return out;
    }

    private void act(Player p, Town t, String message) {
        Text.msg(p, message);
        if (plugin.towns().byId(t.id) != null) treasury(p, t);
    }

    // ------------------------------------------------------------------ government

    private void government(Player p, Town t) {
        Registries reg = reg();
        GovernmentDef gov = reg.government(t.govId);
        Menu m = new Menu(54, "&8Government");
        back(m, 49, p, t);

        List<String> info = new ArrayList<>();
        info.addAll(gov.description.stream().map(s -> "&7" + s).toList());
        info.add("");
        info.add("&7" + gov.leaderTitle + ": &f" + name(t.leader) + "   &7Owner: &f" + name(t.owner));
        info.add("&7Leader chosen by: &f" + (gov.leaderSelection.equals("elected") ? "election" : gov.leaderSelection.equals("owner") ? "the technical owner" : "appointment"));
        info.add("&8The owner (technical) and the leader (political) are separate seats.");
        if (!gov.modifiers.isEmpty()) { info.add(""); info.add("&6Effects:"); info.addAll(effects(gov.modifiers)); }
        m.set(4, Gui.item(gov.icon, gov.name, info));

        if (gov.leaderSelection.equals("elected")) {
            String why = permBlocker(t, p, Perm.VOTE);
            m.set(2, Gui.item(Material.PAPER, "&eVote for the " + gov.leaderTitle, "&7Current votes decide the leader; ties keep the sitting one.", "", Gui.action(why, "Click to choose a candidate")),
                    pl -> { if (why == null) pickMember(pl, t, "Vote for the " + gov.leaderTitle, id -> { String e = plugin.governance().vote(pl, t, id); Text.msg(pl, e == null ? "&aVote recorded." : "&c" + e); government(pl, t); }, () -> government(pl, t)); });
        } else if (gov.leaderSelection.equals("appointed")) {
            String why = permBlocker(t, p, Perm.APPOINT_OFFICIALS);
            m.set(2, Gui.item(Material.GOLDEN_HELMET, "&eAppoint the " + gov.leaderTitle, "&7Choose who leads the civilization.", "", Gui.action(why, "Click to choose")),
                    pl -> { if (why == null) pickMember(pl, t, "Appoint the " + gov.leaderTitle, id -> { String e = plugin.governance().appointLeader(pl, t, id); Text.msg(pl, e == null ? "&aAppointed." : "&c" + e); government(pl, t); }, () -> government(pl, t)); });
        }

        policyRow(m, p, t, "government", 19);

        // other governments
        int slot = 37;
        for (GovernmentDef g : reg.governments.values()) {
            if (slot > 43) break;
            String why = plugin.governance().govBlocker(p, t, g);
            List<String> gl = new ArrayList<>();
            gl.addAll(g.description.stream().map(s -> "&7" + s).toList());
            gl.add("");
            if (!g.modifiers.isEmpty()) { gl.add("&6Effects:"); gl.addAll(effects(g.modifiers)); }
            gl.add("&7Change cost: &f" + Describe.cost(g.changeCost));
            gl.add("&7Roles: &f" + String.join(", ", g.roles.values().stream().map(r -> r.title).toList()));
            gl.add("");
            gl.add(g.id.equals(t.govId) ? "&a✔ Current government" : Gui.action(why, "Click to switch (roles are replaced)"));
            m.set(slot++, Gui.item(g.icon, (g.id.equals(t.govId) ? "&a" : "&e") + Text.plain(g.name), gl), pl -> {
                String e = plugin.governance().changeGovernment(pl, t, g);
                Text.msg(pl, e == null ? "&aThe civilization is now a " + Text.plain(g.name) + "&a." : "&c" + e);
                government(pl, t);
            });
        }
        m.open(p);
    }

    private void policyRow(Menu m, Player p, Town t, String kind, int startSlot) {
        Registries reg = reg();
        List<PolicyDef> offered = new ArrayList<>();
        for (PolicyDef pd : reg.policies.values()) if (pd.kind.equals(kind) && plugin.governance().offered(t, pd)) offered.add(pd);
        long active = plugin.governance().active(t, kind);
        int slots = plugin.governance().slots(t, kind);
        m.set(startSlot - 1 > 0 ? startSlot - 1 : 18, Gui.item(Material.BOOKSHELF, "&6Policies (" + active + "/" + slots + " slots)", "&7Policies add modifiers while adopted.", "&7Click one to adopt or revoke it."));
        int slot = startSlot;
        for (PolicyDef pd : offered) {
            if (slot > startSlot + 15) break;
            boolean on = t.policies.contains(pd.id);
            String why = plugin.governance().policyBlocker(p, t, pd);
            List<String> l = new ArrayList<>();
            l.addAll(pd.description.stream().map(s -> "&7" + s).toList());
            l.add("");
            l.addAll(effects(pd.effects));
            l.add("&7Adoption cost: &f" + Describe.cost(pd.cost));
            l.add("");
            l.add(on ? "&a✔ ACTIVE &7- " + Gui.action(why, "click to revoke") : Gui.action(why, "Click to adopt"));
            m.set(slot++, Gui.item(pd.icon, (on ? "&a" : "&e") + Text.plain(pd.name), l), pl -> {
                String e = plugin.governance().togglePolicy(pl, t, pd);
                if (e != null) Text.msg(pl, "&c" + e);
                if (kind.equals("government")) government(pl, t); else economy(pl, t);
            });
            if ((slot - startSlot) == 7) slot = startSlot + 9;
        }
        if (offered.isEmpty()) m.set(startSlot, Gui.item(Material.BARRIER, "&7No policies offered", "&8This " + kind + " has no policies."));
    }

    // ------------------------------------------------------------------ economy

    private void economy(Player p, Town t) {
        Registries reg = reg();
        EconomyDef econ = reg.economy(t.econId);
        Menu m = new Menu(54, "&8Economy");
        back(m, 49, p, t);
        List<String> info = new ArrayList<>();
        info.addAll(econ.description.stream().map(s -> "&7" + s).toList());
        info.add("");
        info.add("&7Money: " + (econ.moneyEnabled ? "&aenabled" : "&cdisabled &7(money income becomes points at x" + Text.num(econ.moneyToPoints) + ")"));
        info.add("&7Money contributions: " + (econ.contributionMoney ? "&aaccepted" : "&cnot accepted"));
        info.add("&7Money -> points exchange: &f" + (econ.exchangeRate > 0 ? "x" + Text.num(econ.exchangeRate) : "not allowed"));
        info.add("&7Treasury withdrawals: &f" + (econ.withdrawLimit > 0 ? "up to " + Text.num(econ.withdrawLimit) + "/day" : "not allowed"));
        if (!econ.modifiers.isEmpty()) { info.add(""); info.add("&6Effects:"); info.addAll(effects(econ.modifiers)); }
        m.set(4, Gui.item(econ.icon, econ.name, info));

        policyRow(m, p, t, "economy", 19);

        int slot = 37;
        for (EconomyDef e : reg.economies.values()) {
            if (slot > 43) break;
            String why = plugin.governance().econBlocker(p, t, e);
            List<String> el = new ArrayList<>();
            el.addAll(e.description.stream().map(s -> "&7" + s).toList());
            el.add("");
            if (!e.modifiers.isEmpty()) { el.add("&6Effects:"); el.addAll(effects(e.modifiers)); }
            el.add("&7Money: " + (e.moneyEnabled ? "&aenabled" : "&cdisabled"));
            el.add("&7Change cost: &f" + Describe.cost(e.changeCost));
            el.add("");
            el.add(e.id.equals(t.econId) ? "&a✔ Current system" : Gui.action(why, "Click to switch"));
            m.set(slot++, Gui.item(e.icon, (e.id.equals(t.econId) ? "&a" : "&e") + Text.plain(e.name), el), pl -> {
                String err = plugin.governance().changeEconomy(pl, t, e);
                Text.msg(pl, err == null ? "&aThe economy is now " + Text.plain(e.name) + "&a." : "&c" + err);
                economy(pl, t);
            });
        }
        m.open(p);
    }

    // ------------------------------------------------------------------ members & roles

    private void members(Player p, Town t) {
        UUID me = p.getUniqueId();
        Menu m = new Menu(54, "&8Members & roles");
        back(m, 49, p, t);
        GovernmentDef gov = reg().government(t.govId);
        int i = 0;
        List<Map.Entry<UUID, String>> list = new ArrayList<>(t.members.entrySet());
        list.sort((a, b) -> Integer.compare(t.weightOf(b.getKey()), t.weightOf(a.getKey())));
        String why = permBlocker(t, p, Perm.APPOINT_OFFICIALS);
        for (Map.Entry<UUID, String> e : list) {
            if (i >= 45) break;
            Rank r = t.ranks.get(e.getValue());
            List<String> l = new ArrayList<>();
            l.add("&7Role: &f" + (r == null ? e.getValue() : r.title));
            if (e.getKey().equals(t.leader)) l.add("&6" + gov.leaderTitle);
            if (e.getKey().equals(t.owner)) l.add("&bTechnical owner");
            double[] c = t.contributions.get(e.getKey());
            if (c != null) l.add("&7Contributed: &f" + Text.num(c[0]) + " pts, " + Text.num(c[1]) + " money");
            l.add("");
            l.add(Gui.action(why, "Click to change role"));
            UUID target = e.getKey();
            m.set(i++, head(target, "&f" + name(target), l), pl -> { if (why == null) assignRole(pl, t, target); });
        }
        m.set(51, Gui.item(Material.WRITABLE_BOOK, "&eRoles & permissions", "&7What each role may do."), pl -> roles(pl, t));
        m.open(p);
    }

    private void assignRole(Player p, Town t, UUID target) {
        UUID me = p.getUniqueId();
        GovernmentDef gov = reg().government(t.govId);
        Menu m = new Menu(27, "&8Role for " + name(target));
        int slot = 0;
        for (Rank r : t.ranks.values()) {
            String why = null;
            if (t.weightOf(me) <= t.weightOf(target) && !me.equals(target)) why = "You can only change members ranked below you.";
            else if (r.weight >= t.weightOf(me)) why = "You can only grant roles below your own.";
            else if (r.name.equals(gov.leaderRole)) why = "The " + gov.leaderTitle + " role is set through the government's leadership rules.";
            else if (target.equals(t.leader)) why = "Change the " + gov.leaderTitle + " first.";
            String fw = why;
            m.set(slot++, Gui.item(r.name.equals(t.members.get(target)) ? Material.LIME_DYE : Material.PAPER, "&e" + r.title, "&7Weight: &f" + r.weight, "", fw == null ? "&a> Click to assign" : "&c✘ " + fw),
                    pl -> {
                        if (fw != null) return;
                        t.members.put(target, r.name);
                        plugin.towns().save(t);
                        Text.msg(pl, "&a" + name(target) + " is now " + r.title + ".");
                        members(pl, t);
                    });
        }
        m.set(22, Gui.item(Material.ARROW, "&eBack"), pl -> members(pl, t));
        m.open(p);
    }

    private void roles(Player p, Town t) {
        Menu m = new Menu(54, "&8Roles & permissions");
        m.set(49, Gui.item(Material.ARROW, "&eBack"), pl -> members(pl, t));
        int slot = 0;
        String mine = t.members.get(p.getUniqueId());
        for (Rank r : t.ranks.values().stream().sorted((a, b) -> Integer.compare(b.weight, a.weight)).toList()) {
            if (slot >= 45) break;
            List<String> l = new ArrayList<>();
            l.add("&7Weight: &f" + r.weight + (r.name.equals(mine) ? "   &a(your role)" : ""));
            long holders = t.members.values().stream().filter(x -> x.equals(r.name)).count();
            l.add("&7Members: &f" + holders);
            l.add("");
            for (Perm perm : Perm.values()) l.add((r.perms.contains(perm) ? "&a✔ " : "&8✘ ") + (r.perms.contains(perm) ? "&7" : "&8") + perm.description);
            m.set(slot++, Gui.item(r.name.equals(mine) ? Material.GOLDEN_HELMET : Material.IRON_HELMET, "&e" + r.title, l));
        }
        m.open(p);
    }

    private void pickMember(Player p, Town t, String title, Consumer<UUID> action, Runnable back) {
        Menu m = new Menu(54, "&8" + title);
        int i = 0;
        for (UUID u : t.members.keySet()) {
            if (i >= 45) break;
            m.set(i++, head(u, "&f" + name(u), List.of("&a> Click to choose")), pl -> action.accept(u));
        }
        m.set(49, Gui.item(Material.ARROW, "&eBack"), pl -> back.run());
        m.open(p);
    }

    // ------------------------------------------------------------------ disband

    private void confirmDisband(Player p, Town t) {
        Menu m = new Menu(27, "&4Disband " + t.name + "?");
        m.set(11, Gui.item(Material.RED_CONCRETE, "&cYes, disband " + t.name,
                "&7This cannot be undone.", "&7Removes buildings' records, the ledger", "&7and all spawned villagers.", "&7Blocks stay in the world."), pl -> {
            String err = plugin.towns().disbandBy(pl, t);
            pl.closeInventory();
            if (err != null) Text.msg(pl, "&c" + err);
        });
        m.set(15, Gui.item(Material.LIME_CONCRETE, "&aNo, keep it"), pl -> home(pl, t));
        m.open(p);
    }
}
