package dev.ages.gui;

import dev.ages.config.BuildingDef;
import dev.ages.config.BuildingDef.Entry;
import dev.ages.config.BuildingDef.Kind;
import dev.ages.config.BuildingDef.Recipe;
import dev.ages.util.Text;
import org.bukkit.Material;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/** Turns building config into human-readable lore lines. */
public final class Describe {
    private Describe() {}

    public static String cost(BuildingDef.Cost c) {
        if (c.isFree()) return "Free";
        List<String> parts = new ArrayList<>();
        if (c.points() > 0) parts.add(Text.num(c.points()) + " resource points");
        if (c.money() > 0) parts.add(Text.num(c.money()) + " treasury money");
        c.items().forEach((m, n) -> parts.add(n + "x " + Text.pretty(m)));
        return String.join(", ", parts);
    }

    private static String names(Set<Material> set) {
        List<String> n = set.stream().limit(3).map(Text::pretty).collect(Collectors.toList());
        return String.join("/", n) + (set.size() > 3 ? "/..." : "");
    }

    public static String ingredient(BuildingDef.Ingredient i) {
        return i.durability() > 0 ? names(i.anyOf()) + " (-" + i.durability() + " durability)" : i.amount() + "x " + names(i.anyOf());
    }

    private static String num(double v) { return Text.num(v); }

    /** One output entry, with its probability when it is random. */
    public static String entry(Entry e, double totalWeight, boolean pickOne) {
        String what = switch (e.kind()) {
            case ITEM -> (e.min() == e.max() ? num(e.min()) : num(e.min()) + "-" + num(e.max())) + "x " + Text.pretty(e.item());
            case POINTS -> "+" + (e.min() == e.max() ? num(e.min()) : num(e.min()) + "-" + num(e.max())) + " points";
            case MONEY -> "+" + (e.min() == e.max() ? num(e.min()) : num(e.min()) + "-" + num(e.max())) + " money";
            case AIR -> "nothing";
        };
        double pct = pickOne ? (totalWeight <= 0 ? 100 : e.weight() / totalWeight * 100) : e.chance() * 100;
        return pct >= 99.95 ? what : what + " " + Text.num(Math.round(pct * 10) / 10.0) + "%";
    }

    public static String outputs(Recipe r) {
        double total = 0;
        for (Entry e : r.entries()) total += e.weight();
        final double t = total;
        return r.entries().stream().map(e -> entry(e, t, r.pickOne())).limit(6).collect(Collectors.joining(r.pickOne() ? " | " : ", "))
                + (r.entries().size() > 6 ? " ..." : "");
    }

    public static String recipeLabel(Recipe r) {
        if (r.name() != null) return r.name();
        return Text.pretty(r.id());
    }

    public static String recipeLine(Recipe r) {
        String in = r.consume().isEmpty() ? "nothing" : r.consume().stream().map(Describe::ingredient).collect(Collectors.joining(" + "));
        return "&f" + in + " &7-> &a" + outputs(r);
    }

    public static List<String> function(BuildingDef d) {
        List<String> out = new ArrayList<>();
        var f = d.function;
        if (f != null) {
            String every = "&8Every " + Text.duration(f.interval) + ":";
            if (!f.always.isEmpty()) {
                Recipe fake = new Recipe("always", null, null, List.of(), false, f.always);
                out.add(every + " &a" + outputs(fake));
                every = "&8Plus, every " + Text.duration(f.interval) + ":";
            }
            switch (f.type) {
                case "processor" -> {
                    if (!f.recipes.isEmpty()) {
                        out.add(every + (f.mode.equals("selected") ? " &7(pick a recipe in the building menu)" : f.mode.equals("all") ? " &7(all recipes)" : ""));
                        int shown = 0;
                        for (Recipe r : f.recipes) {
                            if (shown++ == 4) { out.add("  &8+" + (f.recipes.size() - 4) + " more recipes"); break; }
                            out.add("  " + recipeLine(r));
                        }
                    }
                }
                case "spawner" -> out.add("&7Spawns " + Text.pretty(f.entity.name()) + " (max " + f.cap + ")" + (f.housingLimited ? ", limited by housing" : "") + " every " + Text.duration(f.interval));
                case "tax" -> out.add("&7Collects &f" + f.perResident + " &7per resident every " + Text.duration(f.interval));
                case "sell" -> out.add("&7Sells goods from its input container for money");
                default -> { }
            }
        }
        for (var e : d.provides.entrySet()) {
            double v = e.getValue();
            switch (e.getKey()) {
                case "housing" -> out.add("&7Housing: &f+" + (int) v);
                case "respawn_point" -> out.add("&7Respawn point for members");
                case "claim_bonus" -> out.add("&7Border radius: &f+" + (int) v);
                case "storage" -> out.add("&7Logistics hub / shared storage");
                case "production_speed" -> out.add("&7Production speed: &f+" + Math.round(v * 100) + "% civilization-wide");
                case "withdraw_limit" -> out.add("&7Daily treasury withdrawal limit: &f+" + (int) v);
                case "logistics_capacity" -> out.add("&7Rail throughput: &f+" + (int) v + " items per run");
                default -> out.add("&7" + Text.pretty(e.getKey()) + ": &f" + Text.num(v));
            }
        }
        return out;
    }

    /** Requirements a level adds or raises compared with the previous level, as "Nx Label". */
    public static List<String> newRequirements(BuildingDef cur, BuildingDef next) {
        List<String> out = new ArrayList<>();
        for (BuildingDef.Req r : next.requirements) {
            int had = 0;
            for (BuildingDef.Req c : cur.requirements) if (c.label().equals(r.label())) had = c.min();
            if (r.min() > had) out.add(r.min() + "x " + Text.pretty(r.label()));
        }
        return out;
    }
}
