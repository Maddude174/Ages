package dev.ages.gui;

import dev.ages.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Item building helpers shared by all menus. Lore strings use '&' colour codes. */
public final class Gui {
    private Gui() {}

    public static ItemStack item(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Text.c(name));
        if (lore != null && !lore.isEmpty()) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(Text.c(s));
            meta.lore(l);
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        it.setItemMeta(meta);
        return it;
    }

    public static ItemStack item(Material m, String name, String... lore) { return item(m, name, List.of(lore)); }

    public static ItemStack filler() { return item(Material.GRAY_STAINED_GLASS_PANE, " ", List.of()); }

    /** First line to show on a button: green "click" prompt, or the red reason it cannot be used. */
    public static String action(String blocker, String prompt) { return blocker == null ? "&a> " + prompt : "&c✘ " + blocker; }
}
