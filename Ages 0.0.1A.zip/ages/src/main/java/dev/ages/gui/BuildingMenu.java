package dev.ages.gui;

import dev.ages.AgesPlugin;
import dev.ages.building.Scanner;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.config.BuildingDef.Recipe;
import dev.ages.hook.Eco;
import dev.ages.model.Perm;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Town;
import dev.ages.util.Containers;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * A building's core interface: status, production timer (live), recipe choice, upgrade, storage access, income and relocation.
 * Opened by right-clicking the core, or from the /ages building list.
 */
public final class BuildingMenu {
    private final AgesPlugin plugin;

    public BuildingMenu(AgesPlugin plugin) { this.plugin = plugin; }

    public void open(Player p, Town t, PlacedBuilding pb) { open(p, t, pb, false); }

    private void open(Player p, Town t, PlacedBuilding pb, boolean confirmRemove) {
        BuildingDef base = plugin.reg().building(pb.defId);
        if (base == null) { Text.msg(p, "&cThis building's definition no longer exists in the configuration."); return; }
        BuildingDef cur = base.at(pb.level);
        UUID uid = p.getUniqueId();
        boolean mine = pb.owner.equals(uid) || t.can(uid, Perm.MANAGE_BUILDINGS);

        List<String> problems = List.of();
        if (pb.damaged && mine) {
            Scanner.Result r = plugin.buildings().revalidate(pb, false); // opening a damaged building retries the repair
            if (r != null) problems = r.problems();
        }
        final List<String> damageProblems = problems;

        Menu m = new Menu(27, "&8" + Text.plain(cur.name));
        m.set(10, info(t, pb, cur, base, damageProblems));
        m.onRefresh(() -> m.set(10, info(t, pb, cur, base, damageProblems)));   // live countdown

        // ---- recipes
        var f = cur.function;
        if (f != null && f.type.equals("processor") && !f.recipes.isEmpty()) {
            List<String> lore = new ArrayList<>();
            lore.add(f.mode.equals("selected") ? "&7Active recipe is highlighted." : "&7Mode: &f" + f.mode);
            String active = activeRecipe(f.recipes, pb);
            for (Recipe r : f.recipes) {
                boolean on = f.mode.equals("selected") ? r.id().equals(active) : true;
                lore.add((on ? "&a> " : "&8  ") + "&f" + Describe.recipeLabel(r));
                lore.add("    " + Describe.recipeLine(r));
            }
            if (f.mode.equals("selected")) {
                String why = mine ? null : "Only the owner or a manager can change the recipe.";
                lore.add("");
                lore.add(Gui.action(why, "Click to switch to the next recipe"));
                m.set(11, Gui.item(Material.WRITABLE_BOOK, "&eRecipes", lore), pl -> {
                    int i = 0;
                    for (int k = 0; k < f.recipes.size(); k++) if (f.recipes.get(k).id().equals(active)) i = k;
                    String err = plugin.buildings().selectRecipe(pl, t, pb, f.recipes.get((i + 1) % f.recipes.size()).id());
                    if (err != null) Text.msg(pl, "&c" + err);
                    open(pl, t, pb);
                });
            } else {
                m.set(11, Gui.item(Material.BOOK, "&eRecipes", lore));
            }
        }

        // ---- upgrade
        BuildingDef.Upgrade u = plugin.buildings().nextUpgrade(pb);
        if (u == null) {
            m.set(13, Gui.item(Material.NETHER_STAR, "&6Maximum level",
                    base.maxLevel() > 1 ? "&7This building is fully upgraded." : "&7This building cannot be upgraded."));
        } else {
            BuildingDef next = base.at(pb.level + 1);
            List<String> up = new ArrayList<>();
            for (String d : u.description()) up.add("&7" + d);
            AgeDef need = plugin.reg().age(u.ageId());
            up.add("");
            up.add("&6Requires: &f" + (need == null ? u.ageId() : Text.plain(need.name)));
            BuildingDef.Cost cost = plugin.buildings().upgradeCost(t, pb);
            up.add("&6Cost: &f" + Describe.cost(cost));
            List<String> newReqs = Describe.newRequirements(cur, next);
            if (!newReqs.isEmpty()) { up.add("&6Extra building requirements:"); for (String r : newReqs) up.add("  &7" + r); }
            if (next.rx != cur.rx || next.rz != cur.rz || next.up != cur.up || next.down != cur.down)
                up.add("&6Area grows to &f" + (2 * next.rx + 1) + "x" + (2 * next.rz + 1) + " &6wide, &f" + (next.up + next.down + 1) + " &6tall");
            List<String> gain = new ArrayList<>(Describe.function(next));
            gain.removeAll(Describe.function(cur));
            if (!gain.isEmpty()) { up.add(""); up.add("&6Unlocks:"); up.addAll(gain); }
            up.add("");
            up.add(Gui.action(plugin.buildings().upgradeBlocker(p, t, pb), "Click to upgrade"));
            up.add("&8The building is re-checked first; nothing is charged if it fails.");
            m.set(13, Gui.item(Material.ANVIL, "&eUpgrade to " + Text.plain(next.name), up), pl -> {
                List<String> errs = plugin.buildings().tryUpgrade(pl, t, pb);
                if (errs.isEmpty()) Text.msg(pl, "&aUpgraded to " + plugin.reg().effective(pb).name + "&a!");
                else { pl.sendMessage(Text.c("&cCannot upgrade yet:")); for (String s : errs) pl.sendMessage(Text.c("  &c- &7" + s)); }
                open(pl, t, pb);
            });
        }

        // ---- storage access
        boolean same = pb.input != null && pb.input.equals(pb.output);
        if (pb.input != null) m.set(14, storageButton(p, pb, same ? "Open storage" : "Open input", pb.input, Material.HOPPER, same ? "&7Inputs go in, products come out here." : "&7Put ingredients and tools here."), pl -> openStorage(pl, pb, pb.input));
        if (pb.output != null && !same) m.set(15, storageButton(p, pb, "Open output", pb.output, Material.CHEST, "&7Finished goods appear here."), pl -> openStorage(pl, pb, pb.output));

        // ---- legacy owner payout
        Eco eco = plugin.eco();
        if (pb.stored >= 1 && mine && eco != null) {
            m.set(16, Gui.item(Material.GOLD_INGOT, "&6Collect income", "&7Waiting: &f" + eco.fmt(pb.stored), "&a> Click to collect"), pl -> {
                eco.give(pl, pb.stored);
                Text.msg(pl, "&6Collected &f" + eco.fmt(pb.stored) + "&6.");
                pb.stored = 0;
                plugin.db().saveBuilding(pb);
                open(pl, t, pb);
            });
        }

        // ---- relocate
        String rb = plugin.buildings().removeBlocker(p, t, pb);
        List<String> rl = new ArrayList<>();
        rl.add("&7Picks the core up so you can place it elsewhere.");
        rl.add("&7It keeps its level" + (cur.inputCore || cur.outputCore ? " and the core's contents come back to you." : "."));
        rl.add("");
        if (rb != null) rl.add("&c✘ " + rb);
        else if (!confirmRemove) rl.add("&a> Click to remove (asks to confirm)");
        else rl.add("&c> Click again to confirm removal");
        m.set(18, Gui.item(confirmRemove ? Material.TNT : Material.BARREL, confirmRemove ? "&cConfirm: remove this building?" : "&eRemove / relocate", rl), pl -> {
            if (rb != null) return;
            if (!confirmRemove) { open(pl, t, pb, true); return; }
            String err = plugin.buildings().removeCore(pl, t, pb, false);
            if (err != null) Text.msg(pl, "&c" + err);
            else { Text.msg(pl, "&7Building removed. The core is in your inventory (level " + pb.level + " kept)."); pl.closeInventory(); }
        });
        m.set(22, Gui.item(Material.BARRIER, "&cClose"), Player::closeInventory);
        m.open(p);
    }

    private String activeRecipe(List<Recipe> recipes, PlacedBuilding pb) {
        for (Recipe r : recipes) if (r.id().equals(pb.recipe)) return r.id();
        return recipes.get(0).id();
    }

    private ItemStack info(Town t, PlacedBuilding pb, BuildingDef cur, BuildingDef base, List<String> problems) {
        List<String> lore = new ArrayList<>();
        String owner = Bukkit.getOfflinePlayer(pb.owner).getName();
        lore.add("&7Owner: &f" + (owner == null ? "?" : owner));
        lore.add("&7Level: &f" + pb.level + "&7/" + base.maxLevel());
        if (pb.damaged) {
            lore.add("&cStatus: damaged (production paused)");
            for (String s : problems) lore.add("  &c- &7" + s);
            lore.add("&8Fix it, then open this menu again.");
        } else if (cur.function == null || (cur.function.type.equals("none") && cur.function.always.isEmpty())) {
            lore.add("&aStatus: working &7(passive building)");
        } else {
            long now = System.currentTimeMillis();
            lore.add("&aStatus: working" + (pb.lastStatus.isEmpty() || pb.lastStatus.equals("Running") ? "" : " &8- &e" + pb.lastStatus));
            if (pb.nextRun > 0) lore.add("&6Next production: &f" + (pb.nextRun <= now ? "due now" : "in " + Text.remaining(pb.nextRun - now)));
            else lore.add("&6Next production: &7being scheduled");
        }
        List<String> fn = Describe.function(cur);
        if (!fn.isEmpty()) { lore.add(""); lore.addAll(fn); }
        return Gui.item(cur.icon, cur.name, lore);
    }

    private ItemStack storageButton(Player p, PlacedBuilding pb, String name, dev.ages.model.BlockPos pos, Material icon, String desc) {
        String why = reachBlocker(p, pos);
        return Gui.item(icon, "&e" + name, desc, "", Gui.action(why, "Click to open"));
    }

    private String reachBlocker(Player p, dev.ages.model.BlockPos pos) {
        if (!p.getWorld().getName().equals(pos.world())) return "Not in the same world.";
        Location l = pos.toLocation();
        if (l == null || l.distanceSquared(p.getLocation()) > 20 * 20) return "Too far away (stand within 20 blocks).";
        return null;
    }

    private void openStorage(Player p, PlacedBuilding pb, dev.ages.model.BlockPos pos) {
        String why = reachBlocker(p, pos);
        if (why != null) { Text.msg(p, "&c" + why); return; }
        Block b = pos.block();
        if (b == null || !Containers.isContainer(b.getType()) || !(b.getState(false) instanceof Container c)) { Text.msg(p, "&cThat container is gone."); return; }
        p.openInventory(c.getInventory());
    }
}
