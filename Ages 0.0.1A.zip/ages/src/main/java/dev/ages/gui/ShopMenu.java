package dev.ages.gui;

import dev.ages.AgesPlugin;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.config.Registries;
import dev.ages.config.ShopCategory;
import dev.ages.item.Items;
import dev.ages.manager.Progress;
import dev.ages.model.Town;
import dev.ages.util.InvUtil;
import dev.ages.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * The building catalogue. Categories and buildings come from the YAML files, so a new building (or a whole new category)
 * shows up after a restart with no code change. Buildings of the current and earlier ages are listed, plus the NEXT age's core.
 * Opened by right-clicking the current age core, or from /ages (buying remotely only if settings shop.remote_purchase is true).
 */
public final class ShopMenu {
    private static final int[] CATEGORY_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
    private final AgesPlugin plugin;

    public ShopMenu(AgesPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------------ opening

    public void openMain(Player p, Town t, boolean remote) {
        Registries reg = plugin.reg();
        AgeDef age = reg.age(t.ageId);
        Menu m = new Menu(36, "&8" + t.name + " - Catalogue");
        Set<Integer> used = new HashSet<>();
        List<ShopCategory> unplaced = new ArrayList<>();
        for (ShopCategory c : reg.categories) {
            int slot = c.slot();
            boolean ok = false;
            for (int s : CATEGORY_SLOTS) if (s == slot) ok = true;
            if (ok && used.add(slot)) place(m, p, t, c, slot, remote); else unplaced.add(c);
        }
        int idx = 0;
        for (ShopCategory c : unplaced) {
            while (idx < CATEGORY_SLOTS.length && used.contains(CATEGORY_SLOTS[idx])) idx++;
            if (idx >= CATEGORY_SLOTS.length) break;
            used.add(CATEGORY_SLOTS[idx]);
            place(m, p, t, c, CATEGORY_SLOTS[idx], remote);
        }
        m.set(31, Gui.item(Material.PAPER, "&6" + Text.plain(age.name),
                "&7Resource points: &f" + Text.num(t.points), "&7Treasury: &f" + Text.num(t.money),
                "&7Population: &f" + t.population(true, true) + " &7(housing " + plugin.towns().housing(t) + ")"));
        if (remote) m.set(27, Gui.item(Material.ARROW, "&eBack to overview"), pl -> plugin.civMenu().open(pl));
        m.open(p);
    }

    private void place(Menu m, Player p, Town t, ShopCategory c, int slot, boolean remote) {
        long n = plugin.reg().buildings.values().stream().filter(d -> d.shop && d.category.equals(c.id()) && visible(t, d)).count();
        List<String> lore = new ArrayList<>();
        for (String s : c.description()) lore.add("&7" + s);
        lore.add("");
        lore.add("&8" + n + " building" + (n == 1 ? "" : "s") + " available");
        m.set(slot, Gui.item(c.icon(), c.name(), lore), pl -> openCategory(pl, t, c.id(), 0, remote));
    }

    private void openCategory(Player p, Town t, String catId, int page, boolean remote) {
        Registries reg = plugin.reg();
        ShopCategory cat = reg.categories.stream().filter(c -> c.id().equals(catId)).findFirst().orElse(null);
        if (cat == null) return;
        List<BuildingDef> list = reg.buildings.values().stream()
                .filter(d -> d.shop && d.category.equals(catId) && visible(t, d))
                .sorted(Comparator.comparingInt((BuildingDef d) -> reg.ageOrder(d.ageId)).thenComparing(d -> Text.plain(d.name)))
                .toList();
        int perPage = 45;
        int pages = Math.max(1, (list.size() + perPage - 1) / perPage);
        int pg = Math.max(0, Math.min(page, pages - 1));
        Menu m = new Menu(54, "&8" + Text.plain(cat.name()) + " &8(" + (pg + 1) + "/" + pages + ")");
        for (int i = 0; i < perPage && pg * perPage + i < list.size(); i++) {
            BuildingDef d = list.get(pg * perPage + i);
            m.set(i, buildingIcon(p, t, d, remote), pl -> purchase(pl, t, d, remote));
        }
        m.set(45, Gui.item(Material.ARROW, "&eBack"), pl -> openMain(pl, t, remote));
        if (pg > 0) m.set(48, Gui.item(Material.SPECTRAL_ARROW, "&ePrevious page"), pl -> openCategory(pl, t, catId, pg - 1, remote));
        if (pg < pages - 1) m.set(50, Gui.item(Material.SPECTRAL_ARROW, "&eNext page"), pl -> openCategory(pl, t, catId, pg + 1, remote));
        m.set(53, Gui.item(Material.BARRIER, "&cClose"), Player::closeInventory);
        m.open(p);
    }

    /** Buildings of ages up to the current one (not phased out), plus the NEXT age's core. */
    private boolean visible(Town t, BuildingDef d) {
        Registries reg = plugin.reg();
        AgeDef cur = reg.age(t.ageId);
        AgeDef coreFor = reg.ageForCore(d.id);
        if (coreFor != null) return coreFor == reg.nextAge(cur);
        if (reg.isObsolete(d, cur)) return false;
        return reg.ageOrder(d.ageId) <= cur.order;
    }

    // ------------------------------------------------------------------ icons

    private ItemStack buildingIcon(Player p, Town t, BuildingDef d, boolean remote) {
        Registries reg = plugin.reg();
        AgeDef coreFor = reg.ageForCore(d.id);
        List<String> lore = new ArrayList<>();
        for (String s : d.description) lore.add("&7" + s);
        lore.add("");
        AgeDef ba = reg.age(d.ageId);
        lore.add("&8Age: &7" + (ba == null ? d.ageId : Text.plain(ba.name)) + "   &8Area: &7" + (2 * d.rx + 1) + "x" + (2 * d.rz + 1) + ", " + (d.up + d.down + 1) + " tall");
        if (!d.requirements.isEmpty()) {
            lore.add("&6Build requirements:");
            int n = 0;
            for (BuildingDef.Req r : d.requirements) {
                if (n++ == 8) { lore.add("  &8+" + (d.requirements.size() - 8) + " more"); break; }
                lore.add("  &7" + r.min() + "x &f" + Text.pretty(r.label()));
            }
        }
        if (d.inputCore || d.outputCore) lore.add("  &7Core is a storage block: " + Text.pretty(d.coreBlock));
        if (d.inputContainer != null && !d.inputCore) lore.add("  &7Input container: &f" + Text.pretty(d.inputContainer));
        if (d.outputContainer != null && !d.outputCore) lore.add("  &7Output container: &f" + Text.pretty(d.outputContainer));
        List<String> fn = Describe.function(d);
        if (!fn.isEmpty()) { lore.add(""); lore.addAll(fn); }
        if (!d.upgrades.isEmpty()) {
            lore.add("");
            lore.add("&6Upgrades:");
            int lv = 2;
            for (BuildingDef.Upgrade u : d.upgrades) {
                AgeDef ua = reg.age(u.ageId());
                lore.add("  &8Lv" + lv++ + " (" + (ua == null ? u.ageId() : Text.plain(ua.name)) + "): &7" + (u.description().isEmpty() ? "" : u.description().get(0)));
            }
        }
        if (!d.replaces.isEmpty()) {
            List<String> names = new ArrayList<>();
            for (String r : d.replaces) { BuildingDef rd = reg.building(r); names.add(rd == null ? r : Text.plain(rd.name)); }
            lore.add("&8Can replace: &7" + String.join(", ", names));
        }
        List<String> lim = plugin.limits().describe(t, p.getUniqueId(), d);
        if (!lim.isEmpty()) { lore.add(""); lore.addAll(lim); }

        lore.add("");
        lore.add("&6Cost:");
        BuildingDef.Cost c = plugin.buildings().purchaseCost(t, d);
        if (c.isFree()) lore.add("  &7Free");
        if (c.points() > 0) lore.add("  " + (t.points >= c.points() ? "&a✔ " : "&c✘ ") + "&f" + Text.num(c.points()) + " &7resource points (shared: " + Text.num(t.points) + ")");
        if (c.money() > 0) lore.add("  " + (t.money >= c.money() ? "&a✔ " : "&c✘ ") + "&f" + Text.num(c.money()) + " &7treasury money (shared: " + Text.num(t.money) + ")");
        c.items().forEach((mat, n) -> lore.add("  " + (InvUtil.countPlain(p.getInventory(), mat) >= n ? "&a✔ " : "&c✘ ") + "&f" + n + "x " + Text.pretty(mat) + " &7(from your inventory)"));

        if (coreFor != null) {
            lore.add("");
            lore.add("&6Advancement requirements:");
            lore.addAll(plugin.progress().lines(plugin.progress().eval(t, coreFor.requirements), 0));
            if (!coreFor.retire.isEmpty()) {
                List<String> names = new ArrayList<>();
                for (String r : coreFor.retire) { BuildingDef rd = reg.building(r); names.add(rd == null ? r : Text.plain(rd.name)); }
                lore.add("&8Phased out on entering: &7" + String.join(", ", names));
            }
        }
        lore.add("");
        String blocker = blocker(p, t, d, remote);
        lore.add(Gui.action(blocker, "Click to purchase"));
        return Gui.item(d.icon, d.name, lore);
    }

    private String blocker(Player p, Town t, BuildingDef d, boolean remote) {
        if (remote && !plugin.reg().settings.shopRemotePurchase) return "Right-click your civilization core to buy.";
        return plugin.buildings().purchaseBlocker(p, t, d);
    }

    // ------------------------------------------------------------------ purchase

    private void purchase(Player p, Town t, BuildingDef d, boolean remote) {
        String problem = blocker(p, t, d, remote);
        if (problem != null) { Text.msg(p, "&c" + problem); return; }
        BuildingDef.Cost c = plugin.buildings().purchaseCost(t, d);
        plugin.finance().pay(p, t, c, "PURCHASE", p.getName() + " bought " + Text.plain(d.name));
        InvUtil.give(p, Items.core(d));
        Text.msg(p, "&aPurchased &f" + Text.plain(d.name) + "&a. Build it, then place the core block at its centre.");
        openCategory(p, t, d.category, 0, remote);
    }
}
