package dev.ages.listener;

import dev.ages.AgesPlugin;
import dev.ages.item.Items;
import dev.ages.model.Tracked;
import dev.ages.model.Town;
import dev.ages.util.Text;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.world.EntitiesUnloadEvent;
import org.bukkit.inventory.MerchantInventory;
import org.bukkit.persistence.PersistentDataType;

import java.util.UUID;

/**
 * Plugin-spawned villagers and guards: persistent, untradeable, and never duplicated.
 * The persistent registry (TrackedEntities) is the source of truth for slots, so a villager in an unloaded chunk or
 * across a restart still occupies its slot; only a confirmed death frees it, and the building's timer then spawns one replacement.
 */
public final class VillagerListener implements Listener {
    private final AgesPlugin plugin;

    public VillagerListener(AgesPlugin plugin) { this.plugin = plugin; }

    private boolean ours(Entity e) {
        return e.getPersistentDataContainer().has(Items.TOWN, PersistentDataType.STRING);
    }

    // ---- untradeable

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!plugin.reg().settings.villagersUntradeable) return;
        if (e.getRightClicked() instanceof Villager v && ours(v)) {
            e.setCancelled(true);
            e.getPlayer().sendActionBar(Text.c("&7This villager belongs to a civilization and does not trade."));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onOpen(InventoryOpenEvent e) {
        if (!plugin.reg().settings.villagersUntradeable) return;
        if (e.getInventory() instanceof MerchantInventory mi && mi.getMerchant() instanceof Villager v && ours(v)) e.setCancelled(true);
    }

    // ---- death frees exactly one slot

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        if (plugin.tracked().get(e.getEntity().getUniqueId()) != null) plugin.tracked().remove(e.getEntity().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTransform(EntityTransformEvent e) {   // villager -> zombie villager / witch: the slot is freed
        if (plugin.tracked().get(e.getEntity().getUniqueId()) != null) plugin.tracked().remove(e.getEntity().getUniqueId());
    }

    // ---- chunk lifecycle

    @EventHandler
    public void onUnload(EntitiesUnloadEvent e) {
        for (Entity en : e.getEntities()) if (plugin.tracked().get(en.getUniqueId()) != null) plugin.tracked().updateChunk(en);
    }

    /**
     * Tagged entities that are not in the registry are leftovers: from before this version (adopted if their building still has
     * room) or from a disbanded civilization / lost database (removed), so duplicates can never accumulate.
     */
    @EventHandler
    public void onLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (!ours(en)) continue;
            Tracked known = plugin.tracked().get(en.getUniqueId());
            if (known != null) { en.setPersistent(true); continue; }
            var pdc = en.getPersistentDataContainer();
            String ts = pdc.get(Items.TOWN, PersistentDataType.STRING);
            String bs = pdc.get(Items.BUILDING, PersistentDataType.STRING);
            Town t = null;
            UUID building = null;
            try {
                if (ts != null) t = plugin.towns().byId(UUID.fromString(ts));
                if (bs != null) building = UUID.fromString(bs);
            } catch (IllegalArgumentException ignored) { }
            var pb = building == null ? null : plugin.towns().building(building);
            var def = pb == null ? null : plugin.reg().effective(pb);
            boolean room = def != null && def.function != null && def.function.type.equals("spawner")
                    && plugin.tracked().countBuilding(pb.id) < def.function.cap;
            if (t != null && pb != null && room) plugin.tracked().add(en, t.id, pb.id, en.getType() == EntityType.IRON_GOLEM ? "IRON_GOLEM" : en.getType().name());
            else en.remove();
        }
    }
}
