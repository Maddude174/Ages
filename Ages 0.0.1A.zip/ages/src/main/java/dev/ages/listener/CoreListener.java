package dev.ages.listener;

import dev.ages.AgesPlugin;
import dev.ages.building.Scanner;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.item.Items;
import dev.ages.manager.BuildingManager;
import dev.ages.manager.TownManager;
import dev.ages.model.*;
import dev.ages.util.InvUtil;
import dev.ages.util.Text;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Everything that happens to core blocks: founding a civilization (with a chat naming prompt), validating and registering
 * buildings when their core is placed (the age handoff is transactional), opening menus on right-click, and removing
 * a building when its core is broken (the core item and any chest contents are handed back for relocation).
 */
public final class CoreListener implements Listener {
    private record Pending(BuildingDef base, BlockPos pos, Scanner.Result scan, ItemStack item, BukkitTask timeout) {}

    private final AgesPlugin plugin;
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    public CoreListener(AgesPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------------ placing cores

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        String id = Items.coreId(e.getItemInHand());
        if (id == null) return;
        Player p = e.getPlayer();
        BuildingDef base = plugin.reg().building(id);
        if (base == null) {
            e.setCancelled(true);
            Text.msg(p, "&cThis core item refers to an unknown building ('" + id + "'). It may have been removed from the configuration.");
            return;
        }
        if (base.founding) { startFounding(e, base); return; }

        Town t = plugin.towns().of(p.getUniqueId());
        if (t == null) {
            e.setCancelled(true);
            Text.msg(p, "&cYou must belong to a civilization to place buildings.");
            return;
        }
        BuildingManager.Result r = plugin.buildings().tryPlace(p, t, base, Items.level(e.getItemInHand()), Items.bid(e.getItemInHand()), e.getBlockPlaced());
        if (!r.ok()) {
            e.setCancelled(true);
            p.sendMessage(Text.c("&c" + base.name + " &ccannot be activated:"));
            for (String m : r.messages()) p.sendMessage(Text.c("  &c- &7" + m));
            return;
        }
        BuildingDef eff = plugin.reg().effective(r.building());
        Text.msg(p, (eff == null ? base.name : eff.name) + " &7is now active.");
        if (!r.retired().isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (PlacedBuilding old : r.retired()) {
                BuildingDef od = plugin.reg().building(old.defId);
                if (sb.length() > 0) sb.append("&7, ");
                sb.append(od == null ? old.defId : od.name);
            }
            Text.msg(p, "&7Replaced and retired: " + sb + "&7. Their blocks stay in the world.");
        }
        if (r.advancedTo() != null) {
            AgeDef a = r.advancedTo();
            for (UUID u : t.members.keySet()) {
                Player m = Bukkit.getPlayer(u);
                if (m != null) m.sendMessage(Text.c("&6&l" + t.name + " &6enters the " + Text.plain(a.name) + "!"));
            }
        }
    }

    // ------------------------------------------------------------------ founding

    private void startFounding(BlockPlaceEvent e, BuildingDef base) {
        Player p = e.getPlayer();
        UUID u = p.getUniqueId();
        TownManager tm = plugin.towns();
        if (tm.of(u) != null) { deny(e, "&cYou already belong to a civilization."); return; }
        if (pending.containsKey(u)) { deny(e, "&cFinish naming your current civilization first."); return; }
        BlockPos pos = BlockPos.of(e.getBlockPlaced());
        String problem = tm.canFound(pos);
        if (problem != null) { deny(e, "&c" + problem); return; }
        Scanner.Result scan = Scanner.scan(e.getBlockPlaced().getWorld(), pos, base);
        if (!scan.ok()) {
            e.setCancelled(true);
            p.sendMessage(Text.c("&c" + base.name + " &ccannot be founded yet:"));
            for (String m : scan.problems()) p.sendMessage(Text.c("  &c- &7" + m));
            return;
        }
        ItemStack item = e.getItemInHand().clone();
        item.setAmount(1);
        BukkitTask timeout = Bukkit.getScheduler().runTaskLater(plugin, () -> cancelFounding(u, "&cNaming timed out."), 20L * 90);
        pending.put(u, new Pending(base, pos, scan, item, timeout));
        p.sendMessage(Text.c("&6&lYour " + Text.plain(base.name) + " is built."));
        p.sendMessage(Text.c("&7Type a name for your civilization in chat &8(or type &fcancel&8)."));
    }

    private void deny(BlockPlaceEvent e, String msg) {
        e.setCancelled(true);
        Text.msg(e.getPlayer(), msg);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        UUID u = e.getPlayer().getUniqueId();
        if (!pending.containsKey(u)) return;
        e.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        Bukkit.getScheduler().runTask(plugin, () -> handleName(u, text));
    }

    private void handleName(UUID u, String text) {
        Pending pd = pending.get(u);
        Player p = Bukkit.getPlayer(u);
        if (pd == null || p == null) return;
        if (text.equalsIgnoreCase("cancel")) { cancelFounding(u, "&7Founding cancelled."); return; }
        if (!text.matches(plugin.reg().settings.nameRegex)) {
            Text.msg(p, "&cInvalid name. Allowed: " + plugin.reg().settings.nameRegex + " - try again or type cancel.");
            return;
        }
        TownManager tm = plugin.towns();
        if (tm.nameTaken(text)) { Text.msg(p, "&cThat name is taken. Try another."); return; }
        String problem = tm.canFound(pd.pos());
        if (problem != null) { cancelFounding(u, "&c" + problem); return; }

        pd.timeout().cancel();
        pending.remove(u);
        Town t = tm.found(text, u, pd.pos());
        PlacedBuilding core = new PlacedBuilding(UUID.randomUUID(), pd.base().id, t.id, u, pd.pos());
        core.setBox(pd.base().rx, pd.base().rz, pd.base().up, pd.base().down);
        core.input = pd.scan().input();
        core.output = pd.scan().output();
        tm.addBuilding(t, core);
        plugin.production().schedule(core, 0);
        p.sendMessage(Text.c("&6&lThe civilization of " + t.name + " is founded!"));
        Text.msg(p, "&7Right-click your core to open the building shop, or type &e/ages&7 for an overview.");
    }

    private void cancelFounding(UUID u, String why) {
        Pending pd = pending.remove(u);
        if (pd == null) return;
        pd.timeout().cancel();
        Block b = pd.pos().block();
        if (b != null && b.getType() == pd.base().coreBlock) b.setType(Material.AIR);
        Player p = Bukkit.getPlayer(u);
        if (p != null) { InvUtil.give(p, pd.item()); Text.msg(p, why); }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { cancelFounding(e.getPlayer().getUniqueId(), "&7Founding cancelled."); }

    // ------------------------------------------------------------------ using cores

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        PlacedBuilding pb = plugin.towns().core(BlockPos.of(b));
        if (pb == null) return;
        Player p = e.getPlayer();
        if (p.isSneaking() && e.getItem() != null) return; // sneak-click with an item still builds against it
        e.setUseInteractedBlock(Event.Result.DENY);        // also stops chest/barrel cores from opening raw; the menu offers "open storage"
        e.setUseItemInHand(Event.Result.DENY);

        Town t = plugin.towns().byId(pb.townId);
        if (t == null || !t.members.containsKey(p.getUniqueId())) { Text.msg(p, "&cYou are not a member of this civilization."); return; }

        // the current age core opens the shop; sneak + empty hand opens that core's own building menu
        if (t.core.equals(pb.core) && !p.isSneaking()) {
            if (!t.can(p.getUniqueId(), Perm.USE_SHOP)) Text.msg(p, "&cYour role cannot use the catalogue.");
            else plugin.shop().openMain(p, t, false);
            return;
        }
        plugin.buildingMenu().open(p, t, pb);
    }

    // ------------------------------------------------------------------ breaking cores

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        PlacedBuilding pb = plugin.towns().core(BlockPos.of(e.getBlock()));
        if (pb == null) return;
        Player p = e.getPlayer();
        Town t = plugin.towns().byId(pb.townId);
        if (t == null) return;
        String why = plugin.buildings().removeBlocker(p, t, pb);
        if (why != null) {
            e.setCancelled(true);
            Text.msg(p, "&c" + why);
            return;
        }
        e.setDropItems(false);
        plugin.buildings().removeCore(p, t, pb, true);
        Text.msg(p, "&7Building removed. Its core drops (keeping its level) so you can place it elsewhere.");
    }
}
