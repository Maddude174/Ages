package dev.ages;

import org.bukkit.configuration.file.YamlConfiguration;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * Keeps the data folder in step with the plugin's shipped defaults WITHOUT overwriting your edits:
 *  - fresh install: every shipped file is installed
 *  - new shipped files (new ages/buildings/governments/...) are added automatically on the next start, so new content appears
 *    in the shop/GUI with no code change. A file you deleted on purpose is remembered (defaults.manifest) and not restored.
 *  - when the shipped defaults change incompatibly (VERSION bump): your old default files are BACKED UP to backup/ before being
 *    replaced, obsolete ones are removed, and town.yml is migrated to settings.yml with your values carried over.
 * Files you added yourself are never touched.
 */
final class DefaultsSync {
    /** Bump when shipped default content changes in a way that old files cannot coexist with. */
    static final int VERSION = 2;
    private static final String[] FOLDERS = {"ages", "buildings", "governments", "economies", "policies"};
    private static final String[] ROOT_FILES = {"blockgroups.yml", "settings.yml", "shop.yml"};

    private DefaultsSync() {}

    static void run(AgesPlugin plugin) {
        File data = plugin.getDataFolder();
        data.mkdirs();
        List<String> shipped = listShipped(plugin);
        File markerFile = new File(data, "defaults.version");
        File manifestFile = new File(data, "defaults.manifest");
        int installed = readInt(markerFile);
        boolean existing = new File(data, "buildings").exists() || new File(data, "town.yml").exists() || new File(data, "settings.yml").exists();
        Set<String> manifest = new LinkedHashSet<>(readLines(manifestFile));

        try {
            if (installed < VERSION) {
                if (existing) migrate(plugin, shipped, installed);
                else for (String path : shipped) if (!new File(data, path).exists()) plugin.saveResource(path, false);
                write(markerFile, String.valueOf(VERSION));
                manifest.clear();
                manifest.addAll(shipped);
            } else {
                int added = 0;
                for (String path : shipped) {
                    if (manifest.contains(path)) continue;
                    File f = new File(data, path);
                    if (!f.exists()) { plugin.saveResource(path, false); added++; plugin.getLogger().info("New default installed: " + path); }
                    manifest.add(path);
                }
            }
            write(manifestFile, String.join("\n", manifest));
        } catch (IOException e) {
            plugin.getLogger().severe("Could not sync default files: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ migration

    private static void migrate(AgesPlugin plugin, List<String> shipped, int from) throws IOException {
        File data = plugin.getDataFolder();
        File backup = new File(data, "backup/defaults-v" + from + "-" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date()));
        backup.mkdirs();
        plugin.getLogger().info("Updating default configuration (v" + from + " -> v" + VERSION + "). Your previous files are backed up in " + backup.getPath());

        Set<String> obsolete = new HashSet<>(resourceLines(plugin, "obsolete-defaults.txt"));
        int removed = 0, replaced = 0;
        for (String path : obsolete) {
            File f = new File(data, path);
            if (f.exists()) { backupFile(f, backup, data); f.delete(); removed++; }
        }
        for (String path : shipped) {
            if (path.equals("settings.yml")) continue;      // merged below
            File f = new File(data, path);
            if (f.exists()) { backupFile(f, backup, data); replaced++; }
            plugin.saveResource(path, true);
        }

        // town.yml -> settings.yml: keep the user's values
        File oldTown = new File(data, "town.yml");
        File settings = new File(data, "settings.yml");
        File source = oldTown.exists() ? oldTown : settings.exists() ? settings : null;
        YamlConfiguration fresh = new YamlConfiguration();
        try (InputStream in = plugin.getResource("settings.yml")) {
            if (in != null) fresh = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
        }
        if (source != null) {
            backupFile(source, backup, data);
            YamlConfiguration old = YamlConfiguration.loadConfiguration(source);
            int carried = 0;
            for (String key : old.getKeys(true)) {
                if (old.isConfigurationSection(key) || key.startsWith("ranks") || key.startsWith("economy.contributions")) continue;
                if (fresh.contains(key)) { fresh.set(key, old.get(key)); carried++; }
            }
            plugin.getLogger().info("Carried " + carried + " setting(s) over from " + source.getName() + " into settings.yml.");
        }
        fresh.save(settings);
        if (oldTown.exists()) {
            oldTown.delete();
            plugin.getLogger().info("town.yml was renamed to settings.yml (the old file is in the backup folder).");
        }
        plugin.getLogger().info("Defaults updated: " + replaced + " file(s) replaced, " + removed + " obsolete file(s) removed. "
                + "Buildings you saved under old ids keep working through aliases.");
    }

    private static void backupFile(File f, File backup, File data) throws IOException {
        File dest = new File(backup, data.toPath().relativize(f.toPath()).toString());
        dest.getParentFile().mkdirs();
        Files.copy(f.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    // ------------------------------------------------------------------ helpers

    private static List<String> listShipped(AgesPlugin plugin) {
        List<String> out = new ArrayList<>();
        for (String f : ROOT_FILES) out.add(f);
        try (JarFile jar = new JarFile(plugin.pluginFile())) {
            jar.stream().map(JarEntry::getName).forEach(n -> {
                for (String folder : FOLDERS) if (n.startsWith(folder + "/") && n.endsWith(".yml")) out.add(n);
            });
        } catch (IOException e) {
            plugin.getLogger().severe("Could not read the plugin jar: " + e.getMessage());
        }
        return out;
    }

    private static List<String> resourceLines(AgesPlugin plugin, String name) {
        List<String> out = new ArrayList<>();
        try (InputStream in = plugin.getResource(name)) {
            if (in == null) return out;
            for (String l : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\n")) if (!l.isBlank() && !l.startsWith("#")) out.add(l.trim());
        } catch (IOException ignored) { }
        return out;
    }

    private static int readInt(File f) {
        try { return Integer.parseInt(Files.readString(f.toPath()).trim()); } catch (Exception e) { return 0; }
    }

    private static List<String> readLines(File f) {
        try { return f.exists() ? Files.readAllLines(f.toPath()) : List.of(); } catch (IOException e) { return List.of(); }
    }

    private static void write(File f, String text) throws IOException { Files.writeString(f.toPath(), text); }
}
