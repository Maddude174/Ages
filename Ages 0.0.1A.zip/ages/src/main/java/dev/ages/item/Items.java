package dev.ages.item;

import dev.ages.config.BuildingDef;
import dev.ages.util.Text;
import net.kyori.adventure.text.Component;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Custom items are identified by PersistentDataContainer tags, never by display name. */
public final class Items {
    public static NamespacedKey CORE;     // building id
    public static NamespacedKey LEVEL;    // building level, so relocating an upgraded building keeps its level
    public static NamespacedKey BID;      // building uuid, so relocating keeps its identity (and its villagers)
    public static NamespacedKey TOWN;     // on spawned entities
    public static NamespacedKey BUILDING; // on spawned entities

    private Items() {}

    public static void init(Plugin p) {
        CORE = new NamespacedKey(p, "core");
        LEVEL = new NamespacedKey(p, "level");
        BID = new NamespacedKey(p, "bid");
        TOWN = new NamespacedKey(p, "town");
        BUILDING = new NamespacedKey(p, "building");
    }

    public static ItemStack core(BuildingDef d) { return core(d, 1, null); }

    public static ItemStack core(BuildingDef base, int level, UUID bid) {
        BuildingDef eff = base.at(level);
        ItemStack it = new ItemStack(base.coreBlock);
        ItemMeta m = it.getItemMeta();
        m.displayName(Text.c(eff.name));
        List<Component> lore = new ArrayList<>();
        for (String l : base.description) lore.add(Text.c("&7" + l));
        lore.add(Component.empty());
        if (level > 1) lore.add(Text.c("&6Level " + level + " &8(keeps its upgrades)"));
        lore.add(Text.c(base.founding ? "&8Place it to found your civilization." : "&8Build the structure, then place this"));
        if (!base.founding) lore.add(Text.c("&8block at its centre to activate it."));
        m.lore(lore);
        var pdc = m.getPersistentDataContainer();
        pdc.set(CORE, PersistentDataType.STRING, base.id);
        if (level > 1) pdc.set(LEVEL, PersistentDataType.INTEGER, level);
        if (bid != null) pdc.set(BID, PersistentDataType.STRING, bid.toString());
        it.setItemMeta(m);
        return it;
    }

    public static String coreId(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(CORE, PersistentDataType.STRING);
    }

    public static int level(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return 1;
        Integer l = it.getItemMeta().getPersistentDataContainer().get(LEVEL, PersistentDataType.INTEGER);
        return l == null ? 1 : Math.max(1, l);
    }

    public static UUID bid(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        String s = it.getItemMeta().getPersistentDataContainer().get(BID, PersistentDataType.STRING);
        try { return s == null ? null : UUID.fromString(s); } catch (IllegalArgumentException e) { return null; }
    }
}
