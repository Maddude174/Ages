package dev.ages.command;

import dev.ages.AgesPlugin;
import dev.ages.config.*;
import dev.ages.item.Items;
import dev.ages.manager.Progress;
import dev.ages.model.*;
import dev.ages.util.InvUtil;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/** /ages with no arguments opens the civilization GUI; subcommands mirror what the GUI can do. */
public final class AgesCommand implements CommandExecutor, TabCompleter {
    private final AgesPlugin plugin;
    private final Map<UUID, Long> pendingDisband = new HashMap<>();
    private final Map<UUID, Long> pendingTransfer = new HashMap<>();

    public AgesCommand(AgesPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            if (s instanceof Player p) plugin.civMenu().open(p); else help(s);
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "menu", "gui" -> { if (s instanceof Player p) plugin.civMenu().open(p); }
            case "help" -> help(s);
            case "info" -> info(s, a);
            case "buildings" -> buildings(s);
            case "logistics" -> logistics(s);
            case "invite" -> invite(s, a);
            case "accept" -> accept(s);
            case "leave" -> leave(s);
            case "kick" -> kick(s, a);
            case "rank", "role" -> rank(s, a);
            case "contribute" -> contribute(s, a);
            case "withdraw" -> money(s, a, "withdraw");
            case "convert" -> money(s, a, "convert");
            case "treasury" -> treasury(s);
            case "government", "gov" -> government(s, a);
            case "economy", "econ" -> economy(s, a);
            case "policy" -> policy(s, a);
            case "vote" -> vote(s, a);
            case "leader" -> leader(s, a);
            case "owner" -> owner(s, a);
            case "disband" -> disband(s, a);
            case "core", "fireplace" -> give(s, plugin.reg().foundingBuilding(), a.length > 1 ? a[1] : null);
            case "give" -> {
                if (a.length < 2) { Text.msg(s, "&cUsage: /ages give <building> [player]"); return true; }
                give(s, plugin.reg().building(a[1].toLowerCase()), a.length > 2 ? a[2] : null);
            }
            case "reload" -> {
                if (!s.hasPermission("ages.admin")) { Text.msg(s, "&cNo permission."); return true; }
                if (plugin.reloadAll(s)) Text.msg(s, "&aConfiguration reloaded.");
            }
            default -> help(s);
        }
        return true;
    }

    private void help(CommandSender s) {
        Text.msg(s, "&6Ages commands:");
        for (String l : new String[]{
                "/ages &8- open the civilization menu",
                "/ages info [civilization] &8- summary and advancement checklist",
                "/ages buildings | logistics | treasury",
                "/ages invite <player> | accept | leave | kick <player>",
                "/ages contribute hand|all|money <n>   /ages withdraw <n>   /ages convert <n>",
                "/ages government [list|set <id>]   /ages economy [list|set <id>]",
                "/ages policy [list|<id>] &8- adopt or revoke   /ages vote <player>   /ages leader <player>",
                "/ages rank list|create <name> [weight]|delete <name>|perm <name> <PERM> <true|false>|set <player> <role>",
                "/ages owner transfer <player> &8- technical ownership   /ages disband",
                "/ages core [player] &8- (admin) founding core   /ages give <building> [player]   /ages reload"})
            s.sendMessage(Text.c("  &e" + l));
    }

    // ------------------------------------------------------------------ helpers

    private Player player(CommandSender s) {
        if (s instanceof Player p) return p;
        Text.msg(s, "&cPlayers only.");
        return null;
    }

    private Town townOf(Player p) {
        Town t = plugin.towns().of(p.getUniqueId());
        if (t == null) Text.msg(p, "&cYou are not in a civilization.");
        return t;
    }

    private boolean need(Player p, Town t, Perm perm) {
        if (t.can(p.getUniqueId(), perm)) return true;
        Rank r = t.rankOf(p.getUniqueId());
        Text.msg(p, "&cYour role (" + (r == null ? "none" : r.title) + ") cannot: " + perm.description.toLowerCase() + ".");
        return false;
    }

    private String name(UUID u) { String n = u == null ? null : Bukkit.getOfflinePlayer(u).getName(); return n == null ? "?" : n; }

    private UUID memberByName(Town t, String name) {
        for (UUID u : t.members.keySet()) if (name.equalsIgnoreCase(Bukkit.getOfflinePlayer(u).getName())) return u;
        return null;
    }

    private double amount(CommandSender s, String[] a, int idx) {
        try { return Double.parseDouble(a[idx]); } catch (RuntimeException e) { Text.msg(s, "&cEnter a number."); return -1; }
    }

    // ------------------------------------------------------------------ info

    private void give(CommandSender s, BuildingDef d, String target) {
        if (!s.hasPermission("ages.admin")) { Text.msg(s, "&cNo permission."); return; }
        if (d == null) { Text.msg(s, "&cUnknown building."); return; }
        Player p = target != null ? Bukkit.getPlayerExact(target) : s instanceof Player pl ? pl : null;
        if (p == null) { Text.msg(s, "&cPlayer not found."); return; }
        InvUtil.give(p, Items.core(d));
        Text.msg(s, "&7Gave &f" + Text.plain(d.name) + " &7to " + p.getName() + ".");
    }

    private void info(CommandSender s, String[] a) {
        Town t = a.length > 1 ? plugin.towns().byName(String.join(" ", Arrays.copyOfRange(a, 1, a.length)))
                : s instanceof Player p ? plugin.towns().of(p.getUniqueId()) : null;
        if (t == null) { Text.msg(s, "&cCivilization not found."); return; }
        Registries reg = plugin.reg();
        AgeDef age = reg.age(t.ageId);
        GovernmentDef gov = reg.government(t.govId);
        s.sendMessage(Text.c("&6&l" + t.name + " &8- &7" + Text.plain(age.name) + " &8- &7" + Text.plain(gov.name) + " / " + Text.plain(reg.economy(t.econId).name)));
        s.sendMessage(Text.c("&7" + gov.leaderTitle + ": &f" + name(t.leader) + " &7Owner: &f" + name(t.owner) + " &7Members: &f" + t.members.size()
                + " &7Villagers: &f" + t.villagers + " &7Housing: &f" + plugin.towns().housing(t) + " &7Buildings: &f" + t.buildings.size()));
        s.sendMessage(Text.c("&7Resource points: &f" + Text.num(t.points)));
        AgeDef next = reg.nextAge(age);
        if (next == null) { s.sendMessage(Text.c("&aFinal age reached.")); return; }
        Progress.Node n = plugin.progress().eval(t, next.requirements);
        s.sendMessage(Text.c("&7To reach the " + Text.plain(next.name) + ":" + (n.met() ? " &a(requirements met: buy its core in the catalogue)" : "")));
        for (String l : plugin.progress().lines(n, 0)) s.sendMessage(Text.c("  " + l));
    }

    private void buildings(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Map<String, int[]> counts = new TreeMap<>();
        for (PlacedBuilding b : t.buildings) {
            int[] c = counts.computeIfAbsent(b.defId + "#" + b.level, k -> new int[2]);
            c[0]++;
            if (b.damaged) c[1]++;
        }
        counts.forEach((key, c) -> {
            String[] kv = key.split("#");
            BuildingDef d = plugin.reg().building(kv[0]);
            String nm = d == null ? kv[0] : d.at(Integer.parseInt(kv[1])).name;
            p.sendMessage(Text.c("  &f" + c[0] + "x " + nm + (c[1] > 0 ? " &c(" + c[1] + " damaged)" : "")));
        });
    }

    private void logistics(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        List<String> lines = plugin.logistics().describe(t);
        if (lines.isEmpty()) Text.msg(p, "&7No rail network links two of your buildings yet (rail logistics unlock in the " + plugin.reg().settings.logisticsMinAge + " age).");
        else for (String l : lines) p.sendMessage(Text.c("  &f" + l));
    }

    private void treasury(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null || !need(p, t, Perm.VIEW_FINANCES)) return;
        p.sendMessage(Text.c("&6Treasury: &f" + Text.num(t.money) + " &6Resource points: &f" + Text.num(t.points)));
        long now = System.currentTimeMillis();
        int n = 0;
        for (Tx x : t.ledger) {
            if (n++ >= 12) break;
            p.sendMessage(Text.c("  &8" + Text.remaining(now - x.ts) + " ago &7" + (x.actor == null ? "Civilization" : name(x.actor)) + " &f" + x.type.toLowerCase().replace('_', ' ')
                    + " " + (x.amount >= 0 ? "&a+" : "&c") + Text.num(x.amount) + (x.currency.equals("POINTS") ? " pts" : " $") + " &8" + x.note));
        }
    }

    // ------------------------------------------------------------------ membership

    private void invite(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null || !need(p, t, Perm.INVITE)) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages invite <player>"); return; }
        Player target = Bukkit.getPlayerExact(a[1]);
        if (target == null) { Text.msg(p, "&cPlayer not online."); return; }
        if (plugin.towns().of(target.getUniqueId()) != null) { Text.msg(p, "&cThey already belong to a civilization."); return; }
        if (t.members.size() >= plugin.reg().settings.maxMembers) { Text.msg(p, "&cThe civilization is full."); return; }
        t.invites.add(target.getUniqueId());
        Text.msg(p, "&7Invited " + target.getName() + ".");
        Text.msg(target, "&6" + p.getName() + " &7invited you to join &f" + t.name + "&7. Type &e/ages accept&7.");
    }

    private void accept(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        if (plugin.towns().of(p.getUniqueId()) != null) { Text.msg(p, "&cYou already belong to a civilization."); return; }
        for (Town t : plugin.towns().all()) {
            if (t.invites.contains(p.getUniqueId())) {
                plugin.towns().addMember(t, p.getUniqueId(), plugin.reg().government(t.govId).defaultRole);
                Text.msg(p, "&aYou joined " + t.name + "!");
                return;
            }
        }
        Text.msg(p, "&cNo pending invitation.");
    }

    private void leave(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (t.members.size() == 1) { Text.msg(p, "&cYou are the last member. Use &e/ages disband&c to dissolve the civilization."); return; }
        if (t.isOwner(p.getUniqueId())) { Text.msg(p, "&cYou are the technical owner: transfer ownership first (/ages owner transfer <player>)."); return; }
        if (p.getUniqueId().equals(t.leader)) { Text.msg(p, "&cYou are the " + plugin.reg().government(t.govId).leaderTitle + ": hand over leadership first."); return; }
        plugin.towns().removeMember(t, p.getUniqueId());
        Text.msg(p, "&7You left " + t.name + ". Your buildings passed to the civilization's highest rank.");
    }

    private void kick(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null || !need(p, t, Perm.KICK)) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages kick <player>"); return; }
        UUID u = memberByName(t, a[1]);
        if (u == null) { Text.msg(p, "&cNot a member."); return; }
        if (t.isOwner(u)) { Text.msg(p, "&cThe technical owner cannot be removed."); return; }
        if (t.weightOf(u) >= t.weightOf(p.getUniqueId())) { Text.msg(p, "&cYou can only remove members ranked below you."); return; }
        plugin.towns().removeMember(t, u);
        Text.msg(p, "&7Removed " + a[1] + ".");
    }

    // ------------------------------------------------------------------ money

    private void contribute(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages contribute hand|all|money <amount>"); return; }
        switch (a[1].toLowerCase()) {
            case "hand" -> Text.msg(p, plugin.finance().contributeItems(p, t, false));
            case "all" -> Text.msg(p, plugin.finance().contributeItems(p, t, true));
            case "money" -> { if (a.length < 3) { Text.msg(p, "&cUsage: /ages contribute money <amount>"); return; } double v = amount(p, a, 2); if (v > 0) Text.msg(p, plugin.finance().contributeMoney(p, t, v)); }
            default -> Text.msg(p, "&cUsage: /ages contribute hand|all|money <amount>");
        }
    }

    private void money(CommandSender s, String[] a, String what) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages " + what + " <amount>"); return; }
        double v = amount(p, a, 1);
        if (v <= 0) return;
        Text.msg(p, what.equals("withdraw") ? plugin.finance().withdraw(p, t, v) : plugin.finance().convert(p, t, v));
    }

    // ------------------------------------------------------------------ government, economy, policies

    private void government(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Registries reg = plugin.reg();
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            Text.msg(p, "&7Current: &f" + Text.plain(reg.government(t.govId).name));
            for (GovernmentDef g : reg.governments.values()) {
                String why = plugin.governance().govBlocker(p, t, g);
                p.sendMessage(Text.c("  &e" + g.id + " &7- " + Text.plain(g.name) + (g.id.equals(t.govId) ? " &a(current)" : why == null ? " &a(available)" : " &c" + why)));
            }
            return;
        }
        if (a.length < 3 || !a[1].equalsIgnoreCase("set")) { Text.msg(p, "&cUsage: /ages government [list|set <id>]"); return; }
        GovernmentDef g = reg.governments.get(a[2].toLowerCase());
        if (g == null) { Text.msg(p, "&cUnknown government."); return; }
        String e = plugin.governance().changeGovernment(p, t, g);
        Text.msg(p, e == null ? "&aThe civilization is now a " + Text.plain(g.name) + "&a." : "&c" + e);
    }

    private void economy(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Registries reg = plugin.reg();
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            Text.msg(p, "&7Current: &f" + Text.plain(reg.economy(t.econId).name));
            for (EconomyDef e : reg.economies.values()) {
                String why = plugin.governance().econBlocker(p, t, e);
                p.sendMessage(Text.c("  &e" + e.id + " &7- " + Text.plain(e.name) + (e.id.equals(t.econId) ? " &a(current)" : why == null ? " &a(available)" : " &c" + why)));
            }
            return;
        }
        if (a.length < 3 || !a[1].equalsIgnoreCase("set")) { Text.msg(p, "&cUsage: /ages economy [list|set <id>]"); return; }
        EconomyDef e = reg.economies.get(a[2].toLowerCase());
        if (e == null) { Text.msg(p, "&cUnknown economic system."); return; }
        String err = plugin.governance().changeEconomy(p, t, e);
        Text.msg(p, err == null ? "&aThe economy is now " + Text.plain(e.name) + "&a." : "&c" + err);
    }

    private void policy(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Registries reg = plugin.reg();
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            for (PolicyDef pd : reg.policies.values()) {
                if (!plugin.governance().offered(t, pd)) continue;
                String why = plugin.governance().policyBlocker(p, t, pd);
                p.sendMessage(Text.c("  &e" + pd.id + " &7(" + pd.kind + ") " + Text.plain(pd.name) + (t.policies.contains(pd.id) ? " &a[active]" : why == null ? " &7[available]" : " &c" + why)));
            }
            return;
        }
        PolicyDef pd = reg.policy(a[1].toLowerCase());
        if (pd == null) { Text.msg(p, "&cUnknown policy."); return; }
        String err = plugin.governance().togglePolicy(p, t, pd);
        Text.msg(p, err == null ? "&a" + Text.plain(pd.name) + (t.policies.contains(pd.id) ? " adopted." : " revoked.") : "&c" + err);
    }

    private void vote(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages vote <member>"); return; }
        UUID u = memberByName(t, a[1]);
        if (u == null) { Text.msg(p, "&cNot a member."); return; }
        String e = plugin.governance().vote(p, t, u);
        Text.msg(p, e == null ? "&aVote recorded. Current " + plugin.reg().government(t.govId).leaderTitle + ": &f" + name(t.leader) : "&c" + e);
    }

    private void leader(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages leader <member>"); return; }
        UUID u = memberByName(t, a[1]);
        if (u == null) { Text.msg(p, "&cNot a member."); return; }
        String e = plugin.governance().appointLeader(p, t, u);
        Text.msg(p, e == null ? "&a" + name(u) + " now leads the civilization." : "&c" + e);
    }

    private void owner(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 3 || !a[1].equalsIgnoreCase("transfer")) { Text.msg(p, "&cUsage: /ages owner transfer <member> [confirm]   (owner = technical ownership; the leader is separate)"); return; }
        UUID u = memberByName(t, a[2]);
        if (u == null) { Text.msg(p, "&cNot a member."); return; }
        if (a.length < 4 || !a[3].equalsIgnoreCase("confirm")) {
            pendingTransfer.put(p.getUniqueId(), System.currentTimeMillis());
            Text.msg(p, "&eThis hands disband and ownership rights to " + a[2] + ". Run &f/ages owner transfer " + a[2] + " confirm &ewithin 30 seconds.");
            return;
        }
        Long at = pendingTransfer.remove(p.getUniqueId());
        if (at == null || System.currentTimeMillis() - at > 30_000) { Text.msg(p, "&cConfirmation expired. Start again."); return; }
        String e = plugin.governance().transferOwnership(p, t, u);
        Text.msg(p, e == null ? "&aOwnership transferred to " + name(u) + "." : "&c" + e);
    }

    private void disband(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null || !need(p, t, Perm.DISBAND)) return;
        if (a.length < 2 || !a[1].equalsIgnoreCase("confirm")) {
            pendingDisband.put(p.getUniqueId(), System.currentTimeMillis());
            Text.msg(p, "&c&lThis permanently removes " + t.name + ": building records, ledger, villagers. Blocks stay.");
            Text.msg(p, "&cType &f/ages disband confirm &cwithin 30 seconds to continue.");
            return;
        }
        Long at = pendingDisband.remove(p.getUniqueId());
        if (at == null || System.currentTimeMillis() - at > 30_000) { Text.msg(p, "&cConfirmation expired. Run /ages disband again."); return; }
        String e = plugin.towns().disbandBy(p, t);
        if (e != null) Text.msg(p, "&c" + e);
    }

    // ------------------------------------------------------------------ roles

    private void rank(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages rank list|create|delete|perm|set"); return; }
        UUID me = p.getUniqueId();
        Rank mine = t.rankOf(me);
        GovernmentDef gov = plugin.reg().government(t.govId);
        String sub = a[1].toLowerCase();
        if (sub.equals("list")) {
            for (Rank r : t.ranks.values().stream().sorted(Comparator.comparingInt((Rank r) -> -r.weight)).toList())
                p.sendMessage(Text.c("  &e" + r.name + " &8(" + r.weight + ") &7" + r.perms.stream().map(Enum::name).collect(Collectors.joining(", "))));
            return;
        }
        if (sub.equals("set")) {
            if (!need(p, t, Perm.APPOINT_OFFICIALS)) return;
            if (a.length < 4) { Text.msg(p, "&cUsage: /ages rank set <player> <role>"); return; }
            UUID u = memberByName(t, a[2]);
            Rank r = t.ranks.get(a[3].toLowerCase());
            if (u == null || r == null) { Text.msg(p, "&cUnknown member or role."); return; }
            if (r.name.equals(gov.leaderRole) || u.equals(t.leader)) { Text.msg(p, "&cThe " + gov.leaderTitle + " is set through leadership rules (/ages leader or /ages vote)."); return; }
            if (t.weightOf(u) >= mine.weight || r.weight >= mine.weight) { Text.msg(p, "&cYou can only manage members and roles below your own."); return; }
            t.members.put(u, r.name);
            plugin.towns().save(t);
            Text.msg(p, "&7" + a[2] + " is now &f" + r.title + "&7.");
            return;
        }
        if (!need(p, t, Perm.MANAGE_RANKS)) return;
        if (!gov.allowCustomRoles && !sub.equals("perm")) { Text.msg(p, "&cYour government does not allow custom roles."); return; }
        switch (sub) {
            case "create" -> {
                if (a.length < 3) { Text.msg(p, "&cUsage: /ages rank create <name> [weight]"); return; }
                String name = a[2].toLowerCase();
                int w = a.length > 3 ? parseInt(a[3], 10) : 10;
                if (t.ranks.containsKey(name)) { Text.msg(p, "&cThat role exists."); return; }
                if (w >= mine.weight) { Text.msg(p, "&cNew roles must be below your own weight (" + mine.weight + ")."); return; }
                t.ranks.put(name, new Rank(name, w));
                plugin.towns().save(t);
                Text.msg(p, "&7Created role &f" + name + "&7. Give it permissions with /ages rank perm.");
            }
            case "delete" -> {
                Rank r = a.length > 2 ? t.ranks.get(a[2].toLowerCase()) : null;
                if (r == null) { Text.msg(p, "&cUnknown role."); return; }
                if (r.weight >= mine.weight) { Text.msg(p, "&cYou can only delete roles below yours."); return; }
                if (t.members.containsValue(r.name)) { Text.msg(p, "&cMembers still hold that role."); return; }
                if (r.name.equals(gov.defaultRole) || r.name.equals(gov.leaderRole)) { Text.msg(p, "&cThat role is required by your government."); return; }
                t.ranks.remove(r.name);
                plugin.towns().save(t);
                Text.msg(p, "&7Deleted role " + r.name + ".");
            }
            case "perm" -> {
                if (a.length < 5) { Text.msg(p, "&cUsage: /ages rank perm <role> <PERMISSION> <true|false>"); return; }
                Rank r = t.ranks.get(a[2].toLowerCase());
                Perm perm = Perm.parse(a[3]);
                if (r == null || perm == null) { Text.msg(p, "&cUnknown role or permission."); return; }
                if (r.weight >= mine.weight) { Text.msg(p, "&cYou can only edit roles below yours."); return; }
                if (perm.ownerOnly && !t.isOwner(me)) { Text.msg(p, "&cOnly the technical owner can grant " + perm + "."); return; }
                if (!perm.ownerOnly && !mine.perms.contains(perm)) { Text.msg(p, "&cYou cannot grant a permission you do not have."); return; }
                if (Boolean.parseBoolean(a[4])) r.perms.add(perm); else r.perms.remove(perm);
                plugin.towns().save(t);
                Text.msg(p, "&7" + perm + " is now " + (r.perms.contains(perm) ? "&aenabled" : "&cdisabled") + " &7for " + r.name + ".");
            }
            default -> Text.msg(p, "&cUnknown role command.");
        }
    }

    private static int parseInt(String s, int def) {
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return def; }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        Registries reg = plugin.reg();
        if (a.length == 1) out.addAll(List.of("menu", "help", "info", "buildings", "logistics", "treasury", "invite", "accept", "leave", "kick", "rank", "contribute",
                "withdraw", "convert", "government", "economy", "policy", "vote", "leader", "owner", "disband", "core", "give", "reload"));
        else if (a.length == 2) {
            switch (a[0].toLowerCase()) {
                case "give" -> out.addAll(reg.buildings.keySet());
                case "rank", "role" -> out.addAll(List.of("list", "create", "delete", "perm", "set"));
                case "contribute" -> out.addAll(List.of("hand", "all", "money"));
                case "government", "gov", "economy", "econ" -> out.addAll(List.of("list", "set"));
                case "policy" -> out.addAll(reg.policies.keySet());
                case "owner" -> out.add("transfer");
                default -> { }
            }
        } else if (a.length == 3) {
            switch (a[0].toLowerCase()) {
                case "government", "gov" -> out.addAll(reg.governments.keySet());
                case "economy", "econ" -> out.addAll(reg.economies.keySet());
                default -> { }
            }
        } else if (a.length == 4 && a[0].equalsIgnoreCase("rank") && a[1].equalsIgnoreCase("perm")) {
            for (Perm p : Perm.values()) out.add(p.name());
        } else if (a.length == 5 && a[1].equalsIgnoreCase("perm")) out.addAll(List.of("true", "false"));
        String last = a[a.length - 1].toLowerCase();
        return out.stream().filter(x -> x.toLowerCase().startsWith(last)).sorted().collect(Collectors.toList());
    }
}
