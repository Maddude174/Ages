package dev.ages;

import dev.ages.command.AgesCommand;
import dev.ages.config.BuildingDef;
import dev.ages.config.Registries;
import dev.ages.gui.BuildingMenu;
import dev.ages.gui.CivMenu;
import dev.ages.gui.MenuListener;
import dev.ages.gui.ShopMenu;
import dev.ages.hook.Eco;
import dev.ages.hook.VaultEco;
import dev.ages.item.Items;
import dev.ages.listener.CoreListener;
import dev.ages.listener.TownListener;
import dev.ages.listener.VillagerListener;
import dev.ages.manager.*;
import dev.ages.model.Town;
import dev.ages.storage.Database;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.SQLException;

public final class AgesPlugin extends JavaPlugin {
    private volatile Registries reg;
    private Database db;
    private TownManager towns;
    private BuildingManager buildings;
    private Finance finance;
    private Governance governance;
    private Limits limits;
    private Progress progress;
    private TrackedEntities tracked;
    private Production production;
    private Logistics logistics;
    private ShopMenu shop;
    private BuildingMenu buildingMenu;
    private CivMenu civMenu;
    private Eco eco;

    public Registries reg() { return reg; }
    public Database db() { return db; }
    public TownManager towns() { return towns; }
    public BuildingManager buildings() { return buildings; }
    public Finance finance() { return finance; }
    public Governance governance() { return governance; }
    public Limits limits() { return limits; }
    public Progress progress() { return progress; }
    public TrackedEntities tracked() { return tracked; }
    public Production production() { return production; }
    public Logistics logistics() { return logistics; }
    public ShopMenu shop() { return shop; }
    public BuildingMenu buildingMenu() { return buildingMenu; }
    public CivMenu civMenu() { return civMenu; }

    /** The plugin jar (JavaPlugin#getFile is protected). */
    File pluginFile() { return getFile(); }

    /** Vault is a soft dependency; its economy may register after we enable, so resolve lazily. */
    public Eco eco() {
        if (eco == null && getServer().getPluginManager().getPlugin("Vault") != null) {
            try { eco = VaultEco.create(); } catch (Throwable ignored) { }
        }
        return eco;
    }

    @Override
    public void onEnable() {
        Items.init(this);
        DefaultsSync.run(this);

        Registries r = Registries.load(getDataFolder());
        report(r);
        if (!r.errors.isEmpty()) {
            getLogger().severe("The plugin cannot start: fix the error(s) above and restart.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        reg = r;

        try {
            db = new Database(new File(getDataFolder(), "ages.db"), getLogger());
        } catch (SQLException e) {
            getLogger().severe("Could not open database: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        tracked = new TrackedEntities(this);
        towns = new TownManager(this);
        governance = new Governance(this);
        finance = new Finance(this);
        limits = new Limits(this);
        progress = new Progress(this);
        buildings = new BuildingManager(this);
        production = new Production(this);
        logistics = new Logistics(this);
        shop = new ShopMenu(this);
        buildingMenu = new BuildingMenu(this);
        civMenu = new CivMenu(this);

        tracked.load(db.loadTracked());
        towns.load(db.loadAll(reg, reg.settings.ledgerLoad));
        for (Town t : towns.all()) governance.migrateLegacy(t);
        production.initAll();

        Bukkit.getPluginManager().registerEvents(new CoreListener(this), this);
        Bukkit.getPluginManager().registerEvents(new TownListener(this), this);
        Bukkit.getPluginManager().registerEvents(new VillagerListener(this), this);
        Bukkit.getPluginManager().registerEvents(new MenuListener(this), this);
        var cmd = new AgesCommand(this);
        getCommand("ages").setExecutor(cmd);
        getCommand("ages").setTabCompleter(cmd);
        Bukkit.getScheduler().runTaskTimer(this, production, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, logistics, 100L, Math.max(2, reg.settings.logisticsIntervalSeconds) * 20L);
        registerRecipe();

        getLogger().info("Loaded " + reg.ages.size() + " ages, " + reg.buildings.size() + " buildings, " + reg.governments.size() + " governments, "
                + reg.economies.size() + " economies, " + reg.policies.size() + " policies, " + towns.all().size() + " civilizations.");
    }

    @Override
    public void onDisable() {
        if (towns != null) towns.flush();
        if (db != null) db.close();
    }

    private void report(Registries r) {
        for (String n : r.notes) getLogger().info(n);
        for (String s : r.skipped) getLogger().warning(s);
        for (String e : r.errors) getLogger().severe(e);
        if (!r.skipped.isEmpty()) getLogger().warning(r.skipped.stream().filter(s -> s.startsWith("  ->")).count() + " definition(s) were skipped because of the errors above. Everything else loaded.");
    }

    /** Re-read all config. On a fatal error the running config is left untouched; skipped definitions are reported. */
    public boolean reloadAll(CommandSender who) {
        Registries r = Registries.load(getDataFolder());
        report(r);
        if (!r.errors.isEmpty()) {
            who.sendMessage("Reload failed, keeping the old configuration:");
            r.errors.stream().limit(8).forEach(who::sendMessage);
            return false;
        }
        reg = r;
        towns.reboxAll();
        towns.recomputeAll();
        production.rescheduleMissing();
        if (!r.skipped.isEmpty()) who.sendMessage("Reloaded, but " + r.skipped.stream().filter(s -> s.startsWith("  ->")).count() + " definition(s) were skipped: see the console for details.");
        return true;
    }

    /** The founding core item can be crafted: shapeless, ingredients from settings.yml. */
    private void registerRecipe() {
        BuildingDef f = reg.foundingBuilding();
        if (!reg.settings.recipeEnabled || f == null) return;
        ShapelessRecipe rec = new ShapelessRecipe(new NamespacedKey(this, "founding_core"), Items.core(f));
        reg.settings.recipe.forEach((m, n) -> rec.addIngredient(n, m));
        getServer().addRecipe(rec);
    }
}
