package dev.ages.hook;

import org.bukkit.OfflinePlayer;

/** Thin economy interface so Vault stays a soft dependency. */
public interface Eco {
    double balance(OfflinePlayer p);
    boolean has(OfflinePlayer p, double amount);
    boolean take(OfflinePlayer p, double amount);
    void give(OfflinePlayer p, double amount);
    String fmt(double amount);
}
