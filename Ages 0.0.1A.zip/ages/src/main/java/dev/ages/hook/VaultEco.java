package dev.ages.hook;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

/** Only ever loaded when Vault is present (see AgesPlugin#eco), so a missing Vault never breaks the plugin. */
public final class VaultEco implements Eco {
    private final Economy econ;

    private VaultEco(Economy econ) { this.econ = econ; }

    public static Eco create() {
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : new VaultEco(rsp.getProvider());
    }

    @Override public double balance(OfflinePlayer p) { return econ.getBalance(p); }
    @Override public boolean has(OfflinePlayer p, double amount) { return econ.has(p, amount); }
    @Override public boolean take(OfflinePlayer p, double amount) { return econ.withdrawPlayer(p, amount).transactionSuccess(); }
    @Override public void give(OfflinePlayer p, double amount) { econ.depositPlayer(p, amount); }
    @Override public String fmt(double amount) { return econ.format(amount); }
}
