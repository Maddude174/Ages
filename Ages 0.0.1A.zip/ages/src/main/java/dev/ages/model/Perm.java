package dev.ages.model;

/**
 * Action-based permissions. Roles hold sets of these. The two owner-only permissions are always held by the
 * technical owner and are never included in a role's "ALL"; a government may still grant them explicitly.
 */
public enum Perm {
    // world
    BUILD("Place and break blocks in civilization land", false),
    CONTAINERS("Open chests, barrels and furnaces", false),
    INTERACT("Use doors, buttons and levers", false),
    // buildings
    USE_SHOP("Browse the building catalogue", false),
    PURCHASE_BUILDINGS("Buy building cores", false),
    PLACE_BUILDINGS("Place building cores", false),
    UPGRADE_BUILDINGS("Upgrade buildings", false),
    REMOVE_BUILDINGS("Remove or relocate your own building cores", false),
    MANAGE_BUILDINGS("Use, upgrade and remove other members' buildings", false),
    ADVANCE_AGE("Buy and place the next age's core", false),
    // finances
    CONTRIBUTE("Contribute materials or money", false),
    SPEND_POINTS("Spend shared resource points", false),
    SPEND_TREASURY("Spend shared treasury money on development", false),
    WITHDRAW_TREASURY("Withdraw money from the treasury", false),
    VIEW_FINANCES("View the treasury and its history", false),
    COLLECT_TAXES("Collect income from buildings paid out to their owner", false),
    // people
    INVITE("Invite players", false),
    KICK("Remove members", false),
    MANAGE_RANKS("Create and edit roles", false),
    APPOINT_OFFICIALS("Assign roles and appoint the leader", false),
    VOTE("Vote in leadership elections", false),
    // governance
    CHANGE_SETTINGS("Change civilization settings", false),
    CHANGE_GOVERNMENT("Change the government type", false),
    CHANGE_ECONOMY("Change the economic system", false),
    MANAGE_POLICIES("Adopt and revoke policies", false),
    // owner-only
    DISBAND("Disband the civilization", true),
    TRANSFER_OWNERSHIP("Transfer technical ownership", true);

    public final String description;
    public final boolean ownerOnly;

    Perm(String description, boolean ownerOnly) {
        this.description = description;
        this.ownerOnly = ownerOnly;
    }

    public static Perm parse(String s) {
        try { return valueOf(s.toUpperCase()); } catch (IllegalArgumentException e) { return null; }
    }
}
