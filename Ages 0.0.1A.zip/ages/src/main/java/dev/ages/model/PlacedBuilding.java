package dev.ages.model;

import java.util.UUID;

/** A registered building: owned by a player, belonging to a civilization. */
public final class PlacedBuilding {
    public final UUID id;
    /** Canonical building id (aliases from renamed buildings are resolved when loading). */
    public String defId;
    public final UUID townId;
    public UUID owner;
    public final BlockPos core;
    public BlockPos input;
    public BlockPos output;
    public boolean damaged;
    /** Legacy owner-paid income (functions with payout: owner). */
    public double stored;
    /** 1 = base. Upgrades raise it; resolve the definition with Registries#effective. */
    public int level = 1;
    /** Next production time as an epoch-millis timestamp. Persisted, so timers survive restarts. 0 = not scheduled yet. */
    public long nextRun;
    /** Selected recipe id for buildings in "selected" mode (null = first). */
    public String recipe;

    public int minX, minY, minZ, maxX, maxY, maxZ;

    // runtime only
    public String lastStatus = "";

    public PlacedBuilding(UUID id, String defId, UUID townId, UUID owner, BlockPos core) {
        this.id = id;
        this.defId = defId;
        this.townId = townId;
        this.owner = owner;
        this.core = core;
    }

    public void setBox(int rx, int rz, int up, int down) {
        minX = core.x() - rx; maxX = core.x() + rx;
        minZ = core.z() - rz; maxZ = core.z() + rz;
        minY = core.y() - down; maxY = core.y() + up;
    }

    public boolean contains(BlockPos p) {
        return p.world().equals(core.world())
                && p.x() >= minX && p.x() <= maxX
                && p.y() >= minY && p.y() <= maxY
                && p.z() >= minZ && p.z() <= maxZ;
    }
}
