package dev.ages.model;

import java.util.EnumSet;
import java.util.Set;

public final class Rank {
    public final String name;
    /** Display title (e.g. "Chief"). Defaults to the name. */
    public String title;
    /** Higher weight outranks lower. You can only manage ranks and members below your own weight. */
    public int weight;
    public final Set<Perm> perms = EnumSet.noneOf(Perm.class);

    public Rank(String name, int weight) {
        this.name = name;
        this.title = name;
        this.weight = weight;
    }

    public Rank copy() {
        Rank r = new Rank(name, weight);
        r.title = title;
        r.perms.addAll(perms);
        return r;
    }
}
