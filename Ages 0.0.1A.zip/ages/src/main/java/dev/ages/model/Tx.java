package dev.ages.model;

import java.util.UUID;

/** One line of the civilization ledger. Production income is coalesced into hourly lines so the history stays readable. */
public final class Tx {
    public final long id;
    public long ts;
    public final UUID actor;      // null = the civilization itself (production, taxes)
    public final String type;     // CONTRIBUTE_ITEMS, CONTRIBUTE_MONEY, WITHDRAW, PURCHASE, UPGRADE, PRODUCTION, TAX, CONVERT, POLICY, GOVERNMENT, ...
    public final String currency; // POINTS | MONEY
    public double amount;         // signed
    public double balance;        // balance after
    public final String note;

    public Tx(long id, long ts, UUID actor, String type, String currency, double amount, double balance, String note) {
        this.id = id; this.ts = ts; this.actor = actor; this.type = type; this.currency = currency;
        this.amount = amount; this.balance = balance; this.note = note == null ? "" : note;
    }
}
