package dev.ages.model;

import java.util.*;

/** A civilization. Kept as "Town" internally for compatibility with stored data. */
public final class Town {
    public final UUID id;
    public String name;
    public String ageId;
    /** Fixed anchor of the territory (where the first core was placed). */
    public final BlockPos center;
    /** Core block of the CURRENT age: the shop and the respawn anchor. Older cores are retired. */
    public BlockPos core;
    public final long created;

    /** Technical owner: can disband and transfer ownership. NOT necessarily the political leader. */
    public UUID owner;
    /** Political leader: holds the government's leader role. Chosen according to the government type. */
    public UUID leader;
    public String govId;
    public String econId;
    /** Shared resource points: the plugin-specific currency for buildings and ages. */
    public double points;
    /** Shared treasury money (separate from players' personal Vault funds). */
    public double money;
    public long govChangedAt, econChangedAt;

    public final Set<String> policies = new LinkedHashSet<>();
    public final Map<UUID, UUID> votes = new HashMap<>();                 // voter -> candidate
    public final Map<UUID, double[]> contributions = new HashMap<>();     // player -> {points, money}
    public final Deque<Tx> ledger = new ArrayDeque<>();                   // newest first

    public final Map<UUID, String> members = new LinkedHashMap<>();
    public final Map<String, Rank> ranks = new LinkedHashMap<>();
    public final List<PlacedBuilding> buildings = new ArrayList<>();

    // runtime only
    public final Set<UUID> invites = new HashSet<>();
    public int villagers;

    public Town(UUID id, String name, String ageId, BlockPos center, long created) {
        this.id = id;
        this.name = name;
        this.ageId = ageId;
        this.center = center;
        this.core = center;
        this.created = created;
    }

    public boolean isOwner(UUID p) { return p != null && p.equals(owner); }

    public Rank rankOf(UUID player) {
        String r = members.get(player);
        return r == null ? null : ranks.get(r);
    }

    /** Owner-only actions are always allowed for the owner; everything else comes from the player's role. */
    public boolean can(UUID player, Perm perm) {
        if (perm.ownerOnly && isOwner(player)) return true;
        Rank r = rankOf(player);
        return r != null && r.perms.contains(perm);
    }

    public int weightOf(UUID player) {
        Rank r = rankOf(player);
        return r == null ? -1 : r.weight;
    }

    public int population(boolean players, boolean villagerCount) {
        return (players ? members.size() : 0) + (villagerCount ? villagers : 0);
    }

    /** Working (undamaged) buildings of a type at or above a level. */
    public int count(String defId, int minLevel) {
        int n = 0;
        for (PlacedBuilding b : buildings) if (b.defId.equals(defId) && !b.damaged && b.level >= minLevel) n++;
        return n;
    }

    public int count(String defId) { return count(defId, 1); }

    /** All buildings of a type, including damaged. Used for limits. */
    public int countAll(String defId) {
        int n = 0;
        for (PlacedBuilding b : buildings) if (b.defId.equals(defId)) n++;
        return n;
    }

    public int countOwned(UUID owner, String defId) {
        int n = 0;
        for (PlacedBuilding b : buildings) if (b.defId.equals(defId) && b.owner.equals(owner)) n++;
        return n;
    }
}
