package dev.ages.model;

import java.util.UUID;

/** A plugin-spawned entity (villager, golem) and the building slot it occupies. Persisted so restarts never duplicate it. */
public final class Tracked {
    public final UUID entity;
    public UUID building;       // null = unassigned (its building was removed)
    public final UUID town;
    public final String type;
    public String world;
    public int cx, cz;          // last known chunk: used to tell "unloaded" from "gone"

    public Tracked(UUID entity, UUID building, UUID town, String type, String world, int cx, int cz) {
        this.entity = entity; this.building = building; this.town = town; this.type = type;
        this.world = world; this.cx = cx; this.cz = cz;
    }
}
