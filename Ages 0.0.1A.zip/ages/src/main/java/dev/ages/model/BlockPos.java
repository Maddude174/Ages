package dev.ages.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;

/** World-name based block position: safe to store and use as a map key. */
public record BlockPos(String world, int x, int y, int z) {
    public static BlockPos of(Block b) { return new BlockPos(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()); }
    public static BlockPos of(Location l) { return new BlockPos(l.getWorld().getName(), l.getBlockX(), l.getBlockY(), l.getBlockZ()); }

    public ChunkKey chunk() { return new ChunkKey(world, x >> 4, z >> 4); }

    public Location toLocation() {
        World w = Bukkit.getWorld(world);
        return w == null ? null : new Location(w, x, y, z);
    }

    public Block block() {
        World w = Bukkit.getWorld(world);
        return w == null ? null : w.getBlockAt(x, y, z);
    }
}
