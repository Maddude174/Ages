package dev.ages.model;

public record ChunkKey(String world, int x, int z) {}
