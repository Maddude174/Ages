package dev.ages.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;

import java.util.Arrays;
import java.util.stream.Collectors;

public final class Text {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private Text() {}

    /** Colour-coded ('&6') text with italics disabled (items default to italic otherwise). */
    public static Component c(String s) { return LEGACY.deserialize(s).decoration(TextDecoration.ITALIC, false); }

    /** Strip colour codes. */
    public static String plain(String legacy) { return PlainTextComponentSerializer.plainText().serialize(LEGACY.deserialize(legacy)); }

    public static void msg(CommandSender to, String m) { to.sendMessage(c("&6[Ages] &7" + m)); }

    public static String pretty(String id) {
        return Arrays.stream(id.toLowerCase().split("_"))
                .filter(w -> !w.isEmpty())
                .map(w -> Character.toUpperCase(w.charAt(0)) + w.substring(1))
                .collect(Collectors.joining(" "));
    }

    public static String pretty(Material m) { return pretty(m.name()); }

    public static String num(double v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.format("%.1f", v); }

    /** "2m 5s" style remaining time from milliseconds. */
    public static String remaining(long ms) {
        if (ms <= 0) return "now";
        long s = (ms + 999) / 1000;
        if (s >= 3600) return (s / 3600) + "h " + ((s % 3600) / 60) + "m";
        if (s >= 60) return (s / 60) + "m " + (s % 60) + "s";
        return s + "s";
    }

    public static String duration(int s) {
        if (s >= 3600 && s % 3600 == 0) return (s / 3600) + "h";
        if (s >= 60 && s % 60 == 0) return (s / 60) + "m";
        if (s >= 60) return (s / 60) + "m " + (s % 60) + "s";
        return s + "s";
    }
}
