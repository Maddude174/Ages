package dev.ages.util;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class InvUtil {
    private InvUtil() {}

    /** Count of a material, ignoring items with custom meta (renamed, enchanted, damaged). Used for shop costs. */
    public static int countPlain(Inventory inv, Material m) {
        int n = 0;
        for (ItemStack s : inv.getStorageContents()) if (s != null && s.getType() == m && !s.hasItemMeta()) n += s.getAmount();
        return n;
    }

    public static void removePlain(Inventory inv, Material m, int amount) { inv.removeItem(new ItemStack(m, amount)); }

    public static int count(Inventory inv, Set<Material> mats) {
        int n = 0;
        for (ItemStack s : inv.getContents()) if (s != null && mats.contains(s.getType())) n += s.getAmount();
        return n;
    }

    public static int count(Inventory inv, Material m) {
        int n = 0;
        for (ItemStack s : inv.getContents()) if (s != null && s.getType() == m) n += s.getAmount();
        return n;
    }

    /** Move up to max items of one material between inventories, keeping item meta (tool damage etc.). Returns how many moved. */
    public static int move(Inventory from, Inventory to, Material m, int max) {
        int moved = 0;
        ItemStack[] c = from.getContents();
        for (int i = 0; i < c.length && moved < max; i++) {
            ItemStack s = c[i];
            if (s == null || s.getType() != m) continue;
            int take = Math.min(s.getAmount(), max - moved);
            ItemStack part = s.clone();
            part.setAmount(take);
            var left = to.addItem(part);
            int rest = left.isEmpty() ? 0 : left.values().iterator().next().getAmount();
            int done = take - rest;
            if (done <= 0) break; // destination is full for this item
            moved += done;
            if (done == s.getAmount()) {
                from.setItem(i, null);
            } else {
                s.setAmount(s.getAmount() - done);
                from.setItem(i, s);
            }
        }
        return moved;
    }

    public static boolean take(Inventory inv, Set<Material> mats, int amount) {
        if (count(inv, mats) < amount) return false;
        int left = amount;
        ItemStack[] c = inv.getContents();
        for (int i = 0; i < c.length && left > 0; i++) {
            ItemStack s = c[i];
            if (s == null || !mats.contains(s.getType())) continue;
            int t = Math.min(left, s.getAmount());
            left -= t;
            if (t == s.getAmount()) {
                inv.setItem(i, null);
            } else {
                s.setAmount(s.getAmount() - t);
                inv.setItem(i, s);
            }
        }
        return true;
    }

    private static boolean isTool(ItemStack s, Set<Material> mats) {
        return s != null && mats.contains(s.getType()) && s.getType().getMaxDurability() > 0 && s.getItemMeta() instanceof Damageable;
    }

    public static boolean hasTool(Inventory inv, Set<Material> mats) {
        for (ItemStack s : inv.getContents()) if (isTool(s, mats)) return true;
        return false;
    }

    /** Wear down the first matching tool. The tool is destroyed when its durability runs out. */
    public static boolean damage(Inventory inv, Set<Material> mats, int amount) {
        ItemStack[] c = inv.getContents();
        for (int i = 0; i < c.length; i++) {
            ItemStack s = c[i];
            if (!isTool(s, mats)) continue;
            Damageable meta = (Damageable) s.getItemMeta();
            meta.setDamage(meta.getDamage() + amount);
            if (meta.getDamage() >= s.getType().getMaxDurability()) {
                inv.setItem(i, null);
            } else {
                s.setItemMeta(meta);
                inv.setItem(i, s);
            }
            return true;
        }
        return false;
    }

    /** Would these stacks fit? Simulated on a scratch inventory so nothing is half-added. */
    public static boolean fits(Inventory inv, List<ItemStack> stacks) {
        int size = inv.getSize();
        if (size % 9 != 0) return false;
        Inventory tmp = Bukkit.createInventory(null, size);
        ItemStack[] copy = inv.getContents();
        for (int i = 0; i < copy.length; i++) tmp.setItem(i, copy[i] == null ? null : copy[i].clone());
        List<ItemStack> clones = new ArrayList<>();
        for (ItemStack s : stacks) clones.add(s.clone());
        return tmp.addItem(clones.toArray(new ItemStack[0])).isEmpty();
    }

    public static void give(Player p, ItemStack item) {
        var left = p.getInventory().addItem(item);
        for (ItemStack l : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), l);
    }
}
