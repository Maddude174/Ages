package dev.ages.util;

import org.bukkit.Material;
import org.bukkit.Tag;

/** Which block types hold an inventory. Used for container cores, protection and validation. */
public final class Containers {
    private Containers() {}

    public static boolean isContainer(Material m) {
        return switch (m) {
            case CHEST, TRAPPED_CHEST, BARREL, FURNACE, BLAST_FURNACE, SMOKER, HOPPER, DROPPER, DISPENSER, BREWING_STAND -> true;
            default -> Tag.SHULKER_BOXES.isTagged(m);
        };
    }

    /** Containers with a plain slot grid that production and logistics can safely fill (no furnace-style slots). */
    public static boolean isStorage(Material m) {
        return m == Material.CHEST || m == Material.TRAPPED_CHEST || m == Material.BARREL || Tag.SHULKER_BOXES.isTagged(m);
    }
}
