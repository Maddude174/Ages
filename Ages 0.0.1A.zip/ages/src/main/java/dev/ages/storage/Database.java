package dev.ages.storage;

import dev.ages.config.BuildingDef;
import dev.ages.config.Registries;
import dev.ages.model.*;

import java.io.File;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * SQLite storage. Writes run on one background thread; callers snapshot their data first so the main
 * thread is never blocked by disk IO. The only synchronous write is the age handoff, which must be able to fail
 * and roll back. Paper bundles the sqlite driver. Old databases are migrated in place (columns/tables added).
 */
public final class Database {
    private final Connection conn;
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> new Thread(r, "Ages-DB"));
    private final Logger log;
    private final AtomicLong txIds = new AtomicLong(1);

    private interface Sql { void run() throws SQLException; }

    public Database(File file, Logger log) throws SQLException {
        this.log = log;
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite driver not found", e);
        }
        conn = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement s = conn.createStatement()) {
            s.execute("PRAGMA journal_mode=WAL");
            s.execute("CREATE TABLE IF NOT EXISTS towns (id TEXT PRIMARY KEY, name TEXT NOT NULL, age TEXT NOT NULL, created INTEGER,"
                    + " c_world TEXT, c_x INTEGER, c_y INTEGER, c_z INTEGER, k_world TEXT, k_x INTEGER, k_y INTEGER, k_z INTEGER)");
            s.execute("CREATE TABLE IF NOT EXISTS members (town TEXT, player TEXT, rank TEXT, PRIMARY KEY(town, player))");
            s.execute("CREATE TABLE IF NOT EXISTS ranks (town TEXT, name TEXT, weight INTEGER, perms TEXT, PRIMARY KEY(town, name))");
            s.execute("CREATE TABLE IF NOT EXISTS buildings (id TEXT PRIMARY KEY, town TEXT, def TEXT, owner TEXT, world TEXT,"
                    + " x INTEGER, y INTEGER, z INTEGER, has_in INTEGER, in_x INTEGER, in_y INTEGER, in_z INTEGER,"
                    + " has_out INTEGER, out_x INTEGER, out_y INTEGER, out_z INTEGER, damaged INTEGER, stored REAL)");
            s.execute("CREATE TABLE IF NOT EXISTS policies (town TEXT, policy TEXT, PRIMARY KEY(town, policy))");
            s.execute("CREATE TABLE IF NOT EXISTS votes (town TEXT, voter TEXT, candidate TEXT, PRIMARY KEY(town, voter))");
            s.execute("CREATE TABLE IF NOT EXISTS contributions (town TEXT, player TEXT, points REAL, money REAL, PRIMARY KEY(town, player))");
            s.execute("CREATE TABLE IF NOT EXISTS ledger (id INTEGER PRIMARY KEY, town TEXT, ts INTEGER, actor TEXT, type TEXT,"
                    + " currency TEXT, amount REAL, balance REAL, note TEXT)");
            s.execute("CREATE TABLE IF NOT EXISTS tracked (entity TEXT PRIMARY KEY, building TEXT, town TEXT, type TEXT, world TEXT, cx INTEGER, cz INTEGER)");
            // migrations from earlier versions
            for (String alter : new String[]{
                    "ALTER TABLE buildings ADD COLUMN level INTEGER DEFAULT 1",
                    "ALTER TABLE buildings ADD COLUMN next_run INTEGER DEFAULT 0",
                    "ALTER TABLE buildings ADD COLUMN recipe TEXT",
                    "ALTER TABLE towns ADD COLUMN owner TEXT",
                    "ALTER TABLE towns ADD COLUMN leader TEXT",
                    "ALTER TABLE towns ADD COLUMN gov TEXT",
                    "ALTER TABLE towns ADD COLUMN econ TEXT",
                    "ALTER TABLE towns ADD COLUMN points REAL DEFAULT 0",
                    "ALTER TABLE towns ADD COLUMN money REAL DEFAULT 0",
                    "ALTER TABLE towns ADD COLUMN gov_changed INTEGER DEFAULT 0",
                    "ALTER TABLE towns ADD COLUMN econ_changed INTEGER DEFAULT 0"}) {
                try { s.execute(alter); } catch (SQLException ignored) { /* column already exists */ }
            }
            try (ResultSet rs = s.executeQuery("SELECT COALESCE(MAX(id), 0) FROM ledger")) {
                if (rs.next()) txIds.set(rs.getLong(1) + 1);
            }
        }
    }

    public long nextTxId() { return txIds.getAndIncrement(); }

    public void close() {
        io.shutdown();
        try { io.awaitTermination(15, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        try { conn.close(); } catch (SQLException ignored) {}
    }

    // ------------------------------------------------------------------ load

    public List<Town> loadAll(Registries reg, int ledgerPerTown) {
        try {
            return io.submit(() -> load(reg, ledgerPerTown)).get();
        } catch (Exception e) {
            throw new IllegalStateException("Failed to load civilizations", e);
        }
    }

    private static UUID uuid(String s) { return s == null || s.isBlank() ? null : UUID.fromString(s); }

    private List<Town> load(Registries reg, int ledgerPerTown) throws SQLException {
        Map<UUID, Town> map = new LinkedHashMap<>();
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM towns")) {
            while (rs.next()) {
                String age = reg.canonicalAge(rs.getString("age"));
                Town t = new Town(UUID.fromString(rs.getString("id")), rs.getString("name"), age,
                        new BlockPos(rs.getString("c_world"), rs.getInt("c_x"), rs.getInt("c_y"), rs.getInt("c_z")), rs.getLong("created"));
                t.core = new BlockPos(rs.getString("k_world"), rs.getInt("k_x"), rs.getInt("k_y"), rs.getInt("k_z"));
                t.owner = uuid(rs.getString("owner"));
                t.leader = uuid(rs.getString("leader"));
                t.govId = rs.getString("gov");
                t.econId = rs.getString("econ");
                t.points = rs.getDouble("points");
                t.money = rs.getDouble("money");
                t.govChangedAt = rs.getLong("gov_changed");
                t.econChangedAt = rs.getLong("econ_changed");
                map.put(t.id, t);
            }
        }
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM members")) {
            while (rs.next()) {
                Town t = map.get(UUID.fromString(rs.getString("town")));
                if (t != null) t.members.put(UUID.fromString(rs.getString("player")), rs.getString("rank"));
            }
        }
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM ranks")) {
            while (rs.next()) {
                Town t = map.get(UUID.fromString(rs.getString("town")));
                if (t == null) continue;
                Rank r = new Rank(rs.getString("name"), rs.getInt("weight"));
                for (String p : rs.getString("perms").split(",")) {
                    Perm perm = Perm.parse(p.trim());
                    if (perm != null) r.perms.add(perm);   // permissions removed from the plugin (e.g. war/diplomacy) are dropped
                }
                t.ranks.put(r.name, r);
            }
        }
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM buildings")) {
            while (rs.next()) {
                Town t = map.get(UUID.fromString(rs.getString("town")));
                if (t == null) continue;
                String w = rs.getString("world");
                PlacedBuilding b = new PlacedBuilding(UUID.fromString(rs.getString("id")), reg.canonicalBuilding(rs.getString("def")), t.id,
                        UUID.fromString(rs.getString("owner")), new BlockPos(w, rs.getInt("x"), rs.getInt("y"), rs.getInt("z")));
                if (rs.getInt("has_in") == 1) b.input = new BlockPos(w, rs.getInt("in_x"), rs.getInt("in_y"), rs.getInt("in_z"));
                if (rs.getInt("has_out") == 1) b.output = new BlockPos(w, rs.getInt("out_x"), rs.getInt("out_y"), rs.getInt("out_z"));
                b.damaged = rs.getInt("damaged") == 1;
                b.stored = rs.getDouble("stored");
                b.level = Math.max(1, rs.getInt("level"));
                b.nextRun = rs.getLong("next_run");
                b.recipe = rs.getString("recipe");
                BuildingDef d = reg.effective(b);
                if (d != null) b.setBox(d.rx, d.rz, d.up, d.down); else b.setBox(0, 0, 0, 0);
                t.buildings.add(b);
            }
        }
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM policies")) {
            while (rs.next()) { Town t = map.get(UUID.fromString(rs.getString("town"))); if (t != null) t.policies.add(rs.getString("policy")); }
        }
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM votes")) {
            while (rs.next()) {
                Town t = map.get(UUID.fromString(rs.getString("town")));
                if (t != null) t.votes.put(UUID.fromString(rs.getString("voter")), UUID.fromString(rs.getString("candidate")));
            }
        }
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM contributions")) {
            while (rs.next()) {
                Town t = map.get(UUID.fromString(rs.getString("town")));
                if (t != null) t.contributions.put(UUID.fromString(rs.getString("player")), new double[]{rs.getDouble("points"), rs.getDouble("money")});
            }
        }
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM ledger ORDER BY id DESC LIMIT 20000")) {
            while (rs.next()) {
                Town t = map.get(UUID.fromString(rs.getString("town")));
                if (t == null || t.ledger.size() >= ledgerPerTown) continue;
                t.ledger.addLast(new Tx(rs.getLong("id"), rs.getLong("ts"), uuid(rs.getString("actor")), rs.getString("type"),
                        rs.getString("currency"), rs.getDouble("amount"), rs.getDouble("balance"), rs.getString("note")));
            }
        }
        return new ArrayList<>(map.values());
    }

    public List<Tracked> loadTracked() {
        try {
            return io.submit(() -> {
                List<Tracked> out = new ArrayList<>();
                try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM tracked")) {
                    while (rs.next())
                        out.add(new Tracked(UUID.fromString(rs.getString("entity")), uuid(rs.getString("building")), UUID.fromString(rs.getString("town")),
                                rs.getString("type"), rs.getString("world"), rs.getInt("cx"), rs.getInt("cz")));
                }
                return out;
            }).get();
        } catch (Exception e) {
            throw new IllegalStateException("Failed to load tracked entities", e);
        }
    }

    // ------------------------------------------------------------------ snapshots

    private record TSnap(String id, String name, String age, long created, BlockPos c, BlockPos k, String owner, String leader, String gov, String econ,
                         double points, double money, long govChanged, long econChanged,
                         List<String[]> members, List<Object[]> ranks, List<String> policies, List<String[]> votes) {}

    private record BSnap(String id, String town, String def, String owner, BlockPos core, BlockPos in, BlockPos out,
                         boolean damaged, double stored, int level, long nextRun, String recipe) {}

    private static String s(UUID u) { return u == null ? null : u.toString(); }

    private TSnap snap(Town t) {
        List<String[]> members = new ArrayList<>();
        t.members.forEach((u, r) -> members.add(new String[]{u.toString(), r}));
        List<Object[]> ranks = new ArrayList<>();
        for (Rank r : t.ranks.values()) {
            StringJoiner j = new StringJoiner(",");
            r.perms.forEach(p -> j.add(p.name()));
            ranks.add(new Object[]{r.name, r.weight, j.toString()});
        }
        List<String[]> votes = new ArrayList<>();
        t.votes.forEach((v, c) -> votes.add(new String[]{v.toString(), c.toString()}));
        return new TSnap(t.id.toString(), t.name, t.ageId, t.created, t.center, t.core, s(t.owner), s(t.leader), t.govId, t.econId,
                t.points, t.money, t.govChangedAt, t.econChangedAt, members, ranks, new ArrayList<>(t.policies), votes);
    }

    private static BSnap snap(PlacedBuilding b) {
        return new BSnap(b.id.toString(), b.townId.toString(), b.defId, b.owner.toString(), b.core, b.input, b.output,
                b.damaged, b.stored, b.level, b.nextRun, b.recipe);
    }

    // ------------------------------------------------------------------ writers (run inside a transaction)

    private void writeTown(TSnap t) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO towns (id,name,age,created,c_world,c_x,c_y,c_z,k_world,k_x,k_y,k_z,"
                + "owner,leader,gov,econ,points,money,gov_changed,econ_changed) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")) {
            ps.setString(1, t.id()); ps.setString(2, t.name()); ps.setString(3, t.age()); ps.setLong(4, t.created());
            ps.setString(5, t.c().world()); ps.setInt(6, t.c().x()); ps.setInt(7, t.c().y()); ps.setInt(8, t.c().z());
            ps.setString(9, t.k().world()); ps.setInt(10, t.k().x()); ps.setInt(11, t.k().y()); ps.setInt(12, t.k().z());
            ps.setString(13, t.owner()); ps.setString(14, t.leader()); ps.setString(15, t.gov()); ps.setString(16, t.econ());
            ps.setDouble(17, t.points()); ps.setDouble(18, t.money()); ps.setLong(19, t.govChanged()); ps.setLong(20, t.econChanged());
            ps.executeUpdate();
        }
        for (String table : new String[]{"members", "ranks", "policies", "votes"}) {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM " + table + " WHERE town=?")) { ps.setString(1, t.id()); ps.executeUpdate(); }
        }
        try (PreparedStatement ps = conn.prepareStatement("INSERT INTO members VALUES (?,?,?)")) {
            for (String[] m : t.members()) { ps.setString(1, t.id()); ps.setString(2, m[0]); ps.setString(3, m[1]); ps.addBatch(); }
            ps.executeBatch();
        }
        try (PreparedStatement ps = conn.prepareStatement("INSERT INTO ranks VALUES (?,?,?,?)")) {
            for (Object[] r : t.ranks()) { ps.setString(1, t.id()); ps.setString(2, (String) r[0]); ps.setInt(3, (Integer) r[1]); ps.setString(4, (String) r[2]); ps.addBatch(); }
            ps.executeBatch();
        }
        try (PreparedStatement ps = conn.prepareStatement("INSERT INTO policies VALUES (?,?)")) {
            for (String p : t.policies()) { ps.setString(1, t.id()); ps.setString(2, p); ps.addBatch(); }
            ps.executeBatch();
        }
        try (PreparedStatement ps = conn.prepareStatement("INSERT INTO votes VALUES (?,?,?)")) {
            for (String[] v : t.votes()) { ps.setString(1, t.id()); ps.setString(2, v[0]); ps.setString(3, v[1]); ps.addBatch(); }
            ps.executeBatch();
        }
    }

    private void writeBuilding(BSnap b) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO buildings (id,town,def,owner,world,x,y,z,has_in,in_x,in_y,in_z,"
                + "has_out,out_x,out_y,out_z,damaged,stored,level,next_run,recipe) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")) {
            BlockPos c = b.core(), in = b.in(), out = b.out();
            ps.setString(1, b.id()); ps.setString(2, b.town()); ps.setString(3, b.def()); ps.setString(4, b.owner());
            ps.setString(5, c.world()); ps.setInt(6, c.x()); ps.setInt(7, c.y()); ps.setInt(8, c.z());
            ps.setInt(9, in == null ? 0 : 1); ps.setInt(10, in == null ? 0 : in.x()); ps.setInt(11, in == null ? 0 : in.y()); ps.setInt(12, in == null ? 0 : in.z());
            ps.setInt(13, out == null ? 0 : 1); ps.setInt(14, out == null ? 0 : out.x()); ps.setInt(15, out == null ? 0 : out.y()); ps.setInt(16, out == null ? 0 : out.z());
            ps.setInt(17, b.damaged() ? 1 : 0); ps.setDouble(18, b.stored()); ps.setInt(19, b.level()); ps.setLong(20, b.nextRun()); ps.setString(21, b.recipe());
            ps.executeUpdate();
        }
    }

    private void tx(Sql sql) throws SQLException {
        try {
            conn.setAutoCommit(false);
            sql.run();
            conn.commit();
        } catch (SQLException | RuntimeException e) {
            try { conn.rollback(); } catch (SQLException ignored) {}
            throw e;
        } finally {
            try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
        }
    }

    private void run(String what, Sql sql) {
        io.execute(() -> {
            try { tx(sql); } catch (SQLException | RuntimeException e) { log.log(Level.SEVERE, "Database error (" + what + ")", e); }
        });
    }

    // ------------------------------------------------------------------ public API

    public void saveTown(Town t) {
        TSnap s = snap(t);
        run("save civilization", () -> writeTown(s));
    }

    /** Lightweight periodic save of balances only (production income). */
    public void saveBalances(Collection<Town> towns) {
        List<Object[]> rows = new ArrayList<>();
        for (Town t : towns) rows.add(new Object[]{t.points, t.money, t.id.toString()});
        run("save balances", () -> {
            try (PreparedStatement ps = conn.prepareStatement("UPDATE towns SET points=?, money=? WHERE id=?")) {
                for (Object[] r : rows) { ps.setDouble(1, (Double) r[0]); ps.setDouble(2, (Double) r[1]); ps.setString(3, (String) r[2]); ps.addBatch(); }
                ps.executeBatch();
            }
        });
    }

    public void saveBuilding(PlacedBuilding b) { saveBuildings(List.of(b)); }

    public void saveBuildings(Collection<PlacedBuilding> list) {
        List<BSnap> snaps = new ArrayList<>();
        for (PlacedBuilding b : list) snaps.add(snap(b));
        if (snaps.isEmpty()) return;
        run("save buildings", () -> { for (BSnap s : snaps) writeBuilding(s); });
    }

    public void deleteBuilding(UUID id) {
        run("delete building", () -> {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM buildings WHERE id=?")) { ps.setString(1, id.toString()); ps.executeUpdate(); }
        });
    }

    public void deleteTown(UUID id) {
        final String s = id.toString();
        run("delete civilization", () -> {
            for (String table : new String[]{"members", "ranks", "buildings", "policies", "votes", "contributions", "ledger", "tracked"}) {
                try (PreparedStatement ps = conn.prepareStatement("DELETE FROM " + table + " WHERE town=?")) { ps.setString(1, s); ps.executeUpdate(); }
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM towns WHERE id=?")) { ps.setString(1, s); ps.executeUpdate(); }
        });
    }

    public void insertTx(UUID town, Tx t) {
        final String tid = town.toString(), actor = s(t.actor);
        final long id = t.id, ts = t.ts;
        final String type = t.type, cur = t.currency, note = t.note;
        final double amount = t.amount, bal = t.balance;
        run("ledger insert", () -> {
            try (PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO ledger (id,town,ts,actor,type,currency,amount,balance,note) VALUES (?,?,?,?,?,?,?,?,?)")) {
                ps.setLong(1, id); ps.setString(2, tid); ps.setLong(3, ts); ps.setString(4, actor); ps.setString(5, type);
                ps.setString(6, cur); ps.setDouble(7, amount); ps.setDouble(8, bal); ps.setString(9, note);
                ps.executeUpdate();
            }
        });
    }

    public void saveContribution(UUID town, UUID player, double points, double money) {
        final String t = town.toString(), p = player.toString();
        run("contribution", () -> {
            try (PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO contributions (town,player,points,money) VALUES (?,?,?,?)")) {
                ps.setString(1, t); ps.setString(2, p); ps.setDouble(3, points); ps.setDouble(4, money);
                ps.executeUpdate();
            }
        });
    }

    public void saveTracked(Tracked e) {
        final String id = e.entity.toString(), b = s(e.building), t = e.town.toString(), type = e.type, w = e.world;
        final int cx = e.cx, cz = e.cz;
        run("tracked save", () -> {
            try (PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO tracked (entity,building,town,type,world,cx,cz) VALUES (?,?,?,?,?,?,?)")) {
                ps.setString(1, id); ps.setString(2, b); ps.setString(3, t); ps.setString(4, type); ps.setString(5, w); ps.setInt(6, cx); ps.setInt(7, cz);
                ps.executeUpdate();
            }
        });
    }

    public void deleteTracked(UUID entity) {
        run("tracked delete", () -> {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM tracked WHERE entity=?")) { ps.setString(1, entity.toString()); ps.executeUpdate(); }
        });
    }

    /**
     * The age handoff / conversion: save the civilization, the NEW building and delete the retired ones in ONE transaction,
     * and wait for the result. Returns false (nothing written) if it fails, so the caller can roll back its in-memory changes.
     */
    public boolean commitHandoff(Town t, PlacedBuilding created, Collection<PlacedBuilding> retired) {
        TSnap ts = snap(t);
        BSnap bs = snap(created);
        List<String> gone = new ArrayList<>();
        for (PlacedBuilding r : retired) gone.add(r.id.toString());
        try {
            io.submit(() -> {
                tx(() -> {
                    writeTown(ts);
                    writeBuilding(bs);
                    try (PreparedStatement ps = conn.prepareStatement("DELETE FROM buildings WHERE id=?")) {
                        for (String id : gone) { ps.setString(1, id); ps.addBatch(); }
                        ps.executeBatch();
                    }
                });
                return null;
            }).get(15, TimeUnit.SECONDS);
            return true;
        } catch (Exception e) {
            log.log(Level.SEVERE, "Handoff transaction failed; changes rolled back", e);
            return false;
        }
    }
}
