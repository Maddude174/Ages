package dev.ages.config;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

/**
 * blockgroups.yml: named sets of blocks ("any light source", "any planks").
 * A group can combine materials, vanilla block tags and other groups.
 */
public final class BlockGroups {
    private final Map<String, Set<Material>> resolved = new HashMap<>();

    public Set<Material> get(String name) { return resolved.get(name.toLowerCase()); }

    /** Loads and merges any number of files, so groups can live in blockgroups.yml and blockgroups/*.yml. */
    public void load(List<File> files, List<String> errors) {
        Map<String, ConfigurationSection> raw = new LinkedHashMap<>();
        for (File file : files) {
            YamlConfiguration y = new YamlConfiguration();
            try {
                y.load(file);
            } catch (Exception e) {
                errors.add(file.getName() + ": cannot read (" + e.getMessage() + ")");
                continue;
            }
            for (String k : y.getKeys(false)) {
                ConfigurationSection s = y.getConfigurationSection(k);
                if (s != null) raw.put(k.toLowerCase(), s);
            }
        }
        for (String k : raw.keySet()) resolve(k, raw, new ArrayDeque<>(), errors);
    }

    private Set<Material> resolve(String name, Map<String, ConfigurationSection> raw, Deque<String> stack, List<String> errors) {
        Set<Material> done = resolved.get(name);
        if (done != null) return done;
        if (stack.contains(name)) {
            errors.add("blockgroups.yml: group cycle involving '" + name + "'");
            return Set.of();
        }
        ConfigurationSection s = raw.get(name);
        if (s == null) {
            errors.add("blockgroups.yml: unknown group '" + name + "'");
            return Set.of();
        }
        stack.push(name);
        Set<Material> out = EnumSet.noneOf(Material.class);
        for (String m : s.getStringList("materials")) {
            Material mat = Material.matchMaterial(m);
            if (mat == null) errors.add("blockgroups.yml: group '" + name + "' has unknown material '" + m + "'");
            else out.add(mat);
        }
        for (String t : s.getStringList("tags")) {
            NamespacedKey key = NamespacedKey.fromString(t.toLowerCase());
            Tag<Material> tag = key == null ? null : Bukkit.getTag(Tag.REGISTRY_BLOCKS, key, Material.class);
            if (tag == null) errors.add("blockgroups.yml: group '" + name + "' has unknown block tag '" + t + "'");
            else out.addAll(tag.getValues());
        }
        for (String g : s.getStringList("groups")) out.addAll(resolve(g.toLowerCase(), raw, stack, errors));
        stack.pop();
        resolved.put(name, out);
        return out;
    }
}
