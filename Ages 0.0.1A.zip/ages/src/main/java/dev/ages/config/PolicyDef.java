package dev.ages.config;

import org.bukkit.Material;

import java.util.*;

/** A switchable policy that applies modifiers while adopted. kind = government | economy. */
public final class PolicyDef {
    public String id;
    public String name;
    public List<String> description = List.of();
    public Material icon = Material.PAPER;
    public String kind = "government";
    public String minAge;
    public String exclusiveGroup;
    public Map<String, Double> effects = new HashMap<>();
    /** Paid once when adopted. */
    public BuildingDef.Cost cost = BuildingDef.Cost.FREE;
}
