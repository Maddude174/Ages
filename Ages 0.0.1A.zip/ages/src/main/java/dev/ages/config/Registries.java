package dev.ages.config;

import dev.ages.model.Perm;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Rank;
import dev.ages.util.Containers;
import dev.ages.util.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.MemoryConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;

import java.io.File;
import java.util.*;

/**
 * Everything loaded from config files. Immutable once loaded: a reload builds a fresh instance, so a broken
 * edit never leaves the running plugin half-updated.
 *
 * A definition with errors is SKIPPED (reported in {@link #skipped}) and the rest still loads. Only problems
 * that make the plugin unusable (no valid ages, unreadable settings) land in {@link #errors}.
 */
public final class Registries {
    public final BlockGroups groups = new BlockGroups();
    public final Map<String, BuildingDef> buildings = new LinkedHashMap<>();
    public final Map<String, AgeDef> ages = new LinkedHashMap<>();
    public final Map<String, GovernmentDef> governments = new LinkedHashMap<>();
    public final Map<String, EconomyDef> economies = new LinkedHashMap<>();
    public final Map<String, PolicyDef> policies = new LinkedHashMap<>();
    public final List<ShopCategory> categories = new ArrayList<>();
    public Settings settings = new Settings();

    /** Fatal: the plugin cannot run. */
    public final List<String> errors = new ArrayList<>();
    /** Non-fatal: a definition was skipped or adjusted. */
    public final List<String> skipped = new ArrayList<>();
    public final List<String> notes = new ArrayList<>();

    private List<String> sink = errors;
    private final List<AgeDef> ordered = new ArrayList<>();
    private final Map<String, AgeDef> coreToAge = new HashMap<>();
    private final Map<String, String> buildingAliases = new HashMap<>();
    private final Map<String, String> ageAliases = new HashMap<>();

    private static final Set<String> FUNCTIONS = Set.of("processor", "spawner", "tax", "sell", "none");
    private static final Set<String> MODES = Set.of("random", "first", "all", "selected");
    private static final String[] ROMAN = {"I", "II", "III", "IV", "V", "VI"};

    // ------------------------------------------------------------------ lookups

    public String canonicalBuilding(String id) { return buildings.containsKey(id) ? id : buildingAliases.getOrDefault(id, id); }
    public String canonicalAge(String id) { return ages.containsKey(id) ? id : ageAliases.getOrDefault(id, id); }
    public BuildingDef building(String id) { return buildings.get(canonicalBuilding(id)); }
    public AgeDef age(String id) { return ages.get(canonicalAge(id)); }
    public AgeDef firstAge() { return ordered.get(0); }
    public List<AgeDef> orderedAges() { return ordered; }

    public AgeDef nextAge(AgeDef a) {
        int i = ordered.indexOf(a);
        return i >= 0 && i + 1 < ordered.size() ? ordered.get(i + 1) : null;
    }

    /** The age that placing this building advances a civilization into, or null if it is not an age core. */
    public AgeDef ageForCore(String buildingId) { return coreToAge.get(buildingId); }

    public BuildingDef foundingBuilding() { return ordered.isEmpty() ? null : buildings.get(ordered.get(0).coreBuilding); }

    public int ageOrder(String ageId) {
        AgeDef a = age(ageId);
        return a == null ? Integer.MAX_VALUE : a.order;
    }

    public GovernmentDef government(String id) {
        GovernmentDef g = governments.get(id == null ? "" : id);
        return g != null ? g : governments.get(settings.defaultGovernment) != null ? governments.get(settings.defaultGovernment) : governments.values().iterator().next();
    }

    public EconomyDef economy(String id) {
        EconomyDef e = economies.get(id == null ? "" : id);
        return e != null ? e : economies.get(settings.defaultEconomy) != null ? economies.get(settings.defaultEconomy) : economies.values().iterator().next();
    }

    public PolicyDef policy(String id) { return policies.get(id); }

    /** The definition of a placed building at its current level. */
    public BuildingDef effective(PlacedBuilding pb) {
        BuildingDef d = building(pb.defId);
        return d == null ? null : d.at(pb.level);
    }

    /** Can no longer be bought or placed in this age (existing buildings keep working). */
    public boolean isObsolete(BuildingDef d, AgeDef cur) {
        if (d.obsoleteIn != null) {
            AgeDef o = age(d.obsoleteIn);
            if (o != null && o.order <= cur.order) return true;
        }
        for (AgeDef a : ordered) if (a.order <= cur.order && a.retire.contains(d.id)) return true;
        return false;
    }

    // ------------------------------------------------------------------ loading

    public static Registries load(File dir) {
        Registries r = new Registries();
        r.settings = Settings.load(new File(dir, "settings.yml"), r.errors);
        List<File> groupFiles = new ArrayList<>();
        groupFiles.add(new File(dir, "blockgroups.yml"));
        File[] extra = new File(dir, "blockgroups").listFiles((d, n) -> n.endsWith(".yml") && !n.startsWith("_"));
        if (extra != null) { Arrays.sort(extra); groupFiles.addAll(Arrays.asList(extra)); }   // blockgroups/*.yml are merged in
        r.groups.load(groupFiles, r.errors);
        r.loadCategories(new File(dir, "shop.yml"));
        r.loadAges(new File(dir, "ages"));
        r.loadBuildings(new File(dir, "buildings"));
        r.loadGovernments(new File(dir, "governments"));
        r.loadEconomies(new File(dir, "economies"));
        r.loadPolicies(new File(dir, "policies"));
        r.validate();
        return r;
    }

    private void err(String file, String msg) { sink.add(file + ": " + msg); }

    private YamlConfiguration yaml(File f, String label) {
        YamlConfiguration y = new YamlConfiguration();
        try {
            y.load(f);
            return y;
        } catch (Exception e) {
            err(label, "cannot parse YAML (" + e.getMessage() + ")");
            return null;
        }
    }

    private File[] files(File dir) {
        File[] fs = dir.listFiles((d, n) -> n.endsWith(".yml") && !n.startsWith("_"));
        if (fs == null) return new File[0];
        Arrays.sort(fs);
        return fs;
    }

    /** Run one definition's parser against a private error list; any error skips just that definition. */
    private <T> T guarded(String label, java.util.function.Supplier<T> parse) {
        List<String> tmp = new ArrayList<>();
        sink = tmp;
        T result;
        try {
            result = parse.get();
        } catch (RuntimeException ex) {
            tmp.add(label + ": unexpected error (" + ex + ")");
            result = null;
        }
        sink = errors;
        if (!tmp.isEmpty()) {
            for (String t : tmp) skipped.add(t);
            skipped.add("  -> " + label + " was skipped.");
            return null;
        }
        return result;
    }

    private void loadCategories(File f) {
        YamlConfiguration y = yaml(f, "shop.yml");
        if (y == null) return;
        ConfigurationSection cs = y.getConfigurationSection("categories");
        if (cs == null) { err("shop.yml", "no categories"); return; }
        for (String id : cs.getKeys(false)) {
            ConfigurationSection c = cs.getConfigurationSection(id);
            if (c == null) continue;
            Material icon = mat(c.getString("icon"), "shop.yml", id + ".icon");
            if (icon == null) icon = Material.CHEST;
            categories.add(new ShopCategory(id.toLowerCase(), c.getString("name", id), icon,
                    c.getInt("slot", -1), c.getStringList("description")));
        }
    }

    // ------------------------------------------------------------------ ages

    private void loadAges(File dir) {
        for (File f : files(dir)) {
            String label = "ages/" + f.getName();
            AgeDef a = guarded(label, () -> {
                YamlConfiguration y = yaml(f, label);
                return y == null ? null : parseAge(y, label);
            });
            if (a == null) continue;
            if (ages.putIfAbsent(a.id, a) != null) skipped.add(label + ": duplicate age id '" + a.id + "' skipped");
        }
    }

    private AgeDef parseAge(ConfigurationSection y, String file) {
        AgeDef a = new AgeDef();
        a.id = String.valueOf(y.getString("id", "")).toLowerCase();
        if (a.id.isBlank()) { err(file, "missing 'id'"); return a; }
        a.name = y.getString("name", a.id);
        a.order = y.getInt("order", 0);
        a.coreBuilding = String.valueOf(y.getString("core_building", "")).toLowerCase();
        for (String s : y.getStringList("aliases")) a.aliases.add(s.toLowerCase());
        a.claimBase = y.getInt("claim.base_radius", 24);
        a.claimPerBuilding = y.getInt("claim.per_building", 3);
        a.claimMax = y.getInt("claim.max_radius", 64);
        ConfigurationSection lim = y.getConfigurationSection("building_limits");
        if (lim != null) for (String k : lim.getKeys(false)) a.limits.put(k.toLowerCase(), lim.getInt(k));
        ConfigurationSection tl = y.getConfigurationSection("tag_limits");
        if (tl != null) for (String k : tl.getKeys(false))
            a.tagLimits.put(k.toLowerCase(), new int[]{tl.getInt(k + ".per_player", 0), tl.getInt(k + ".per_town", 0)});
        for (String s : y.getStringList("retire")) a.retire.add(s.toLowerCase());
        a.rails = y.getBoolean("rails", false);

        a.requirements = parseCond(y.get("requirements"), file);
        a.advanceCost = parseCost(y.getConfigurationSection("advance_cost"), file);
        return a;
    }

    /**
     * Requirement tree. Accepts a map with all_of / any_of / leaf keys, or a list (= all_of).
     * Also accepts the old format {buildings: {id: n}, population: {min: n, count: [...]}}.
     */
    private Cond parseCond(Object o, String file) {
        if (o == null) return null;
        if (o instanceof List<?> l) {
            List<Cond> items = new ArrayList<>();
            for (Object x : l) { Cond c = parseCond(x, file); if (c != null) items.add(c); }
            return items.isEmpty() ? null : items.size() == 1 ? items.get(0) : new Cond.All(items);
        }
        if (!(o instanceof Map<?, ?> m)) { err(file, "a requirement must be a map or a list"); return null; }
        List<Cond> parts = new ArrayList<>();
        for (Map.Entry<?, ?> e : m.entrySet()) {
            String k = String.valueOf(e.getKey()).toLowerCase();
            Object v = e.getValue();
            switch (k) {
                case "all_of", "any_of" -> {
                    List<Cond> items = new ArrayList<>();
                    if (v instanceof List<?> l) for (Object x : l) { Cond c = parseCond(x, file); if (c != null) items.add(c); }
                    else err(file, k + " must be a list");
                    if (items.isEmpty()) err(file, k + " is empty");
                    else parts.add(k.equals("all_of") ? new Cond.All(items) : new Cond.Any(items));
                }
                case "building" -> parts.add(new Cond.Leaf("building", String.valueOf(v).toLowerCase(), Math.max(1, num(m.get("count"), 1)), Math.max(1, num(m.get("level"), 1)), false, false));
                case "tag" -> parts.add(new Cond.Leaf("tag", String.valueOf(v).toLowerCase(), Math.max(1, num(m.get("count"), 1)), 1, false, false));
                case "members" -> parts.add(new Cond.Leaf("members", "", num(v, 1), 1, false, false));
                case "treasury", "points" -> parts.add(new Cond.Leaf(k, "", v instanceof Number n ? n.doubleValue() : 0, 1, false, false));
                case "population" -> {
                    int min = 0;
                    boolean players = true, villagers = true;
                    if (v instanceof Number n) min = n.intValue();
                    else if (v instanceof Map<?, ?> pm) {
                        min = num(pm.get("min"), 0);
                        if (pm.get("count") instanceof List<?> cl) {
                            players = cl.stream().anyMatch(s -> "players".equalsIgnoreCase(String.valueOf(s)));
                            villagers = cl.stream().anyMatch(s -> "villagers".equalsIgnoreCase(String.valueOf(s)));
                        }
                    }
                    if (min > 0) parts.add(new Cond.Leaf("population", "", min, 1, players, villagers));
                }
                case "buildings" -> {   // legacy map
                    if (v instanceof Map<?, ?> bm)
                        for (Map.Entry<?, ?> be : bm.entrySet())
                            parts.add(new Cond.Leaf("building", String.valueOf(be.getKey()).toLowerCase(), num(be.getValue(), 1), 1, false, false));
                }
                case "count", "level" -> { }  // belong to a sibling building/tag key
                default -> err(file, "unknown requirement key '" + k + "'");
            }
        }
        return parts.isEmpty() ? null : parts.size() == 1 ? parts.get(0) : new Cond.All(parts);
    }

    private void collectBuildingRefs(Cond c, Set<String> out) {
        if (c instanceof Cond.All a) a.items().forEach(x -> collectBuildingRefs(x, out));
        else if (c instanceof Cond.Any a) a.items().forEach(x -> collectBuildingRefs(x, out));
        else if (c instanceof Cond.Leaf l && l.type().equals("building")) out.add(l.id());
    }

    // ------------------------------------------------------------------ buildings

    private void loadBuildings(File dir) {
        for (File f : files(dir)) {
            String label = "buildings/" + f.getName();
            BuildingDef d = guarded(label, () -> {
                YamlConfiguration y = yaml(f, label);
                return y == null ? null : parseBuilding(y, label);
            });
            if (d == null) continue;
            if (buildings.putIfAbsent(d.id, d) != null) skipped.add(label + ": duplicate building id '" + d.id + "' skipped");
        }
    }

    private BuildingDef parseBuilding(ConfigurationSection c, String file) {
        BuildingDef d = new BuildingDef();
        d.id = String.valueOf(c.getString("id", "")).toLowerCase();
        if (d.id.isBlank()) { err(file, "missing 'id'"); return d; }
        d.name = c.getString("name", d.id);
        d.description = c.getStringList("description");
        d.category = c.getString("category", "community").toLowerCase();
        d.ageId = String.valueOf(c.getString("age", "")).toLowerCase();
        d.obsoleteIn = c.getString("obsolete_in") == null ? null : c.getString("obsolete_in").toLowerCase();
        d.coreBlock = mat(c.getString("core_block"), file, "core_block");
        if (d.coreBlock == null) return d;
        if (!d.coreBlock.isBlock()) err(file, "core_block " + d.coreBlock + " is not a placeable block");
        Material icon = c.contains("icon") ? mat(c.getString("icon"), file, "icon") : null;
        d.icon = icon != null ? icon : d.coreBlock;
        d.shop = c.getBoolean("shop", true);
        for (String s : c.getStringList("aliases")) d.aliases.add(s.toLowerCase());
        for (String s : c.getStringList("replaces")) d.replaces.add(s.toLowerCase());

        Object tags = c.get("tags");
        if (tags instanceof List<?> l) for (Object x : l) d.tags.put(String.valueOf(x).toLowerCase(), 1.0);
        else if (tags instanceof Map<?, ?> m) for (Map.Entry<?, ?> e : m.entrySet())
            d.tags.put(String.valueOf(e.getKey()).toLowerCase(), e.getValue() instanceof Number n ? n.doubleValue() : 1.0);
        else if (tags instanceof String s) d.tags.put(s.toLowerCase(), 1.0);

        ConfigurationSection scan = c.getConfigurationSection("scan");
        if (scan != null) {
            int y = scan.getInt("y", 0);
            d.rx = scan.getInt("x", 0);
            d.rz = scan.getInt("z", d.rx);
            d.up = scan.getInt("up", y);
            d.down = scan.getInt("down", y);
            int max = settings.maxScanRadius;
            if (d.rx > max || d.rz > max || d.up > max || d.down > max)
                err(file, "scan radius exceeds buildings.max_scan_radius (" + max + ")");
        }
        d.requirements.addAll(parseReqs(c.getMapList("requirements"), file));
        d.cost = parseCost(c.getConfigurationSection("cost"), file);
        // limits: max_per_town / max_per_player (older files) and the shorter per_town / per_player are both accepted
        d.maxPerTown = c.getInt("limits.max_per_town", c.getInt("limits.per_town", 0));
        d.maxPerPlayer = c.getInt("limits.max_per_player", c.getInt("limits.per_player", 0));
        if (d.maxPerTown < 0 || d.maxPerPlayer < 0) err(file, "limits cannot be negative");
        d.anywhere = "anywhere".equalsIgnoreCase(c.getString("placement", "inside"));

        String in = c.getString("logistics.input"), out = c.getString("logistics.output");
        if (in != null) {
            if (in.equalsIgnoreCase("CORE")) { d.inputCore = true; d.inputContainer = d.coreBlock; }
            else d.inputContainer = mat(in, file, "logistics.input");
        }
        if (out != null) {
            if (out.equalsIgnoreCase("CORE")) { d.outputCore = true; d.outputContainer = d.coreBlock; }
            else d.outputContainer = mat(out, file, "logistics.output");
        }
        d.stores = c.getString("logistics.stores", "any").toLowerCase();
        if (!Set.of("any", "food", "goods").contains(d.stores)) err(file, "logistics.stores must be any, food or goods");
        if ((d.inputCore || d.outputCore) && !Containers.isStorage(d.coreBlock))
            err(file, "logistics CORE needs a storage block as core_block (chest, barrel...), not " + d.coreBlock);
        for (Material m : new Material[]{d.inputContainer, d.outputContainer})
            if (m != null && !Containers.isContainer(m)) err(file, "logistics container " + m + " is not a container block");

        ConfigurationSection fs = c.getConfigurationSection("function");
        if (fs != null) d.function = parseFunction(fs, file);
        ConfigurationSection pv = c.getConfigurationSection("provides");
        if (pv != null) d.provides.putAll(parseProvides(pv));

        int level = 2;
        for (Map<?, ?> um : maps(c.get("upgrades"))) {
            ConfigurationSection us = new MemoryConfiguration().createSection("u", um);
            BuildingDef.Upgrade u = parseUpgrade(us, d, level, file);
            if (u != null) d.upgrades.add(u);
            level++;
        }
        d.buildLevels();

        // every level must be internally consistent
        for (int lv = 1; lv <= d.maxLevel(); lv++) {
            BuildingDef x = d.at(lv);
            String ctx = file + (lv > 1 ? " (level " + lv + ")" : "");
            if (x.hasItemOutput() && x.outputContainer == null) err(ctx, "item outputs need a logistics.output container (or output: CORE)");
            if (x.hasInput() && x.inputContainer == null) err(ctx, "inputs/consumption need a logistics.input container (or input: CORE)");
            if (x.function != null && x.function.type.equals("processor") && x.function.recipes.isEmpty() && x.function.always.isEmpty())
                err(ctx, "processor has no recipes and no 'always' output");
            if (x.function != null && x.function.mode.equals("selected") && x.function.recipes.isEmpty())
                err(ctx, "mode 'selected' needs at least one recipe");
        }
        return d;
    }

    private Map<String, Double> parseProvides(ConfigurationSection pv) {
        Map<String, Double> out = new HashMap<>();
        for (String k : pv.getKeys(false)) {
            Object o = pv.get(k);
            if (o instanceof Boolean b) out.put(k, b ? 1.0 : 0.0);
            else if (o instanceof Number n) out.put(k, n.doubleValue());
        }
        return out;
    }

    private List<BuildingDef.Req> parseReqs(List<Map<?, ?>> list, String file) {
        List<BuildingDef.Req> out = new ArrayList<>();
        for (Map<?, ?> m : list) {
            Object g = m.get("group");
            Object mt = m.get("material");
            int min = num(m.get("min"), 1);
            if (min < 1) { err(file, "requirement min must be at least 1"); continue; }
            if (g != null) {
                String gn = g.toString().toLowerCase();
                Set<Material> set = groups.get(gn);
                if (set == null) { err(file, "unknown block group '" + gn + "'"); continue; }
                out.add(new BuildingDef.Req(gn, set, min));
            } else if (mt != null) {
                Material mm = mat(mt.toString(), file, "requirements");
                if (mm != null) out.add(new BuildingDef.Req(mm.name().toLowerCase(), EnumSet.of(mm), min));
            } else {
                err(file, "a requirement needs 'group' or 'material'");
            }
        }
        return out;
    }

    private BuildingDef.FunctionDef parseFunction(ConfigurationSection fs, String file) {
        BuildingDef.FunctionDef f = new BuildingDef.FunctionDef();
        f.type = fs.getString("type", "none").toLowerCase();
        if (!FUNCTIONS.contains(f.type)) err(file, "unknown function type '" + f.type + "' (valid: " + FUNCTIONS + ")");
        f.interval = fs.getInt("interval", 300);
        if (f.interval < 1) err(file, "function interval must be at least 1 second");
        f.mode = fs.getString("mode", "random").toLowerCase();
        if (!MODES.contains(f.mode)) err(file, "unknown recipe mode '" + f.mode + "' (valid: " + MODES + ")");
        Set<String> ids = new HashSet<>();
        int idx = 0;
        for (Map<?, ?> rm : fs.getMapList("recipes")) {
            BuildingDef.Recipe r = parseRecipe(rm, file, idx++);
            if (r == null) continue;
            if (!ids.add(r.id())) err(file, "duplicate recipe id '" + r.id() + "'");
            f.recipes.add(r);
        }
        f.always.addAll(parseEntryList(fs.getList("always"), file));
        if (fs.contains("entity")) {
            try {
                f.entity = EntityType.valueOf(String.valueOf(fs.getString("entity")).toUpperCase());
            } catch (IllegalArgumentException e) {
                err(file, "unknown entity '" + fs.getString("entity") + "'");
            }
        }
        f.cap = fs.getInt("cap", 1);
        if (f.cap < 1) err(file, "spawner cap must be at least 1");
        f.housingLimited = fs.getBoolean("housing_limited", false);
        for (Map<?, ?> im : fs.getMapList("consume")) f.consume.add(parseIngredient(im, file));
        f.perResident = fs.getDouble("per_resident", 0);
        f.maxStored = fs.getDouble("max_stored", 1000);
        f.payout = fs.getString("payout", "treasury").toLowerCase();
        ConfigurationSection pr = fs.getConfigurationSection("prices");
        if (pr != null) {
            for (String k : pr.getKeys(false)) {
                Material m = mat(k, file, "prices");
                if (m == null) continue;
                if (pr.getDouble(k) < 0) err(file, "price for " + k + " cannot be negative");
                f.prices.put(m, pr.getDouble(k));
            }
        }
        f.maxItems = fs.getInt("max_items", 64);
        if (f.type.equals("spawner") && f.entity == null) err(file, "spawner function needs an 'entity'");
        return f;
    }

    /**
     * A recipe marked `optional: true` is silently dropped when it references a material this server version
     * does not have (e.g. copper tools before 1.21.9), instead of failing the definition.
     */
    private BuildingDef.Recipe parseRecipe(Map<?, ?> rm, String file, int idx) {
        int before = sink.size();
        BuildingDef.Recipe r = parseRecipeInner(rm, file, idx);
        if (Boolean.TRUE.equals(rm.get("optional")) && sink.size() > before) {
            sink.subList(before, sink.size()).clear();
            return null;
        }
        return r;
    }

    private BuildingDef.Recipe parseRecipeInner(Map<?, ?> rm, String file, int idx) {
        String id = rm.get("id") != null ? String.valueOf(rm.get("id")).toLowerCase() : "r" + (idx + 1);
        String name = rm.get("name") != null ? String.valueOf(rm.get("name")) : null;
        Integer interval = rm.get("interval") instanceof Number n ? Integer.valueOf(Math.max(1, n.intValue())) : null;
        String ctx = file + " recipe '" + id + "'";
        List<BuildingDef.Ingredient> consume = new ArrayList<>();
        for (Map<?, ?> im : maps(rm.get("consume"))) consume.add(parseIngredient(im, ctx));
        Map<?, ?> pm = rm.get("produce") instanceof Map<?, ?> x ? x : Map.of();
        boolean pickOne = !"all".equalsIgnoreCase(String.valueOf(pm.get("pick")));
        List<BuildingDef.Entry> entries = parseProduce(pm, pickOne, ctx);
        if (entries.isEmpty()) err(ctx, "has no valid produce entries");
        return new BuildingDef.Recipe(id, name, interval, consume, pickOne, entries);
    }

    /**
     * Entries: {item: X, min, max} | {item: AIR} | {points: N} | {money: N}, plus weight / chance / percent.
     * pick: one  -> weighted. With `percent` on every entry the values must total <= 100; the remainder is AIR.
     * pick: all  -> each entry rolls independently on `chance` (0-1).
     */
    private List<BuildingDef.Entry> parseProduce(Map<?, ?> pm, boolean pickOne, String ctx) {
        List<BuildingDef.Entry> out = new ArrayList<>();
        double percentSum = 0;
        int withPercent = 0, withWeight = 0, total = 0;
        for (Map<?, ?> em : maps(pm.get("entries"))) {
            total++;
            BuildingDef.Kind kind;
            Material item = null;
            double min, max;
            if (em.containsKey("points") || em.containsKey("money")) {
                kind = em.containsKey("points") ? BuildingDef.Kind.POINTS : BuildingDef.Kind.MONEY;
                double v = dbl(em.get(kind == BuildingDef.Kind.POINTS ? "points" : "money"), 0);
                min = dbl(em.get("min"), v);
                max = dbl(em.get("max"), v);
                if (min < 0) err(ctx, "a " + kind.name().toLowerCase() + " amount cannot be negative");
            } else {
                String it = String.valueOf(em.get("item"));
                if (it.equalsIgnoreCase("AIR")) { kind = BuildingDef.Kind.AIR; min = max = 0; }
                else {
                    kind = BuildingDef.Kind.ITEM;
                    item = mat(it, ctx, "produce item");
                    if (item == null) continue;
                    if (!item.isItem()) { err(ctx, it + " is not an item"); continue; }
                    min = dbl(em.get("min"), 1);
                    max = dbl(em.get("max"), min);
                    if (min < 1) err(ctx, "item quantities must be at least 1 (use AIR for 'nothing')");
                }
            }
            if (max < min) err(ctx, "max (" + max + ") is smaller than min (" + min + ")");
            double weight = dbl(em.get("weight"), 1);
            double chance = dbl(em.get("chance"), 1.0);
            if (em.containsKey("weight")) withWeight++;
            if (em.containsKey("percent")) {
                double p = dbl(em.get("percent"), -1);
                if (p < 0 || p > 100) err(ctx, "percent must be between 0 and 100 (got " + em.get("percent") + ")");
                withPercent++;
                percentSum += Math.max(0, p);
                weight = Math.max(0, p);
            }
            if (weight <= 0 && !em.containsKey("percent")) err(ctx, "weight must be greater than 0");
            if (chance < 0 || chance > 1) err(ctx, "chance must be between 0 and 1 (got " + chance + ")");
            out.add(new BuildingDef.Entry(kind, item, min, max, weight, chance));
        }
        if (withPercent > 0) {
            if (!pickOne) err(ctx, "percent can only be used with pick: one (use chance with pick: all)");
            else if (withPercent != total) err(ctx, "percent must be given on every entry or on none");
            else if (withWeight > 0) err(ctx, "do not mix weight and percent in one recipe");
            else if (percentSum > 100.0001) err(ctx, "percent values total " + trim(percentSum) + "%, which is more than 100%");
            else if (percentSum < 99.9999) out.add(new BuildingDef.Entry(BuildingDef.Kind.AIR, null, 0, 0, 100 - percentSum, 1.0)); // remainder = nothing
        }
        return out;
    }

    private List<BuildingDef.Entry> parseEntryList(Object o, String file) {
        if (!(o instanceof List<?> l)) return List.of();
        Map<String, Object> pm = new HashMap<>();
        pm.put("pick", "all");
        pm.put("entries", l);
        return parseProduce(pm, false, file + " always");
    }

    private BuildingDef.Ingredient parseIngredient(Map<?, ?> im, String file) {
        Set<Material> set = EnumSet.noneOf(Material.class);
        if (im.get("item") != null) {
            Material m = mat(im.get("item").toString(), file, "ingredient.item");
            if (m != null) set.add(m);
        }
        if (im.get("any_of") instanceof List<?> l) {
            for (Object o : l) {
                Material m = mat(String.valueOf(o), file, "ingredient.any_of");
                if (m != null) set.add(m);
            }
        }
        if (set.isEmpty()) err(file, "an ingredient has no valid 'item' or 'any_of'");
        int amount = num(im.get("amount"), im.get("durability") != null ? 0 : 1);
        int durability = num(im.get("durability"), 0);
        if (durability > 0) {
            for (Material m : set) {
                if (m.getMaxDurability() <= 0) err(file, m + " has no durability, so it cannot be a 'durability' input");
                else if (durability >= m.getMaxDurability()) err(file, "durability " + durability + " is not less than " + m + "'s maximum (" + m.getMaxDurability() + ")");
            }
        } else if (amount < 1) {
            err(file, "an ingredient needs amount >= 1 or durability >= 1");
        } else if (amount > 2304) {
            err(file, "ingredient amount " + amount + " is unreasonably large");
        }
        return new BuildingDef.Ingredient(set, amount, durability);
    }

    /** points = shared resource points, treasury = shared treasury money, items = from the buyer. Old `money:` is migrated. */
    private BuildingDef.Cost parseCost(ConfigurationSection s, String file) {
        if (s == null) return BuildingDef.Cost.FREE;
        double points = s.getDouble("points", 0);
        double treasury = s.getDouble("treasury", 0);
        if (!s.contains("points") && s.contains("money")) {
            points = s.getDouble("money") * settings.legacyMoneyToPoints;
            notes.add(file + ": old 'cost.money: " + trim(s.getDouble("money")) + "' read as " + trim(points) + " resource points "
                    + "(migration.legacy_money_cost_to_points). Replace it with 'points:' to silence this.");
        }
        if (points < 0 || treasury < 0) err(file, "costs cannot be negative");
        Map<Material, Integer> items = new LinkedHashMap<>();
        ConfigurationSection is = s.getConfigurationSection("items");
        if (is != null) {
            for (String k : is.getKeys(false)) {
                Material m = mat(k, file, "cost.items");
                if (m == null) continue;
                if (is.getInt(k) < 1) err(file, "cost item " + k + " must be at least 1");
                else items.put(m, is.getInt(k));
            }
        }
        return new BuildingDef.Cost(points, treasury, items);
    }

    private BuildingDef.Upgrade parseUpgrade(ConfigurationSection s, BuildingDef d, int level, String file) {
        String ctx = file + " (upgrade to level " + level + ")";
        String label = s.getString("label", ROMAN[Math.min(level, ROMAN.length) - 1]);
        String age = String.valueOf(s.getString("age", d.ageId)).toLowerCase();
        BuildingDef.Cost cost = parseCost(s.getConfigurationSection("cost"), ctx);
        int rx = -1, rz = -1, up = -1, down = -1;
        ConfigurationSection sc = s.getConfigurationSection("scan");
        if (sc != null) {
            rx = sc.getInt("x", -1);
            rz = sc.contains("z") ? sc.getInt("z") : rx;
            up = sc.getInt("up", sc.getInt("y", -1));
            down = sc.getInt("down", sc.getInt("y", -1));
            int max = settings.maxScanRadius;
            if (rx > max || rz > max || up > max || down > max) err(ctx, "scan radius exceeds buildings.max_scan_radius (" + max + ")");
        }
        List<BuildingDef.Req> reqs = parseReqs(s.getMapList("requirements"), ctx);
        List<BuildingDef.Recipe> recipes = new ArrayList<>();
        List<BuildingDef.Entry> always = new ArrayList<>();
        Integer interval = null, cap = null, maxItems = null;
        Double perResident = null, maxStored = null;
        Map<Material, Double> prices = new LinkedHashMap<>();
        ConfigurationSection fs = s.getConfigurationSection("function");
        if (fs != null) {
            int idx = 1000;
            for (Map<?, ?> rm : fs.getMapList("recipes")) {
                BuildingDef.Recipe r = parseRecipe(rm, ctx, idx++);
                if (r != null) recipes.add(r);
            }
            always.addAll(parseEntryList(fs.getList("always"), ctx));
            if (fs.contains("interval")) interval = Math.max(1, fs.getInt("interval"));
            if (fs.contains("cap")) cap = fs.getInt("cap");
            if (fs.contains("max_items")) maxItems = fs.getInt("max_items");
            if (fs.contains("per_resident")) perResident = fs.getDouble("per_resident");
            if (fs.contains("max_stored")) maxStored = fs.getDouble("max_stored");
            ConfigurationSection pr = fs.getConfigurationSection("prices");
            if (pr != null) {
                for (String k : pr.getKeys(false)) {
                    Material m = mat(k, ctx, "prices");
                    if (m != null) prices.put(m, pr.getDouble(k));
                }
            }
            if (d.function == null) err(ctx, "this building has no base function to upgrade");
            else if (!recipes.isEmpty() && !d.function.type.equals("processor")) err(ctx, "recipes can only be added to processor buildings");
        }
        Map<String, Double> provides = new HashMap<>();
        ConfigurationSection pv = s.getConfigurationSection("provides");
        if (pv != null) provides.putAll(parseProvides(pv));
        return new BuildingDef.Upgrade(label, age, cost, rx, rz, up, down, reqs, recipes, always, interval, cap, maxItems,
                perResident, maxStored, prices, provides, s.getStringList("description"));
    }

    // ------------------------------------------------------------------ governments, economies, policies

    private void loadGovernments(File dir) {
        for (File f : files(dir)) {
            String label = "governments/" + f.getName();
            GovernmentDef g = guarded(label, () -> {
                YamlConfiguration y = yaml(f, label);
                return y == null ? null : parseGovernment(y, label);
            });
            if (g != null && governments.putIfAbsent(g.id, g) != null) skipped.add(label + ": duplicate government id '" + g.id + "' skipped");
        }
        if (governments.isEmpty()) {
            GovernmentDef g = GovernmentDef.fallback();
            governments.put(g.id, g);
            notes.add("No valid governments found: using a built-in fallback (chiefdom).");
        }
    }

    private GovernmentDef parseGovernment(ConfigurationSection y, String file) {
        GovernmentDef g = new GovernmentDef();
        g.id = String.valueOf(y.getString("id", "")).toLowerCase();
        if (g.id.isBlank()) { err(file, "missing 'id'"); return g; }
        g.name = y.getString("name", g.id);
        g.description = y.getStringList("description");
        Material icon = y.contains("icon") ? mat(y.getString("icon"), file, "icon") : null;
        if (icon != null) g.icon = icon;
        g.minAge = y.getString("min_age") == null ? null : y.getString("min_age").toLowerCase();
        g.leaderTitle = y.getString("leader_title", "Leader");
        g.leaderRole = String.valueOf(y.getString("leader_role", "")).toLowerCase();
        g.defaultRole = String.valueOf(y.getString("default_role", "")).toLowerCase();
        g.leaderSelection = y.getString("leader_selection", "appointed").toLowerCase();
        if (!Set.of("owner", "appointed", "elected").contains(g.leaderSelection)) err(file, "leader_selection must be owner, appointed or elected");
        g.allowCustomRoles = y.getBoolean("allow_custom_roles", true);
        ConfigurationSection rs = y.getConfigurationSection("roles");
        if (rs == null) err(file, "no roles defined");
        else for (String name : rs.getKeys(false)) {
            ConfigurationSection r = rs.getConfigurationSection(name);
            if (r == null) continue;
            Rank rank = new Rank(name.toLowerCase(), r.getInt("weight", 10));
            rank.title = r.getString("title", Text.pretty(name));
            for (String p : r.getStringList("permissions")) {
                if (p.equalsIgnoreCase("ALL")) {
                    for (Perm perm : Perm.values()) if (!perm.ownerOnly) rank.perms.add(perm);
                } else {
                    Perm perm = Perm.parse(p);
                    if (perm == null) err(file, "role '" + name + "' has unknown permission '" + p + "'");
                    else rank.perms.add(perm);
                }
            }
            g.roles.put(rank.name, rank);
        }
        if (!g.roles.containsKey(g.leaderRole)) err(file, "leader_role '" + g.leaderRole + "' is not a defined role");
        if (!g.roles.containsKey(g.defaultRole)) err(file, "default_role '" + g.defaultRole + "' is not a defined role");
        flatten(y.getConfigurationSection("modifiers"), "", g.modifiers);
        g.policies = y.getStringList("policies").stream().map(String::toLowerCase).toList();
        g.policySlots = y.getInt("policy_slots", 2);
        g.changeCost = parseCost(y.getConfigurationSection("change_cost"), file);
        g.changeCooldownHours = y.getInt("change_cooldown_hours", 24);
        return g;
    }

    private void loadEconomies(File dir) {
        for (File f : files(dir)) {
            String label = "economies/" + f.getName();
            EconomyDef e = guarded(label, () -> {
                YamlConfiguration y = yaml(f, label);
                return y == null ? null : parseEconomy(y, label);
            });
            if (e != null && economies.putIfAbsent(e.id, e) != null) skipped.add(label + ": duplicate economy id '" + e.id + "' skipped");
        }
        if (economies.isEmpty()) {
            EconomyDef e = EconomyDef.fallback();
            economies.put(e.id, e);
            notes.add("No valid economies found: using a built-in fallback (barter).");
        }
    }

    private EconomyDef parseEconomy(ConfigurationSection y, String file) {
        EconomyDef e = new EconomyDef();
        e.id = String.valueOf(y.getString("id", "")).toLowerCase();
        if (e.id.isBlank()) { err(file, "missing 'id'"); return e; }
        e.name = y.getString("name", e.id);
        e.description = y.getStringList("description");
        Material icon = y.contains("icon") ? mat(y.getString("icon"), file, "icon") : null;
        if (icon != null) e.icon = icon;
        e.minAge = y.getString("min_age") == null ? null : y.getString("min_age").toLowerCase();
        e.moneyEnabled = y.getBoolean("money_enabled", true);
        e.moneyToPoints = y.getDouble("money_to_points", 0.5);
        e.exchangeRate = y.getDouble("exchange_rate", 0);
        e.contributionMoney = y.getBoolean("contribution_money", e.moneyEnabled);
        e.withdrawLimit = y.getDouble("withdraw_limit", 0);
        if (e.moneyToPoints < 0 || e.exchangeRate < 0 || e.withdrawLimit < 0) err(file, "rates and limits cannot be negative");
        flatten(y.getConfigurationSection("modifiers"), "", e.modifiers);
        e.policies = y.getStringList("policies").stream().map(String::toLowerCase).toList();
        e.policySlots = y.getInt("policy_slots", 2);
        e.changeCost = parseCost(y.getConfigurationSection("change_cost"), file);
        e.changeCooldownHours = y.getInt("change_cooldown_hours", 24);
        return e;
    }

    private void loadPolicies(File dir) {
        for (File f : files(dir)) {
            String label = "policies/" + f.getName();
            PolicyDef p = guarded(label, () -> {
                YamlConfiguration y = yaml(f, label);
                return y == null ? null : parsePolicy(y, label);
            });
            if (p != null && policies.putIfAbsent(p.id, p) != null) skipped.add(label + ": duplicate policy id '" + p.id + "' skipped");
        }
    }

    private PolicyDef parsePolicy(ConfigurationSection y, String file) {
        PolicyDef p = new PolicyDef();
        p.id = String.valueOf(y.getString("id", "")).toLowerCase();
        if (p.id.isBlank()) { err(file, "missing 'id'"); return p; }
        p.name = y.getString("name", p.id);
        p.description = y.getStringList("description");
        Material icon = y.contains("icon") ? mat(y.getString("icon"), file, "icon") : null;
        if (icon != null) p.icon = icon;
        p.kind = y.getString("kind", "government").toLowerCase();
        if (!p.kind.equals("government") && !p.kind.equals("economy")) err(file, "kind must be government or economy");
        p.minAge = y.getString("min_age") == null ? null : y.getString("min_age").toLowerCase();
        p.exclusiveGroup = y.getString("exclusive_group");
        flatten(y.getConfigurationSection("effects"), "", p.effects);
        p.cost = parseCost(y.getConfigurationSection("cost"), file);
        return p;
    }

    private void flatten(ConfigurationSection s, String prefix, Map<String, Double> out) {
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            Object v = s.get(k);
            if (v instanceof ConfigurationSection sub) flatten(sub, prefix + k + ".", out);
            else if (v instanceof Number n) out.put(prefix + k, n.doubleValue());
        }
    }

    // ------------------------------------------------------------------ cross-validation

    private void validate() {
        // Drop buildings and ages whose references are broken, repeating until nothing changes (a dropped age can orphan buildings).
        for (int pass = 0; pass < 6; pass++) {
            boolean changed = false;
            for (Iterator<BuildingDef> it = buildings.values().iterator(); it.hasNext(); ) {
                BuildingDef d = it.next();
                String why = null;
                if (!ages.containsKey(d.ageId)) why = "age '" + d.ageId + "' does not exist (or was skipped)";
                for (BuildingDef.Upgrade u : d.upgrades) if (why == null && !ages.containsKey(u.ageId())) why = "an upgrade uses age '" + u.ageId() + "' which does not exist";
                if (why != null) { skipped.add("buildings/" + d.id + ": " + why + " -> building skipped"); it.remove(); changed = true; }
            }
            for (Iterator<AgeDef> it = ages.values().iterator(); it.hasNext(); ) {
                AgeDef a = it.next();
                List<String> problems = new ArrayList<>();
                if (!buildings.containsKey(a.coreBuilding)) problems.add("core_building '" + a.coreBuilding + "' does not exist (or was skipped)");
                Set<String> refs = new HashSet<>();
                collectBuildingRefs(a.requirements, refs);
                for (String r : refs) if (!buildings.containsKey(r) && !buildingAliasesContain(r)) problems.add("requirement references unknown building '" + r + "'");
                if (!problems.isEmpty()) {
                    for (String p : problems) skipped.add("ages/" + a.id + ": " + p);
                    skipped.add("  -> age '" + a.id + "' was skipped, so later ages cannot be reached through it.");
                    it.remove();
                    changed = true;
                }
            }
            if (!changed) break;
        }

        ordered.addAll(ages.values());
        ordered.sort(Comparator.comparingInt(a -> a.order));
        for (Iterator<AgeDef> it = ordered.iterator(); it.hasNext(); ) {
            AgeDef a = it.next();
            if (coreToAge.putIfAbsent(a.coreBuilding, a) != null) { skipped.add("ages/" + a.id + ": core building already used by another age -> skipped"); it.remove(); ages.remove(a.id); }
        }
        for (int i = 1; i < ordered.size(); i++)
            if (ordered.get(i).order == ordered.get(i - 1).order) skipped.add("ages: '" + ordered.get(i).id + "' shares order " + ordered.get(i).order + " with '" + ordered.get(i - 1).id + "'. Ages need distinct order values.");
        if (ordered.isEmpty()) { errors.add("No valid ages loaded. See the skipped definitions above for why."); return; }

        BuildingDef founding = foundingBuilding();
        if (founding != null) founding.founding = true;

        for (AgeDef a : ordered) {
            for (String r : a.retire) if (!buildings.containsKey(r) && !buildingAliasesContain(r)) notes.add("ages/" + a.id + ": retire lists unknown building '" + r + "'");
            if (a.advanceCost == null) a.advanceCost = BuildingDef.Cost.FREE;
        }
        for (AgeDef a : ordered) for (String al : a.aliases) ageAliases.put(al, a.id);
        for (BuildingDef d : buildings.values()) for (String al : d.aliases) buildingAliases.put(al, d.id);

        // New categories appear automatically, so a new building never needs a code or shop.yml change to show up.
        Set<String> cats = new HashSet<>();
        for (ShopCategory c : categories) cats.add(c.id());
        for (BuildingDef d : buildings.values()) {
            if (cats.add(d.category)) {
                categories.add(new ShopCategory(d.category, "&7" + Text.pretty(d.category), Material.CHEST, -1, List.of("Added automatically.")));
                notes.add("Shop category '" + d.category + "' was created automatically (used by " + d.id + "). Add it to shop.yml to customise it.");
            }
        }
        for (BuildingDef d : buildings.values()) for (String rep : d.replaces) if (!buildings.containsKey(rep) && !buildingAliasesContain(rep))
            notes.add("buildings/" + d.id + ": replaces unknown building '" + rep + "'");

        // governments / economies / policies cross-references
        for (GovernmentDef g : governments.values()) {
            g.policies = g.policies.stream().filter(p -> { if (policies.containsKey(p)) return true; notes.add("governments/" + g.id + ": unknown policy '" + p + "' ignored"); return false; }).toList();
            if (g.minAge != null && !ages.containsKey(g.minAge)) { notes.add("governments/" + g.id + ": unknown min_age '" + g.minAge + "', treated as none"); g.minAge = null; }
        }
        for (EconomyDef e : economies.values()) {
            e.policies = e.policies.stream().filter(p -> { if (policies.containsKey(p)) return true; notes.add("economies/" + e.id + ": unknown policy '" + p + "' ignored"); return false; }).toList();
            if (e.minAge != null && !ages.containsKey(e.minAge)) { notes.add("economies/" + e.id + ": unknown min_age '" + e.minAge + "', treated as none"); e.minAge = null; }
        }
        if (!governments.containsKey(settings.defaultGovernment)) {
            notes.add("settings.yml: defaults.government '" + settings.defaultGovernment + "' not found; using '" + governments.keySet().iterator().next() + "'");
            settings.defaultGovernment = governments.keySet().iterator().next();
        }
        if (!economies.containsKey(settings.defaultEconomy)) {
            notes.add("settings.yml: defaults.economy '" + settings.defaultEconomy + "' not found; using '" + economies.keySet().iterator().next() + "'");
            settings.defaultEconomy = economies.keySet().iterator().next();
        }
    }

    private boolean buildingAliasesContain(String id) {
        for (BuildingDef d : buildings.values()) if (d.aliases.contains(id)) return true;
        return false;
    }

    // ------------------------------------------------------------------ helpers

    private Material mat(String name, String file, String ctx) {
        if (name == null) { err(file, "missing material for " + ctx); return null; }
        Material m = Material.matchMaterial(name);
        if (m == null) err(file, "unknown material '" + name + "' (" + ctx + ")");
        return m;
    }

    private static String trim(double v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.format("%.2f", v); }
    private static int num(Object o, int def) { return o instanceof Number n ? n.intValue() : def; }
    private static double dbl(Object o, double def) { return o instanceof Number n ? n.doubleValue() : def; }

    private static List<Map<?, ?>> maps(Object o) {
        List<Map<?, ?>> out = new ArrayList<>();
        if (o instanceof List<?> l) for (Object x : l) if (x instanceof Map<?, ?> m) out.add(m);
        return out;
    }
}
