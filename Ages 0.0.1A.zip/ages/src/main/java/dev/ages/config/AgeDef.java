package dev.ages.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class AgeDef {
    public String id;
    public String name;
    public int order;
    /** Building that is this age's core. Buying and placing it advances the civilization INTO this age. */
    public String coreBuilding;
    /** Rail logistics work for civilizations in this age (YAML: rails: true). */
    public boolean rails;
    /** Old ids for this age in saved data. */
    public List<String> aliases = new ArrayList<>();

    public int claimBase = 24, claimPerBuilding = 3, claimMax = 64;

    /** Max count per building id while the civilization is in this age (0/absent = no age limit). */
    public Map<String, Integer> limits = new HashMap<>();
    /** Shared tag pools: {perPlayer, perTown}. */
    public Map<String, int[]> tagLimits = new HashMap<>();

    /** What must be true to buy and place this age's core. Null = no requirement. */
    public Cond requirements;
    public BuildingDef.Cost advanceCost = BuildingDef.Cost.FREE;
    /** Buildings of these ids are unregistered (phased out) when the civilization enters this age. */
    public List<String> retire = new ArrayList<>();
}
