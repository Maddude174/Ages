package dev.ages.config;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

import java.util.*;

/**
 * Description of a building, loaded from buildings/*.yml.
 * A building with `upgrades:` has several levels. Level 1 is this object; higher levels are derived
 * copies with the upgrades applied cumulatively. Always resolve a placed building through
 * Registries#effective(PlacedBuilding) so its level is respected.
 */
public final class BuildingDef {
    public String id;
    public String name;
    public List<String> description = List.of();
    public String category;
    public String ageId;
    public Material coreBlock;
    public Material icon;
    public boolean shop = true;
    /** True for the first age's core: placing it founds a civilization. Derived, not configured. */
    public boolean founding;
    /** From this age on the building can no longer be bought or placed (existing ones keep working). */
    public String obsoleteIn;
    /** Shared limit pools this building counts toward, with a weight each (e.g. housing: 2). */
    public Map<String, Double> tags = new LinkedHashMap<>();
    /** Old ids this building replaces in saved data (renames). */
    public List<String> aliases = new ArrayList<>();
    /** Building ids that are absorbed when this is placed over them (conversion / merging). */
    public List<String> replaces = new ArrayList<>();

    /** Radii from the core. A 5/5/5 hut checks an 11x11x11 area. */
    public int rx, rz, up, down;

    public List<Req> requirements = new ArrayList<>();
    public Cost cost = Cost.FREE;
    public int maxPerTown, maxPerPlayer;
    /** true = may be placed in wilderness (mines, quarries). Never inside another civilization's land. */
    public boolean anywhere;

    public Material inputContainer, outputContainer;
    /** The core block itself is the input/output container (chest/barrel cores). */
    public boolean inputCore, outputCore;
    /** Storage hubs only: what rail logistics may park here: any | food | goods (YAML: logistics.stores). */
    public String stores = "any";
    public FunctionDef function;
    public Map<String, Double> provides = new HashMap<>();

    // ---- levels
    public int level = 1;
    /** Null on the level-1 definition; points at it on derived levels. */
    public BuildingDef base;
    public List<Upgrade> upgrades = new ArrayList<>();
    private BuildingDef[] levels;

    public double provide(String key) { return provides.getOrDefault(key, 0.0); }

    public record Req(String label, Set<Material> materials, int min) {}

    /** points = shared resource points, money = shared treasury money, items = taken from the buyer's inventory. */
    public record Cost(double points, double money, Map<Material, Integer> items) {
        public static final Cost FREE = new Cost(0, 0, Map.of());
        public boolean isFree() { return points <= 0 && money <= 0 && items.isEmpty(); }
    }

    /** Either a tool (durability > 0: one matching item is worn down) or consumed items (amount). */
    public record Ingredient(Set<Material> anyOf, int amount, int durability) {}

    public enum Kind { ITEM, AIR, POINTS, MONEY }

    /** One possible result. AIR = nothing. POINTS/MONEY go to the civilization, not a container. */
    public record Entry(Kind kind, Material item, double min, double max, double weight, double chance) {}

    public record Recipe(String id, String name, Integer interval, List<Ingredient> consume, boolean pickOne, List<Entry> entries) {}

    /**
     * One upgrade step. Negative radii and null overrides mean "keep the previous level's value".
     * Requirements replace same-labelled ones (higher minimum wins) or are added; recipes, always-outputs and provides are added.
     */
    public record Upgrade(String label, String ageId, Cost cost, int rx, int rz, int up, int down,
                          List<Req> requirements, List<Recipe> recipes, List<Entry> always,
                          Integer interval, Integer cap, Integer maxItems, Double perResident, Double maxStored,
                          Map<Material, Double> prices, Map<String, Double> provides, List<String> description) {}

    public static final class FunctionDef {
        public String type = "none";
        public int interval = 300;
        /** random | first | all | selected (the owner picks a recipe in the building menu). */
        public String mode = "random";
        // processor
        public List<Recipe> recipes = new ArrayList<>();
        /** Fired every cycle regardless of recipes: typically resource points, sometimes treasury money. */
        public List<Entry> always = new ArrayList<>();
        // spawner
        public EntityType entity;
        public int cap = 1;
        public boolean housingLimited;
        public List<Ingredient> consume = new ArrayList<>();
        // tax / sell
        public double perResident;
        public double maxStored = 1000;
        public Map<Material, Double> prices = new LinkedHashMap<>();
        public int maxItems = 64;
        /** treasury (default) or owner (legacy: the building owner collects it). */
        public String payout = "treasury";

        FunctionDef copy() {
            FunctionDef f = new FunctionDef();
            f.type = type; f.interval = interval; f.mode = mode; f.recipes = new ArrayList<>(recipes); f.always = new ArrayList<>(always);
            f.entity = entity; f.cap = cap; f.housingLimited = housingLimited; f.consume = new ArrayList<>(consume);
            f.perResident = perResident; f.maxStored = maxStored; f.prices = new LinkedHashMap<>(prices); f.maxItems = maxItems; f.payout = payout;
            return f;
        }
    }

    // ------------------------------------------------------------------ derived info

    private Map<Material, Integer> needsCache;

    /**
     * Items this building's INPUT container wants and the stock level to keep: four cycles' worth of each
     * ingredient, two of each tool, a full sale batch of each sellable good. Rail logistics delivers against this.
     */
    public Map<Material, Integer> needs() {
        if (needsCache != null) return needsCache;
        Map<Material, Integer> n = new HashMap<>();
        if (function != null) {
            for (Recipe r : function.recipes)
                for (Ingredient i : r.consume())
                    for (Material m : i.anyOf()) n.merge(m, i.durability() > 0 ? 2 : i.amount() * 4, Math::max);
            for (Ingredient i : function.consume)
                for (Material m : i.anyOf()) n.merge(m, i.durability() > 0 ? 2 : i.amount() * 4, Math::max);
            for (Material m : function.prices.keySet()) n.merge(m, Math.max(64, function.maxItems), Math::max);
        }
        needsCache = n;
        return n;
    }

    public boolean hasItemOutput() {
        if (function == null) return false;
        for (Entry e : function.always) if (e.kind() == Kind.ITEM) return true;
        for (Recipe r : function.recipes) for (Entry e : r.entries()) if (e.kind() == Kind.ITEM) return true;
        return false;
    }

    public boolean hasInput() {
        if (function == null) return false;
        if (!function.consume.isEmpty() || !function.prices.isEmpty()) return true;
        for (Recipe r : function.recipes) if (!r.consume().isEmpty()) return true;
        return false;
    }

    // ------------------------------------------------------------------ levels

    /** Call once on the level-1 definition after all upgrades were added. */
    public void buildLevels() {
        levels = new BuildingDef[upgrades.size() + 1];
        levels[0] = this;
        for (int i = 0; i < upgrades.size(); i++) levels[i + 1] = levels[i].derive(upgrades.get(i), i + 2, this);
    }

    public BuildingDef root() { return base != null ? base : this; }

    public int maxLevel() { return root().upgrades.size() + 1; }

    /** The effective definition at a level (clamped to 1..maxLevel). */
    public BuildingDef at(int level) {
        BuildingDef r = root();
        if (r.levels == null) return r;
        return r.levels[Math.max(1, Math.min(level, r.levels.length)) - 1];
    }

    private BuildingDef derive(Upgrade u, int lvl, BuildingDef root) {
        BuildingDef d = new BuildingDef();
        d.id = id; d.name = root.name + " &7" + u.label(); d.description = description; d.category = category;
        d.ageId = ageId; d.coreBlock = coreBlock; d.icon = icon; d.shop = shop; d.founding = founding;
        d.obsoleteIn = obsoleteIn; d.tags = tags; d.aliases = aliases; d.replaces = replaces;
        d.rx = u.rx() >= 0 ? u.rx() : rx;
        d.rz = u.rz() >= 0 ? u.rz() : rz;
        d.up = u.up() >= 0 ? u.up() : up;
        d.down = u.down() >= 0 ? u.down() : down;
        d.requirements = new ArrayList<>(requirements);
        for (Req nr : u.requirements()) {
            boolean replaced = false;
            for (int i = 0; i < d.requirements.size(); i++) {
                if (d.requirements.get(i).label().equals(nr.label())) {
                    if (nr.min() > d.requirements.get(i).min()) d.requirements.set(i, nr);
                    replaced = true;
                    break;
                }
            }
            if (!replaced) d.requirements.add(nr);
        }
        d.cost = cost; d.maxPerTown = maxPerTown; d.maxPerPlayer = maxPerPlayer; d.anywhere = anywhere;
        d.inputContainer = inputContainer; d.outputContainer = outputContainer;
        d.inputCore = inputCore; d.outputCore = outputCore; d.stores = stores;
        d.provides = new HashMap<>(provides);
        u.provides().forEach((k, v) -> d.provides.merge(k, v, Double::sum));
        d.level = lvl;
        d.base = root;
        if (function != null) {
            FunctionDef f = function.copy();
            f.recipes.addAll(u.recipes());
            f.always.addAll(u.always());
            if (u.interval() != null) f.interval = u.interval();
            if (u.cap() != null) f.cap = u.cap();
            if (u.maxItems() != null) f.maxItems = u.maxItems();
            if (u.perResident() != null) f.perResident = u.perResident();
            if (u.maxStored() != null) f.maxStored = u.maxStored();
            f.prices.putAll(u.prices());
            d.function = f;
        }
        return d;
    }
}
