package dev.ages.config;

import java.util.List;

/**
 * A requirement tree loaded from YAML: all_of / any_of groups containing leaf conditions.
 * Leaf types: building (id, count, level), tag (id, count), population, members, treasury, points.
 */
public sealed interface Cond {
    record All(List<Cond> items) implements Cond {}

    record Any(List<Cond> items) implements Cond {}

    /** amount = required count / balance. level only for "building". players/villagers only for "population". */
    record Leaf(String type, String id, double amount, int level, boolean players, boolean villagers) implements Cond {}
}
