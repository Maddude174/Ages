package dev.ages.config;

import java.util.HashMap;
import java.util.Map;

/**
 * Combined modifiers from government + economy + policies + buildings.
 * Keys ending in "_mult" multiply (default 1); every other key adds (default 0).
 */
public final class Effects {
    private final Map<String, Double> values = new HashMap<>();

    public void apply(Map<String, Double> mods) {
        if (mods == null) return;
        mods.forEach((k, v) -> {
            if (k.endsWith("_mult")) values.merge(k, v, (a, b) -> a * b);
            else values.merge(k, v, Double::sum);
        });
    }

    public double mult(String key) { return values.getOrDefault(key, 1.0); }

    public double add(String key) { return values.getOrDefault(key, 0.0); }
}
