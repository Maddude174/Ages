package dev.ages.config;

import dev.ages.model.Perm;
import dev.ages.model.Rank;
import org.bukkit.Material;

import java.util.*;

/** A government type: default roles and permissions, how the political leader is chosen, and modifiers/policies. */
public final class GovernmentDef {
    public String id;
    public String name;
    public List<String> description = List.of();
    public Material icon = Material.WHITE_BANNER;
    public String minAge;
    public String leaderTitle = "Leader";
    public String leaderRole;
    public String defaultRole;
    /** owner | appointed | elected */
    public String leaderSelection = "appointed";
    public boolean allowCustomRoles = true;
    public final Map<String, Rank> roles = new LinkedHashMap<>();
    public Map<String, Double> modifiers = new HashMap<>();
    public List<String> policies = new ArrayList<>();
    public int policySlots = 2;
    public BuildingDef.Cost changeCost = BuildingDef.Cost.FREE;
    public int changeCooldownHours = 24;

    /** Used only if no valid government file exists, so the plugin always has a working role set. */
    public static GovernmentDef fallback() {
        GovernmentDef g = new GovernmentDef();
        g.id = "chiefdom";
        g.name = "&6Chiefdom";
        g.leaderTitle = "Chief";
        g.leaderRole = "chief";
        g.defaultRole = "citizen";
        g.leaderSelection = "owner";
        Rank chief = new Rank("chief", 100);
        for (Perm p : Perm.values()) if (!p.ownerOnly) chief.perms.add(p);
        Rank citizen = new Rank("citizen", 40);
        citizen.perms.addAll(List.of(Perm.BUILD, Perm.CONTAINERS, Perm.INTERACT, Perm.USE_SHOP, Perm.PURCHASE_BUILDINGS,
                Perm.PLACE_BUILDINGS, Perm.UPGRADE_BUILDINGS, Perm.REMOVE_BUILDINGS, Perm.CONTRIBUTE, Perm.VIEW_FINANCES, Perm.VOTE));
        g.roles.put("chief", chief);
        g.roles.put("citizen", citizen);
        return g;
    }
}
