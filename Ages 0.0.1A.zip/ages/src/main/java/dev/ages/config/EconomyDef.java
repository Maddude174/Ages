package dev.ages.config;

import org.bukkit.Material;

import java.util.*;

/** An economic system. Independent of the government type: it changes how money, points and contributions behave. */
public final class EconomyDef {
    public String id;
    public String name;
    public List<String> description = List.of();
    public Material icon = Material.EMERALD;
    public String minAge;
    /** false = treasury money outputs are converted to resource points at moneyToPoints, and money contributions are refused. */
    public boolean moneyEnabled = true;
    public double moneyToPoints = 0.5;
    /** Treasury money -> points exchange rate for /ages convert (0 = not allowed). */
    public double exchangeRate = 0;
    public boolean contributionMoney = true;
    /** Base money a role with WITHDRAW_TREASURY may withdraw per 24h (buildings can add to it). 0 = withdrawals disabled. */
    public double withdrawLimit = 0;
    public Map<String, Double> modifiers = new HashMap<>();
    public List<String> policies = new ArrayList<>();
    public int policySlots = 2;
    public BuildingDef.Cost changeCost = BuildingDef.Cost.FREE;
    public int changeCooldownHours = 24;

    public static EconomyDef fallback() {
        EconomyDef e = new EconomyDef();
        e.id = "barter";
        e.name = "&6Barter";
        return e;
    }
}
