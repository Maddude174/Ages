package dev.ages.building;

import dev.ages.config.BuildingDef;
import dev.ages.model.BlockPos;
import dev.ages.util.Text;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Validates a finished build: counts blocks of each required group inside the box
 * (core +/- radii) and locates the input/output containers.
 *
 * Performance: a 41^3 box is ~69k lookups, fine for a one-off check on placement and for
 * debounced revalidation. If it ever shows up in timings, switch to ChunkSnapshots.
 */
public final class Scanner {
    private Scanner() {}

    public record Result(boolean ok, boolean chunkUnloaded, List<String> problems, BlockPos input, BlockPos output) {}

    private static BlockPos at(BlockPos core, long[] c) { return new BlockPos(core.world(), (int) c[1], (int) c[2], (int) c[3]); }

    public static Result scan(World w, BlockPos core, BuildingDef def) {
        int minX = core.x() - def.rx, maxX = core.x() + def.rx;
        int minZ = core.z() - def.rz, maxZ = core.z() + def.rz;
        int minY = Math.max(w.getMinHeight(), core.y() - def.down);
        int maxY = Math.min(w.getMaxHeight() - 1, core.y() + def.up);

        for (int cx = minX >> 4; cx <= maxX >> 4; cx++)
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++)
                if (!w.isChunkLoaded(cx, cz)) return new Result(false, true, List.of("Part of this building is in an unloaded chunk."), null, null);

        int[] counts = new int[def.requirements.size()];
        Material in = def.inputContainer, out = def.outputContainer;
        boolean same = in != null && in == out && !def.inputCore && !def.outputCore;
        // candidates sorted by distance: [distance², x, y, z]
        List<long[]> inCand = new ArrayList<>(), outCand = new ArrayList<>();

        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    Material m = w.getType(x, y, z);
                    if (m.isAir()) continue;
                    for (int i = 0; i < counts.length; i++) if (def.requirements.get(i).materials().contains(m)) counts[i]++;
                    boolean isIn = !def.inputCore && m == in, isOut = !def.outputCore && m == out;
                    if (isIn || isOut) {
                        long dx = x - core.x(), dy = y - core.y(), dz = z - core.z();
                        long[] c = {dx * dx + dy * dy + dz * dz, x, y, z};
                        if (isIn) inCand.add(c);
                        if (isOut && !same) outCand.add(c);
                    }
                }
            }
        }
        inCand.sort((a, b) -> Long.compare(a[0], b[0]));
        outCand.sort((a, b) -> Long.compare(a[0], b[0]));
        BlockPos inPos = null, outPos = null;
        if (def.inputCore) inPos = core;
        if (def.outputCore) outPos = core;
        if (same) {
            // input and output are the same block type: nearest = input, second nearest = output
            if (inCand.size() > 0) inPos = at(core, inCand.get(0));
            if (inCand.size() > 1) outPos = at(core, inCand.get(1));
        } else {
            if (!def.inputCore && !inCand.isEmpty()) inPos = at(core, inCand.get(0));
            if (!def.outputCore && !outCand.isEmpty()) outPos = at(core, outCand.get(0));
        }

        List<String> problems = new ArrayList<>();
        for (int i = 0; i < counts.length; i++) {
            BuildingDef.Req r = def.requirements.get(i);
            if (counts[i] < r.min())
                problems.add("Need " + (r.min() - counts[i]) + " more " + Text.pretty(r.label()) + " (" + counts[i] + "/" + r.min() + ")");
        }
        if (in != null && inPos == null) problems.add("Needs an input " + Text.pretty(in) + " inside the building.");
        if (out != null && outPos == null) problems.add(same ? "Needs a second " + Text.pretty(out) + " (one for input, one for output)." : "Needs an output " + Text.pretty(out) + " inside the building.");
        return new Result(problems.isEmpty(), false, problems, inPos, outPos);
    }
}
