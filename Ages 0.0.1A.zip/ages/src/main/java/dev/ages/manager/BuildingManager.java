package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.building.Scanner;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.config.Registries;
import dev.ages.item.Items;
import dev.ages.model.*;
import dev.ages.util.Containers;
import dev.ages.util.InvUtil;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/** Purchasing rules, placement (transactional), integrity, upgrades and relocation. */
public final class BuildingManager {
    public record Result(boolean ok, List<String> messages, PlacedBuilding building, AgeDef advancedTo, List<PlacedBuilding> retired) {
        static Result fail(String... m) { return new Result(false, List.of(m), null, null, List.of()); }
        static Result fail(List<String> m) { return new Result(false, m, null, null, List.of()); }
    }

    private final AgesPlugin plugin;
    private final Map<UUID, Long> dirty = new LinkedHashMap<>();

    public BuildingManager(AgesPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------------ purchasing

    /** What buying this building (or the next age's core) costs this civilization, after modifiers. */
    public BuildingDef.Cost purchaseCost(Town t, BuildingDef d) {
        AgeDef coreFor = plugin.reg().ageForCore(d.id);
        return plugin.finance().scaled(t, coreFor != null ? coreFor.advanceCost : d.cost);
    }

    /** Null = the player can buy this now; otherwise the first thing in the way. */
    public String purchaseBlocker(Player p, Town t, BuildingDef d) {
        Registries reg = plugin.reg();
        UUID u = p.getUniqueId();
        if (!t.can(u, Perm.USE_SHOP)) return "Your role cannot use the catalogue.";
        if (!t.can(u, Perm.PURCHASE_BUILDINGS)) return "Your role cannot purchase buildings.";
        AgeDef cur = reg.age(t.ageId);
        AgeDef coreFor = reg.ageForCore(d.id);
        if (reg.isObsolete(d, cur)) return "Phased out: not available in the " + Text.plain(cur.name) + ".";
        if (coreFor != null) {
            if (!t.can(u, Perm.ADVANCE_AGE)) return "Your role cannot advance the age.";
            if (coreFor != reg.nextAge(cur)) return "This is not the core of your next age.";
            if (!plugin.progress().eval(t, coreFor.requirements).met()) return "Advancement requirements are not met.";
        } else {
            if (reg.ageOrder(d.ageId) > cur.order) return "Requires a later age.";
            String lim = plugin.limits().check(t, u, d, List.of());
            if (lim != null) return lim;
        }
        return plugin.finance().payProblem(p, t, purchaseCost(t, d));
    }

    // ------------------------------------------------------------------ placement

    /**
     * Validate and register a building core being placed. Everything is checked BEFORE anything changes. For age cores and
     * conversions the new building is validated first and only then are the old ones retired, in one transaction: a failure
     * anywhere leaves the civilization exactly as it was.
     */
    public Result tryPlace(Player p, Town t, BuildingDef base, int level, UUID bid, Block block) {
        Registries reg = plugin.reg();
        TownManager tm = plugin.towns();
        UUID uid = p.getUniqueId();
        AgeDef cur = reg.age(t.ageId);
        AgeDef coreFor = reg.ageForCore(base.id);
        BlockPos pos = BlockPos.of(block);

        if (!t.can(uid, Perm.PLACE_BUILDINGS)) return Result.fail("Your role cannot place buildings.");
        if (reg.isObsolete(base, cur)) return Result.fail("This building is phased out in your age and can no longer be placed.");

        level = Math.max(1, Math.min(level, base.maxLevel()));
        for (int l = 2; l <= level; l++)
            if (reg.ageOrder(base.upgrades.get(l - 2).ageId()) > cur.order) return Result.fail("This level " + level + " core needs a later age than yours.");
        BuildingDef def = base.at(level);

        // ---- age core: requirements and what gets retired
        AgeDef advance = null;
        Set<PlacedBuilding> retire = new LinkedHashSet<>();
        if (coreFor != null) {
            if (!t.can(uid, Perm.ADVANCE_AGE)) return Result.fail("Your role cannot advance the age.");
            if (coreFor != reg.nextAge(cur)) return Result.fail("This is not the core of your next age.");
            Progress.Node n = plugin.progress().eval(t, coreFor.requirements);
            if (!n.met()) return Result.fail(plugin.progress().unmet(n));
            advance = coreFor;
            PlacedBuilding oldCore = tm.core(t.core);
            if (oldCore != null) retire.add(oldCore);
            for (PlacedBuilding b : t.buildings) if (coreFor.retire.contains(b.defId)) retire.add(b);
        } else if (reg.ageOrder(base.ageId) > cur.order) {
            return Result.fail("Your civilization has not reached the age this building needs.");
        }

        // ---- territory
        Town at = tm.at(pos);
        if (def.anywhere) {
            if (at != null && at != t) return Result.fail("You cannot build this on another civilization's land.");
        } else if (at != t) {
            return Result.fail("This must be placed inside your civilization's borders.");
        }

        // ---- conversion / merging: buildings of the replaced types whose core lies inside the new area
        if (!def.replaces.isEmpty()) {
            Set<String> repIds = new HashSet<>();
            for (String r : def.replaces) repIds.add(reg.canonicalBuilding(r));
            for (PlacedBuilding b : t.buildings) {
                if (!repIds.contains(b.defId) || retire.contains(b)) continue;
                boolean inNew = Math.abs(b.core.x() - pos.x()) <= def.rx && Math.abs(b.core.z() - pos.z()) <= def.rz
                        && b.core.y() >= pos.y() - def.down && b.core.y() <= pos.y() + def.up && b.core.world().equals(pos.world());
                if (!inNew && !b.contains(pos)) continue;
                if (!b.owner.equals(uid) && !t.can(uid, Perm.MANAGE_BUILDINGS))
                    return Result.fail("This would replace a building owned by someone else. You need building management rights.");
                retire.add(b);
            }
        }

        // ---- limits (a replacement does not count against its own limit)
        String lim = plugin.limits().check(t, uid, def, retire);
        if (lim != null) return Result.fail(lim);

        PlacedBuilding clash = tm.conflict(pos, def, retire);
        if (clash != null) {
            BuildingDef cd = reg.building(clash.defId);
            return Result.fail("Too close to another building (" + Text.plain(cd == null ? clash.defId : cd.name) + "). Cores may not sit inside another building's area.");
        }

        Scanner.Result scan = Scanner.scan(block.getWorld(), pos, def);
        if (!scan.ok()) return Result.fail(scan.problems());

        // ---- commit
        UUID id = bid != null && tm.building(bid) == null ? bid : UUID.randomUUID();
        PlacedBuilding pb = new PlacedBuilding(id, base.id, t.id, uid, pos);
        pb.level = level;
        pb.setBox(def.rx, def.rz, def.up, def.down);
        pb.input = scan.input();
        pb.output = scan.output();
        List<PlacedBuilding> retired = new ArrayList<>(retire);
        if (!tm.commit(t, pb, retired, advance)) return Result.fail("Something went wrong saving this change. Nothing was changed: your old buildings are intact.");
        return new Result(true, List.of(), pb, advance, retired);
    }

    // ------------------------------------------------------------------ integrity

    public void markDirty(Block b) {
        long now = System.currentTimeMillis();
        for (PlacedBuilding pb : plugin.towns().buildingsAt(BlockPos.of(b))) dirty.putIfAbsent(pb.id, now);
    }

    /** Re-check a few due buildings per call. Block changes mark buildings dirty; the check is debounced. */
    public void processDirty(long now) {
        if (dirty.isEmpty()) return;
        long delay = plugin.reg().settings.revalidateDelaySeconds * 1000L;
        List<PlacedBuilding> due = new ArrayList<>();
        Iterator<Map.Entry<UUID, Long>> it = dirty.entrySet().iterator();
        while (it.hasNext() && due.size() < 4) {
            var e = it.next();
            if (now - e.getValue() < delay) continue;
            it.remove();
            PlacedBuilding pb = plugin.towns().building(e.getKey());
            if (pb != null) due.add(pb);
        }
        for (PlacedBuilding pb : due) revalidate(pb, true);
    }

    /** Re-scan a building. Failing marks it damaged (function off, repairable); a missing core removes it. */
    public Scanner.Result revalidate(PlacedBuilding pb, boolean notify) {
        Registries reg = plugin.reg();
        BuildingDef def = reg.effective(pb);
        Town t = plugin.towns().byId(pb.townId);
        if (def == null || t == null) return null;
        World w = Bukkit.getWorld(pb.core.world());
        if (w == null || !w.isChunkLoaded(pb.core.x() >> 4, pb.core.z() >> 4)) return null;

        if (w.getType(pb.core.x(), pb.core.y(), pb.core.z()) != def.coreBlock) {
            if (notify) tell(pb, "&cYour " + def.name + " &cwas destroyed.");
            plugin.towns().removeBuilding(t, pb);
            return null;
        }
        Scanner.Result r = Scanner.scan(w, pb.core, def);
        if (r.chunkUnloaded()) return r;
        boolean was = pb.damaged;
        boolean moved = !Objects.equals(pb.input, r.input()) || !Objects.equals(pb.output, r.output());
        pb.damaged = !r.ok();
        if (r.input() != null) pb.input = r.input();
        if (r.output() != null) pb.output = r.output();
        if (was != pb.damaged || moved) {
            plugin.db().saveBuilding(pb);
            plugin.towns().recomputeClaims(t);
            plugin.logistics().invalidate(pb);
            if (notify) {
                if (pb.damaged) tell(pb, "&cYour " + def.name + " &cis damaged: " + r.problems().get(0));
                else tell(pb, "&aYour " + def.name + " &ahas been repaired.");
            }
        }
        return r;
    }

    private void tell(PlacedBuilding pb, String msg) {
        Player p = Bukkit.getPlayer(pb.owner);
        if (p != null) Text.msg(p, msg);
    }

    /** A building whose core block was blown up or otherwise removed. */
    public void coreDestroyed(PlacedBuilding pb) {
        Town t = plugin.towns().byId(pb.townId);
        if (t == null) return;
        BuildingDef d = plugin.reg().effective(pb);
        tell(pb, "&cYour " + (d == null ? pb.defId : d.name) + " &cwas destroyed.");
        plugin.towns().removeBuilding(t, pb);
    }

    // ------------------------------------------------------------------ removal / relocation

    /** Null if the player may remove this building's core; otherwise why not. */
    public String removeBlocker(Player p, Town t, PlacedBuilding pb) {
        UUID u = p.getUniqueId();
        if (plugin.towns().isTownCore(pb.core)) return "The core of your current age cannot be removed.";
        boolean own = pb.owner.equals(u);
        if (own ? !(t.can(u, Perm.REMOVE_BUILDINGS) || t.can(u, Perm.MANAGE_BUILDINGS)) : !t.can(u, Perm.MANAGE_BUILDINGS))
            return own ? "Your role cannot remove buildings." : "Only the owner (or someone with building management rights) can remove this.";
        return null;
    }

    /**
     * Unregister the building and hand back its core item (keeping level and identity) so it can be placed elsewhere.
     * A chest/barrel core's contents are returned too, never destroyed. breaking = the block was broken by the player
     * (the item and contents drop at the block), otherwise the block is removed and everything goes to the player.
     */
    public String removeCore(Player p, Town t, PlacedBuilding pb, boolean breaking) {
        String why = removeBlocker(p, t, pb);
        if (why != null) return why;
        BuildingDef base = plugin.reg().building(pb.defId);
        Block block = pb.core.block();
        List<ItemStack> contents = new ArrayList<>();
        if (block != null && Containers.isContainer(block.getType()) && block.getState(false) instanceof Container c) {
            Inventory inv = c.getInventory();
            for (ItemStack s : inv.getContents()) if (s != null) contents.add(s.clone());
            inv.clear();
        }
        plugin.towns().removeBuilding(t, pb);
        if (!breaking && block != null) block.setType(Material.AIR);
        ItemStack item = base == null ? null : Items.core(base, pb.level, pb.id);
        if (breaking && block != null) {
            var loc = block.getLocation().add(0.5, 0.5, 0.5);
            if (item != null) block.getWorld().dropItemNaturally(loc, item);
            for (ItemStack s : contents) block.getWorld().dropItemNaturally(loc, s);
        } else {
            if (item != null) InvUtil.give(p, item);
            for (ItemStack s : contents) InvUtil.give(p, s);
        }
        return null;
    }

    // ------------------------------------------------------------------ recipe selection

    public String selectRecipe(Player p, Town t, PlacedBuilding pb, String recipeId) {
        UUID u = p.getUniqueId();
        if (!(pb.owner.equals(u) || t.can(u, Perm.MANAGE_BUILDINGS))) return "Only the owner or a manager can change the recipe.";
        pb.recipe = recipeId;
        pb.lastStatus = "";
        plugin.towns().markDirty(pb);
        return null;
    }

    // ------------------------------------------------------------------ upgrades

    public BuildingDef.Upgrade nextUpgrade(PlacedBuilding pb) {
        BuildingDef base = plugin.reg().building(pb.defId);
        if (base == null || pb.level >= base.maxLevel()) return null;
        return base.upgrades.get(pb.level - 1);
    }

    public BuildingDef.Cost upgradeCost(Town t, PlacedBuilding pb) {
        BuildingDef.Upgrade u = nextUpgrade(pb);
        return u == null ? BuildingDef.Cost.FREE : plugin.finance().scaled(t, u.cost());
    }

    /** Cheap pre-checks (permission, age, damage, affordability). Null = nothing blocks the attempt. */
    public String upgradeBlocker(Player p, Town t, PlacedBuilding pb) {
        Registries reg = plugin.reg();
        UUID uid = p.getUniqueId();
        BuildingDef.Upgrade u = nextUpgrade(pb);
        if (u == null) return "Already at the maximum level.";
        boolean own = pb.owner.equals(uid);
        if (own ? !(t.can(uid, Perm.UPGRADE_BUILDINGS) || t.can(uid, Perm.MANAGE_BUILDINGS)) : !t.can(uid, Perm.MANAGE_BUILDINGS))
            return own ? "Your role cannot upgrade buildings." : "Only the owner or someone with building management rights can upgrade this.";
        AgeDef cur = reg.age(t.ageId);
        AgeDef need = reg.age(u.ageId());
        if (need != null && need.order > cur.order) return "Requires the " + Text.plain(need.name) + ".";
        if (pb.damaged) return "Repair the building first.";
        return plugin.finance().payProblem(p, t, upgradeCost(t, pb));
    }

    /** Try to upgrade. Returns the problems; an EMPTY list means success. The scan runs before anything is charged. */
    public List<String> tryUpgrade(Player p, Town t, PlacedBuilding pb) {
        Registries reg = plugin.reg();
        TownManager tm = plugin.towns();
        String blocker = upgradeBlocker(p, t, pb);
        if (blocker != null) return List.of(blocker);
        BuildingDef base = reg.building(pb.defId);
        BuildingDef next = base.at(pb.level + 1);
        World w = Bukkit.getWorld(pb.core.world());
        if (w == null) return List.of("World not loaded.");
        if (tm.conflict(pb.core, next, List.of(pb)) != null) return List.of("The larger area would overlap another building.");
        if (!next.anywhere) {
            int[][] corners = {{-next.rx, -next.rz}, {next.rx, -next.rz}, {-next.rx, next.rz}, {next.rx, next.rz}};
            for (int[] c : corners) {
                Town at = tm.at(new BlockPos(pb.core.world(), pb.core.x() + c[0], pb.core.y(), pb.core.z() + c[1]));
                if (at != null && at != t) return List.of("The larger area would reach into another civilization's land.");
            }
        }
        Scanner.Result scan = Scanner.scan(w, pb.core, next);
        if (!scan.ok()) return scan.problems();
        plugin.finance().pay(p, t, upgradeCost(t, pb), "UPGRADE", "Upgraded " + Text.plain(base.name) + " to level " + next.level);
        tm.upgrade(t, pb, next, scan);
        return List.of();
    }
}
