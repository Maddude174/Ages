package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.config.Registries;
import dev.ages.config.Settings;
import dev.ages.model.BlockPos;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Town;
import dev.ages.util.InvUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.inventory.Inventory;

import java.util.*;

/**
 * Rail logistics. Rails connect buildings into networks; goods then move VIRTUALLY (no minecarts) from
 * output containers to input containers that need them.
 *
 * Network discovery: a building's "ports" are the rails on the shell of its area (box + 1 block). Rails that touch
 * each other (including up/down slopes) form one network, and every building with a port on it is a node. One long
 * connected railway therefore links a whole city, with no per-pair rails.
 *
 * Each run, per town on a network:
 *   0. storage hubs sort their input barrel into their output chest
 *   A. producers send items directly to buildings that need them (needs() = recipe ingredients, tools, sellable goods)
 *   B. what nobody needs goes to a storage hub
 *   C. buildings still short of an ingredient pull it from storage
 * Throughput is capped per building and per network. Only loaded chunks take part. Main thread only.
 */
public final class Logistics implements Runnable {
    private static final long FORCE_REBUILD_MS = 60_000;

    private static final class Network {
        final Set<BlockPos> rails = new HashSet<>();
        final List<PlacedBuilding> buildings = new ArrayList<>();
    }

    private static final class Node {
        final PlacedBuilding b;
        final BuildingDef d;
        final Inventory in, out;
        final boolean storage;
        int inLeft, outLeft;

        Node(PlacedBuilding b, BuildingDef d, Inventory in, Inventory out, int budget) {
            this.b = b; this.d = d; this.in = in; this.out = out;
            this.storage = d.provide("storage") > 0;
            this.inLeft = budget; this.outLeft = budget;
        }
    }

    private final AgesPlugin plugin;
    private final Map<UUID, List<BlockPos>> ports = new HashMap<>();
    private List<Network> networks = List.of();
    private boolean dirty = true;
    private long lastBuild;

    public Logistics(AgesPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------------ invalidation

    /** A building was added, removed or resized: its ports and every network must be recomputed. */
    public void invalidate(PlacedBuilding b) {
        ports.remove(b.id);
        dirty = true;
    }

    /** A rail was placed or broken: buildings whose area (box + 1) contains it get fresh ports. */
    public void railChanged(Block rail) {
        TownManager tm = plugin.towns();
        BlockPos p = BlockPos.of(rail);
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
                for (int dz = -1; dz <= 1; dz++)
                    for (PlacedBuilding b : tm.buildingsAt(new BlockPos(p.world(), p.x() + dx, p.y() + dy, p.z() + dz))) ports.remove(b.id);
        dirty = true;
    }

    // ------------------------------------------------------------------ discovery

    private boolean logistic(BuildingDef d) { return d != null && (d.inputContainer != null || d.outputContainer != null); }

    private static boolean isRail(World w, int x, int y, int z) {
        return y >= w.getMinHeight() && y < w.getMaxHeight() && w.isChunkLoaded(x >> 4, z >> 4) && Tag.RAILS.isTagged(w.getType(x, y, z));
    }

    /** Rails on the six faces of the building's area expanded by one block. Null = chunks not loaded (retry later). */
    private List<BlockPos> portsOf(PlacedBuilding b) {
        List<BlockPos> cached = ports.get(b.id);
        if (cached != null) return cached;
        World w = Bukkit.getWorld(b.core.world());
        if (w == null) return null;
        int x0 = b.minX - 1, x1 = b.maxX + 1, z0 = b.minZ - 1, z1 = b.maxZ + 1;
        int y0 = Math.max(w.getMinHeight(), b.minY - 1), y1 = Math.min(w.getMaxHeight() - 1, b.maxY + 1);
        for (int cx = x0 >> 4; cx <= x1 >> 4; cx++)
            for (int cz = z0 >> 4; cz <= z1 >> 4; cz++)
                if (!w.isChunkLoaded(cx, cz)) return null;

        List<BlockPos> out = new ArrayList<>();
        for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) {
            if (isRail(w, x, y0, z)) out.add(new BlockPos(b.core.world(), x, y0, z));
            if (y1 != y0 && isRail(w, x, y1, z)) out.add(new BlockPos(b.core.world(), x, y1, z));
        }
        for (int y = y0 + 1; y < y1; y++) {
            for (int z = z0; z <= z1; z++) {
                if (isRail(w, x0, y, z)) out.add(new BlockPos(b.core.world(), x0, y, z));
                if (x1 != x0 && isRail(w, x1, y, z)) out.add(new BlockPos(b.core.world(), x1, y, z));
            }
            for (int x = x0 + 1; x < x1; x++) {
                if (isRail(w, x, y, z0)) out.add(new BlockPos(b.core.world(), x, y, z0));
                if (z1 != z0 && isRail(w, x, y, z1)) out.add(new BlockPos(b.core.world(), x, y, z1));
            }
        }
        if (out.size() > 200) out = new ArrayList<>(out.subList(0, 200));
        ports.put(b.id, out);
        return out;
    }

    private void rebuild() {
        dirty = false;
        lastBuild = System.currentTimeMillis();
        Registries reg = plugin.reg();
        int cap = reg.settings.maxRailsPerNetwork;
        Map<BlockPos, Network> railToNet = new HashMap<>();
        List<Network> out = new ArrayList<>();
        List<PlacedBuilding> nodes = new ArrayList<>();

        for (Town t : plugin.towns().all()) {
            for (PlacedBuilding b : t.buildings) {
                if (b.damaged || !logistic(reg.effective(b))) continue;
                List<BlockPos> ps = portsOf(b);
                if (ps == null || ps.isEmpty()) continue;
                nodes.add(b);
                for (BlockPos port : ps) {
                    if (railToNet.containsKey(port)) continue;
                    Network n = new Network();
                    flood(port, n, railToNet, cap);
                    out.add(n);
                }
            }
        }
        Map<Network, Set<PlacedBuilding>> members = new HashMap<>();
        for (PlacedBuilding b : nodes) {
            for (BlockPos port : ports.getOrDefault(b.id, List.of())) {
                Network n = railToNet.get(port);
                if (n != null) members.computeIfAbsent(n, k -> new LinkedHashSet<>()).add(b);
            }
        }
        for (var e : members.entrySet()) e.getKey().buildings.addAll(e.getValue());
        out.removeIf(n -> n.buildings.size() < 2);
        networks = out;
    }

    private void flood(BlockPos start, Network n, Map<BlockPos, Network> seen, int cap) {
        World w = Bukkit.getWorld(start.world());
        if (w == null) return;
        Deque<BlockPos> q = new ArrayDeque<>();
        q.add(start);
        seen.put(start, n);
        n.rails.add(start);
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        while (!q.isEmpty() && n.rails.size() < cap) {
            BlockPos p = q.poll();
            for (int[] d : dirs) {
                for (int dy = -1; dy <= 1; dy++) {
                    int x = p.x() + d[0], y = p.y() + dy, z = p.z() + d[1];
                    BlockPos np = new BlockPos(p.world(), x, y, z);
                    if (seen.containsKey(np) || !isRail(w, x, y, z)) continue;
                    seen.put(np, n);
                    n.rails.add(np);
                    q.add(np);
                }
            }
        }
    }

    // ------------------------------------------------------------------ the run

    @Override
    public void run() {
        Settings s = plugin.reg().settings;
        if (!s.logisticsEnabled) return;
        try {
            if (dirty || System.currentTimeMillis() - lastBuild > FORCE_REBUILD_MS) rebuild();
            for (Network n : networks) {
                Map<UUID, List<PlacedBuilding>> byTown = new HashMap<>();
                for (PlacedBuilding b : n.buildings) byTown.computeIfAbsent(b.townId, k -> new ArrayList<>()).add(b);
                for (List<PlacedBuilding> group : byTown.values()) process(group, s);
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Logistics error: " + e);
        }
    }

    private Inventory inv(BlockPos p) {
        if (p == null) return null;
        World w = Bukkit.getWorld(p.world());
        if (w == null || !w.isChunkLoaded(p.x() >> 4, p.z() >> 4)) return null;
        return w.getBlockAt(p.x(), p.y(), p.z()).getState(false) instanceof Container c ? c.getInventory() : null;
    }

    private void process(List<PlacedBuilding> group, Settings s) {
        if (group.size() < 2) return;
        Registries reg = plugin.reg();
        Town town = plugin.towns().byId(group.get(0).townId);
        AgeDef townAge = town == null ? null : reg.age(town.ageId);
        if (townAge == null || !townAge.rails) return; // automation unlocks with the age's `rails: true`
        List<Node> nodes = new ArrayList<>();
        for (PlacedBuilding b : group) {
            BuildingDef d = reg.effective(b);
            if (b.damaged || d == null) continue;
            Inventory in = inv(b.input);
            Inventory out = b.output != null && b.output.equals(b.input) ? in : inv(b.output);   // a chest core is one inventory
            if (in == null && out == null) continue;
            nodes.add(new Node(b, d, in, out, s.itemsPerBuildingPerRun));
        }
        int cap = s.itemsPerNetworkPerRun;
        for (Node n : nodes) cap += (int) n.d.provide("logistics_capacity"); // railway stations etc. raise the throughput
        int[] budget = {cap};
        List<Node> storages = new ArrayList<>();
        for (Node n : nodes) if (n.storage) storages.add(n);

        // 0. storage hubs make delivered goods available in their output chest
        for (Node st : storages) {
            if (st.in == null || st.out == null || st.in == st.out) continue;
            for (Material m : materials(st.in)) {
                int moved = InvUtil.move(st.in, st.out, m, Math.min(st.inLeft, budget[0]));
                st.inLeft -= moved; budget[0] -= moved;
            }
        }

        List<Node> demanders = new ArrayList<>();
        for (Node n : nodes) if (n.in != null && !n.d.needs().isEmpty()) demanders.add(n);

        // A + B. producers: direct delivery first, surplus to storage
        List<Node> sources = new ArrayList<>(nodes);
        Collections.shuffle(sources);
        for (Node src : sources) {
            if (src.storage || src.out == null) continue;
            for (Material m : materials(src.out)) {
                if (src.outLeft <= 0 || budget[0] <= 0) break;
                if (src.in == src.out && src.d.needs().containsKey(m)) continue; // a chest core: its own ingredients are not 'output'
                List<Node> want = new ArrayList<>(demanders);
                Collections.shuffle(want);
                for (Node dst : want) {
                    if (dst == src || src.outLeft <= 0 || budget[0] <= 0) continue;
                    Integer target = dst.d.needs().get(m);
                    if (target == null) continue;
                    int deficit = target - InvUtil.count(dst.in, m);
                    if (deficit <= 0) continue;
                    int moved = InvUtil.move(src.out, dst.in, m, Math.min(deficit, Math.min(src.outLeft, Math.min(dst.inLeft, budget[0]))));
                    src.outLeft -= moved; dst.inLeft -= moved; budget[0] -= moved;
                }
                for (Node st : storages) {
                    if (st == src || st.in == null || src.outLeft <= 0 || budget[0] <= 0 || !accepts(st, m)) continue;
                    int moved = InvUtil.move(src.out, st.in, m, Math.min(src.outLeft, Math.min(st.inLeft, budget[0])));
                    src.outLeft -= moved; st.inLeft -= moved; budget[0] -= moved;
                }
            }
        }

        // C. buildings still short of an ingredient pull it from storage
        for (Node dst : demanders) {
            if (dst.storage) continue;
            for (var need : dst.d.needs().entrySet()) {
                Material m = need.getKey();
                int deficit = need.getValue() - InvUtil.count(dst.in, m);
                if (deficit <= 0) continue;
                for (Node st : storages) {
                    if (st.out == null || deficit <= 0 || dst.inLeft <= 0 || budget[0] <= 0) continue;
                    int moved = InvUtil.move(st.out, dst.in, m, Math.min(deficit, Math.min(st.outLeft, Math.min(dst.inLeft, budget[0]))));
                    deficit -= moved; st.outLeft -= moved; dst.inLeft -= moved; budget[0] -= moved;
                }
            }
        }
    }

    private static boolean isFood(Material m) {
        return m.isEdible() || m == Material.WHEAT || m == Material.SUGAR || m == Material.EGG || m == Material.WHEAT_SEEDS
                || m == Material.BEETROOT_SEEDS || m == Material.COCOA_BEANS || m == Material.HONEYCOMB;
    }

    /** Storage hubs may only take what their `logistics.stores` allows (granary = food, storehouse = goods). */
    private static boolean accepts(Node st, Material m) {
        return switch (st.d.stores) {
            case "food" -> isFood(m);
            case "goods" -> !isFood(m);
            default -> true;
        };
    }

    private static Set<Material> materials(Inventory inv) {
        Set<Material> out = EnumSet.noneOf(Material.class);
        for (var s : inv.getContents()) if (s != null) out.add(s.getType());
        return out;
    }

    // ------------------------------------------------------------------ info

    /** Human-readable summary of the networks a town's buildings are on. */
    public List<String> describe(Town t) {
        if (dirty) rebuild();
        List<String> out = new ArrayList<>();
        Registries reg = plugin.reg();
        int i = 1;
        for (Network n : networks) {
            List<PlacedBuilding> mine = n.buildings.stream().filter(b -> b.townId.equals(t.id)).toList();
            if (mine.isEmpty()) continue;
            Map<String, Integer> counts = new TreeMap<>();
            for (PlacedBuilding b : mine) {
                BuildingDef d = reg.effective(b);
                counts.merge(d == null ? b.defId : dev.ages.util.Text.plain(d.name), 1, Integer::sum);
            }
            StringJoiner j = new StringJoiner(", ");
            counts.forEach((k, v) -> j.add(v + "x " + k));
            out.add("Network " + i++ + ": " + n.rails.size() + " rails, " + mine.size() + " buildings (" + j + ")");
        }
        return out;
    }
}
