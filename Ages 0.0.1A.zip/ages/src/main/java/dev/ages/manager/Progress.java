package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.config.BuildingDef;
import dev.ages.config.Cond;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Town;
import dev.ages.util.Text;

import java.util.ArrayList;
import java.util.List;

/** Evaluates requirement trees (all_of / any_of) against a civilization and renders them as a checklist. */
public final class Progress {
    private final AgesPlugin plugin;

    public Progress(AgesPlugin plugin) { this.plugin = plugin; }

    /** group = an all_of/any_of node (kids set). A leaf has no kids. */
    public record Node(boolean met, String text, List<Node> kids, boolean any) {
        public boolean isGroup() { return !kids.isEmpty(); }
    }

    public Node eval(Town t, Cond c) {
        if (c == null) return new Node(true, "No requirements", List.of(), false);
        if (c instanceof Cond.All a) {
            List<Node> kids = new ArrayList<>();
            boolean met = true;
            for (Cond x : a.items()) { Node n = eval(t, x); kids.add(n); met &= n.met(); }
            return new Node(met, "All of:", kids, false);
        }
        if (c instanceof Cond.Any a) {
            List<Node> kids = new ArrayList<>();
            boolean met = false;
            for (Cond x : a.items()) { Node n = eval(t, x); kids.add(n); met |= n.met(); }
            return new Node(met, "Any one of:", kids, true);
        }
        return leaf(t, (Cond.Leaf) c);
    }

    private Node leaf(Town t, Cond.Leaf l) {
        switch (l.type()) {
            case "building" -> {
                BuildingDef d = plugin.reg().building(l.id());
                int have = t.count(plugin.reg().canonicalBuilding(l.id()), l.level());
                int need = (int) l.amount();
                String name = d == null ? l.id() : Text.plain(d.root().name);
                String lvl = l.level() > 1 ? " (level " + l.level() + "+)" : "";
                return new Node(have >= need, name + lvl + ": " + Math.min(have, need) + "/" + need, List.of(), false);
            }
            case "tag" -> {
                double have = plugin.limits().tagUsage(t, l.id(), null, List.of());
                return new Node(have >= l.amount(), Text.pretty(l.id()) + ": " + (long) Math.min(have, l.amount()) + "/" + (long) l.amount(), List.of(), false);
            }
            case "population" -> {
                int have = t.population(l.players(), l.villagers());
                String what = l.players() && l.villagers() ? "players and villagers" : l.players() ? "players" : "villagers";
                return new Node(have >= l.amount(), "Population (" + what + "): " + Math.min(have, (int) l.amount()) + "/" + (int) l.amount(), List.of(), false);
            }
            case "members" -> {
                return new Node(t.members.size() >= l.amount(), "Members: " + Math.min(t.members.size(), (int) l.amount()) + "/" + (int) l.amount(), List.of(), false);
            }
            case "treasury" -> {
                return new Node(t.money >= l.amount(), "Treasury: " + Text.num(Math.min(t.money, l.amount())) + "/" + Text.num(l.amount()), List.of(), false);
            }
            case "points" -> {
                return new Node(t.points >= l.amount(), "Resource points: " + Text.num(Math.min(t.points, l.amount())) + "/" + Text.num(l.amount()), List.of(), false);
            }
            default -> {
                return new Node(false, "Unknown requirement " + l.type(), List.of(), false);
            }
        }
    }

    /** Checklist lines for chat/lore: "&a✔ text" / "&c✘ text", groups indented. */
    public List<String> lines(Node n, int indent) {
        List<String> out = new ArrayList<>();
        String pad = "  ".repeat(indent);
        if (n.isGroup()) {
            if (indent > 0) out.add(pad + (n.met() ? "&a✔ " : "&c✘ ") + "&7" + n.text());
            for (Node k : n.kids()) out.addAll(lines(k, indent + (indent == 0 && !n.any() ? 0 : 1)));
        } else {
            out.add(pad + (n.met() ? "&a✔ &7" : "&c✘ &f") + n.text());
        }
        return out;
    }

    /** Unmet leaves only (for short error messages). For an any_of group, one line summarising the choice. */
    public List<String> unmet(Node n) {
        List<String> out = new ArrayList<>();
        if (n.met()) return out;
        if (!n.isGroup()) { out.add(n.text()); return out; }
        if (n.any()) {
            List<String> opts = new ArrayList<>();
            for (Node k : n.kids()) opts.add(k.isGroup() ? "(" + String.join(", ", unmet(k)) + ")" : k.text());
            out.add("One of: " + String.join("  OR  ", opts));
        } else {
            for (Node k : n.kids()) out.addAll(unmet(k));
        }
        return out;
    }
}
