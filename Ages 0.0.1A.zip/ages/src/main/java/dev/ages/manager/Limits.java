package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.config.Effects;
import dev.ages.config.Registries;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Town;
import dev.ages.util.Text;

import java.util.*;

/**
 * Building limits at three levels, all checked together:
 *   1. the building itself   (limits.max_per_town / max_per_player in its YAML, plus the age's building_limits)
 *   2. shared TAG pools      (tags: [housing] on buildings; caps in settings.yml limits.tags and the age's tag_limits)
 *   3. per-civilization caps, so a big civilization cannot bypass limits by having every member place the maximum
 * The strictest non-zero cap wins. Modifiers can raise tag caps (tag_limit_add.<tag>).
 */
public final class Limits {
    private final AgesPlugin plugin;

    public Limits(AgesPlugin plugin) { this.plugin = plugin; }

    /** Weighted usage of a tag, optionally for one player, ignoring buildings that are about to be replaced. */
    public double tagUsage(Town t, String tag, UUID player, Collection<PlacedBuilding> ignore) {
        double used = 0;
        Registries reg = plugin.reg();
        for (PlacedBuilding b : t.buildings) {
            if (ignore.contains(b) || (player != null && !b.owner.equals(player))) continue;
            BuildingDef d = reg.building(b.defId);
            if (d != null) used += d.tags.getOrDefault(tag, 0.0);
        }
        return used;
    }

    /** {perPlayer, perTown} effective caps for a tag (0 = unlimited). */
    public int[] tagCaps(Town t, String tag) {
        Registries reg = plugin.reg();
        AgeDef age = reg.age(t.ageId);
        int[] a = reg.settings.tagLimits.getOrDefault(tag, new int[]{0, 0});
        int[] b = age == null ? new int[]{0, 0} : age.tagLimits.getOrDefault(tag, new int[]{0, 0});
        int perPlayer = strict(a[0], b[0]);
        int perTown = strict(a[1], b[1]);
        Effects fx = plugin.governance().effects(t);
        int bonus = (int) Math.round(fx.add("tag_limit_add." + tag));
        if (perTown > 0) perTown += bonus;
        if (perPlayer > 0) perPlayer += bonus > 0 ? Math.max(1, bonus / 2) : 0;
        return new int[]{perPlayer, perTown};
    }

    public int buildingTownCap(Town t, BuildingDef d) {
        AgeDef age = plugin.reg().age(t.ageId);
        return strict(d.maxPerTown, age == null ? 0 : age.limits.getOrDefault(d.id, 0));
    }

    private static int strict(int a, int b) {
        if (a > 0 && b > 0) return Math.min(a, b);
        return Math.max(a, b);
    }

    /** Null if one more of this building may be placed; otherwise the reason. */
    public String check(Town t, UUID player, BuildingDef d, Collection<PlacedBuilding> ignore) {
        String name = Text.plain(d.root().name);
        int town = 0, mine = 0;
        for (PlacedBuilding b : t.buildings) {
            if (ignore.contains(b) || !b.defId.equals(d.id)) continue;
            town++;
            if (b.owner.equals(player)) mine++;
        }
        int townCap = buildingTownCap(t, d);
        if (townCap > 0 && town >= townCap) return "Your civilization already has the maximum " + townCap + " x " + name + ".";
        if (d.maxPerPlayer > 0 && mine >= d.maxPerPlayer) return "You already own the maximum " + d.maxPerPlayer + " x " + name + ".";
        for (Map.Entry<String, Double> tag : d.tags.entrySet()) {
            int[] caps = tagCaps(t, tag.getKey());
            double w = tag.getValue();
            String label = Text.pretty(tag.getKey());
            if (caps[1] > 0) {
                double used = tagUsage(t, tag.getKey(), null, ignore);
                if (used + w > caps[1] + 1e-9) return label + " limit of the civilization reached (" + fmt(used) + "/" + caps[1] + " used, this needs " + fmt(w) + ").";
            }
            if (caps[0] > 0) {
                double used = tagUsage(t, tag.getKey(), player, ignore);
                if (used + w > caps[0] + 1e-9) return "Your personal " + label + " limit is reached (" + fmt(used) + "/" + caps[0] + " used, this needs " + fmt(w) + ").";
            }
        }
        return null;
    }

    /** Lines for the GUI: how much of each relevant limit is used. */
    public List<String> describe(Town t, UUID player, BuildingDef d) {
        List<String> out = new ArrayList<>();
        int townCap = buildingTownCap(t, d);
        if (townCap > 0) out.add("&7Civilization: &f" + t.countAll(d.id) + "/" + townCap);
        if (d.maxPerPlayer > 0) out.add("&7You: &f" + t.countOwned(player, d.id) + "/" + d.maxPerPlayer);
        for (String tag : d.tags.keySet()) {
            int[] caps = tagCaps(t, tag);
            if (caps[1] > 0) out.add("&7" + Text.pretty(tag) + " (civilization): &f" + fmt(tagUsage(t, tag, null, List.of())) + "/" + caps[1]);
            if (caps[0] > 0) out.add("&7" + Text.pretty(tag) + " (you): &f" + fmt(tagUsage(t, tag, player, List.of())) + "/" + caps[0]);
        }
        return out;
    }

    private static String fmt(double v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.format("%.1f", v); }
}
