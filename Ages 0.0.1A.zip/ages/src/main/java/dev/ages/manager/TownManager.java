package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.config.GovernmentDef;
import dev.ages.config.Registries;
import dev.ages.model.*;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;

import java.util.*;
import java.util.function.Consumer;

/** Runtime state: civilizations, members, territory claims, building indexes and write-behind persistence. Main thread only. */
public final class TownManager {
    private final AgesPlugin plugin;
    private final Map<UUID, Town> towns = new HashMap<>();
    private final Map<String, Town> byName = new HashMap<>();
    private final Map<UUID, UUID> playerTown = new HashMap<>();
    private final Map<ChunkKey, UUID> claims = new HashMap<>();
    private final Map<UUID, Set<ChunkKey>> townChunks = new HashMap<>();
    private final Map<UUID, PlacedBuilding> byId = new HashMap<>();
    private final Map<BlockPos, PlacedBuilding> byCore = new HashMap<>();
    private final Map<ChunkKey, List<PlacedBuilding>> byChunk = new HashMap<>();

    // write-behind: frequently changing state (production timers, income) is flushed periodically, not per change
    private final Set<PlacedBuilding> dirtyBuildings = new LinkedHashSet<>();
    private final Set<Town> dirtyTowns = new LinkedHashSet<>();
    private final Map<Tx, UUID> dirtyTx = new LinkedHashMap<>();

    public TownManager(AgesPlugin plugin) { this.plugin = plugin; }

    public void load(List<Town> list) { for (Town t : list) register(t); }

    private void register(Town t) {
        towns.put(t.id, t);
        byName.put(t.name.toLowerCase(), t);
        for (UUID u : t.members.keySet()) playerTown.put(u, t.id);
        for (PlacedBuilding b : t.buildings) index(b);
        plugin.tracked().refreshTown(t);
        recomputeClaims(t);
    }

    // ------------------------------------------------------------------ lookups

    public Collection<Town> all() { return towns.values(); }
    public Town byId(UUID id) { return towns.get(id); }
    public Town byName(String n) { return byName.get(n.toLowerCase()); }
    public Town of(UUID player) { UUID id = playerTown.get(player); return id == null ? null : towns.get(id); }
    public Town at(BlockPos p) { UUID id = claims.get(p.chunk()); return id == null ? null : towns.get(id); }
    public Town at(Block b) { return at(BlockPos.of(b)); }
    public Town at(Location l) { return at(BlockPos.of(l)); }
    public PlacedBuilding building(UUID id) { return byId.get(id); }
    public PlacedBuilding core(BlockPos p) { return byCore.get(p); }

    public boolean isTownCore(BlockPos p) {
        PlacedBuilding b = byCore.get(p);
        if (b == null) return false;
        Town t = towns.get(b.townId);
        return t != null && t.core.equals(p);
    }

    public List<PlacedBuilding> buildingsAt(BlockPos p) {
        List<PlacedBuilding> l = byChunk.get(p.chunk());
        if (l == null) return List.of();
        List<PlacedBuilding> out = new ArrayList<>();
        for (PlacedBuilding b : l) if (b.contains(p)) out.add(b);
        return out;
    }

    /** The building whose input or output container is at this position, if any. */
    public PlacedBuilding containerOf(BlockPos p) {
        for (PlacedBuilding b : buildingsAt(p)) if (p.equals(b.input) || p.equals(b.output)) return b;
        return null;
    }

    /** A building that would clash with a new one (core inside the other's box or vice versa), ignoring those being replaced. */
    public PlacedBuilding conflict(BlockPos core, BuildingDef def, Collection<PlacedBuilding> ignore) {
        int minX = core.x() - def.rx, maxX = core.x() + def.rx;
        int minY = core.y() - def.down, maxY = core.y() + def.up;
        int minZ = core.z() - def.rz, maxZ = core.z() + def.rz;
        Set<PlacedBuilding> seen = new HashSet<>();
        for (int cx = minX >> 4; cx <= maxX >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++) {
                List<PlacedBuilding> l = byChunk.get(new ChunkKey(core.world(), cx, cz));
                if (l == null) continue;
                for (PlacedBuilding o : l) {
                    if (ignore.contains(o) || !seen.add(o)) continue;
                    BlockPos oc = o.core;
                    boolean oldCoreInNew = oc.world().equals(core.world())
                            && oc.x() >= minX && oc.x() <= maxX && oc.y() >= minY && oc.y() <= maxY && oc.z() >= minZ && oc.z() <= maxZ;
                    if (oldCoreInNew || o.contains(core)) return o;
                }
            }
        }
        return null;
    }

    public int housing(Town t) {
        double h = 0;
        Registries reg = plugin.reg();
        for (PlacedBuilding b : t.buildings) {
            BuildingDef d = reg.effective(b);
            if (d != null && !b.damaged) h += d.provide("housing");
        }
        return (int) Math.round(h * plugin.governance().effects(t).mult("housing_mult"));
    }

    public PlacedBuilding respawnPoint(Town t, Location from) {
        Registries reg = plugin.reg();
        PlacedBuilding best = null;
        double bestD = Double.MAX_VALUE;
        for (PlacedBuilding b : t.buildings) {
            BuildingDef d = reg.effective(b);
            if (d == null || b.damaged || d.provide("respawn_point") <= 0 || !b.core.world().equals(from.getWorld().getName())) continue;
            double dx = b.core.x() - from.getX(), dz = b.core.z() - from.getZ();
            double dist = dx * dx + dz * dz;
            if (dist < bestD) { bestD = dist; best = b; }
        }
        return best;
    }

    /** A safe standing spot on or just above a building's core (so a respawn never lands inside blocks). */
    public Location safeSpawn(PlacedBuilding b) {
        World w = Bukkit.getWorld(b.core.world());
        if (w == null) return null;
        for (int r = 0; r <= 2; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    for (int dy = 0; dy <= 4; dy++) {
                        Block feet = w.getBlockAt(b.core.x() + dx, b.core.y() + dy, b.core.z() + dz);
                        Block head = feet.getRelative(0, 1, 0);
                        Block below = feet.getRelative(0, -1, 0);
                        if (feet.isPassable() && !feet.isLiquid() && head.isPassable() && !head.isLiquid() && below.getType().isSolid())
                            return new Location(w, feet.getX() + 0.5, feet.getY(), feet.getZ() + 0.5);
                    }
                }
            }
        }
        return new Location(w, b.core.x() + 0.5, b.core.y() + 1, b.core.z() + 0.5);
    }

    // ------------------------------------------------------------------ founding, membership, disbanding

    public String canFound(BlockPos pos) {
        if (at(pos) != null) return "This land already belongs to a civilization.";
        int min = plugin.reg().settings.minTownDistance;
        for (Town t : towns.values()) {
            if (!t.center.world().equals(pos.world())) continue;
            double d = Math.hypot(t.center.x() - pos.x(), t.center.z() - pos.z());
            if (d < min) return "Too close to " + t.name + " (civilizations need " + min + " blocks between them).";
        }
        return null;
    }

    public boolean nameTaken(String name) { return byName.containsKey(name.toLowerCase()); }

    public Town found(String name, UUID founder, BlockPos pos) {
        Registries reg = plugin.reg();
        Town t = new Town(UUID.randomUUID(), name, reg.firstAge().id, pos, System.currentTimeMillis());
        t.owner = founder;
        t.leader = founder;
        t.econId = reg.settings.defaultEconomy;
        t.members.put(founder, "x");
        GovernmentDef g = reg.government(reg.settings.defaultGovernment);
        plugin.governance().applyGovernment(t, g);   // gives the founder the leader role
        register(t);
        plugin.db().saveTown(t);
        return t;
    }

    public void addMember(Town t, UUID u, String rank) {
        t.members.put(u, rank);
        playerTown.put(u, t.id);
        t.invites.remove(u);
        save(t);
    }

    public void removeMember(Town t, UUID u) {
        t.members.remove(u);
        playerTown.remove(u);
        t.votes.remove(u);
        t.votes.values().removeIf(c -> c.equals(u));
        transferBuildings(t, u);
        if (u.equals(t.leader)) plugin.governance().setLeader(t, t.members.containsKey(t.owner) ? t.owner : t.members.keySet().stream().findFirst().orElse(null));
        save(t);
    }

    /** Buildings of a departing member pass to the highest-ranked remaining member, so cities never fill with dead buildings. */
    private void transferBuildings(Town t, UUID from) {
        UUID heir = null;
        int best = -1;
        for (UUID m : t.members.keySet()) {
            int w = t.weightOf(m);
            if (w > best) { best = w; heir = m; }
        }
        if (heir == null) return;
        for (PlacedBuilding b : t.buildings) {
            if (b.owner.equals(from)) { b.owner = heir; plugin.db().saveBuilding(b); }
        }
    }

    /** Remove the civilization entirely. Blocks stay in the world; records, ledger and spawned villagers are removed. */
    public void disband(Town t) {
        plugin.tracked().removeTown(t.id);
        for (PlacedBuilding b : new ArrayList<>(t.buildings)) { unindex(b); dirtyBuildings.remove(b); plugin.logistics().invalidate(b); }
        Set<ChunkKey> chunks = townChunks.remove(t.id);
        if (chunks != null) for (ChunkKey ck : chunks) claims.remove(ck, t.id);
        for (UUID u : t.members.keySet()) playerTown.remove(u);
        towns.remove(t.id);
        byName.remove(t.name.toLowerCase());
        dirtyTowns.remove(t);
        dirtyTx.values().removeIf(id -> id.equals(t.id));
        plugin.db().deleteTown(t.id);
    }

    /** Permission-checked disband (owner, or a role the government explicitly gave DISBAND). Null on success. */
    public String disbandBy(org.bukkit.entity.Player p, Town t) {
        if (!t.can(p.getUniqueId(), Perm.DISBAND)) return "Only the technical owner can disband the civilization.";
        String name = t.name;
        List<UUID> members = new ArrayList<>(t.members.keySet());
        disband(t);
        for (UUID u : members) {
            org.bukkit.entity.Player m = Bukkit.getPlayer(u);
            if (m != null) dev.ages.util.Text.msg(m, "&6The civilization of " + name + " has been disbanded.");
        }
        plugin.getLogger().info(p.getName() + " disbanded the civilization '" + name + "'.");
        return null;
    }

    public void save(Town t) {
        dirtyTowns.remove(t);
        plugin.db().saveTown(t);
    }

    // ------------------------------------------------------------------ buildings

    public void addBuilding(Town t, PlacedBuilding b) {
        t.buildings.add(b);
        index(b);
        plugin.db().saveBuilding(b);
        recomputeClaims(t);
        plugin.logistics().invalidate(b);
    }

    /** Unregister a building. Its spawned entities stay alive but unassigned (they re-attach if the same building is placed again). */
    public void removeBuilding(Town t, PlacedBuilding b) {
        t.buildings.remove(b);
        unindex(b);
        dirtyBuildings.remove(b);
        plugin.production().unschedule(b);
        plugin.tracked().release(b.id);
        plugin.db().deleteBuilding(b.id);
        recomputeClaims(t);
        plugin.logistics().invalidate(b);
    }

    /**
     * TRANSACTIONAL placement: registers the new building, retires the buildings it replaces and (for an age core) advances the age,
     * all in memory AND in a single database transaction. If anything fails everything is rolled back, so a failed handoff never
     * leaves a civilization without its previous core.
     */
    public boolean commit(Town t, PlacedBuilding nb, List<PlacedBuilding> retire, AgeDef advanceTo) {
        String oldAge = t.ageId;
        BlockPos oldCore = t.core;
        List<PlacedBuilding> removed = new ArrayList<>();
        try {
            t.buildings.add(nb);
            index(nb);
            for (PlacedBuilding r : retire) {
                if (!t.buildings.remove(r)) continue;
                unindex(r);
                removed.add(r);
            }
            if (advanceTo != null) { t.ageId = advanceTo.id; t.core = nb.core; }
            recomputeClaims(t);
            if (!plugin.db().commitHandoff(t, nb, removed)) throw new IllegalStateException("database commit failed");
        } catch (RuntimeException ex) {
            t.buildings.remove(nb);
            unindex(nb);
            for (PlacedBuilding r : removed) { t.buildings.add(r); index(r); }
            t.ageId = oldAge;
            t.core = oldCore;
            recomputeClaims(t);
            plugin.getLogger().severe("Placement of " + nb.defId + " failed and was rolled back: " + ex.getMessage());
            return false;
        }
        // committed: side effects that cannot fail
        for (PlacedBuilding r : removed) {
            dirtyBuildings.remove(r);
            plugin.production().unschedule(r);
            plugin.logistics().invalidate(r);
        }
        BuildingDef nd = plugin.reg().effective(nb);
        int cap = nd != null && nd.function != null && nd.function.type.equals("spawner") ? nd.function.cap : 0;
        plugin.tracked().reassign(removed.stream().map(r -> r.id).toList(), nb.id, cap);
        plugin.production().schedule(nb, 0);
        plugin.logistics().invalidate(nb);
        return true;
    }

    /** Apply an upgrade: new level, new area (re-indexed), fresh input/output, territory recomputed. */
    public void upgrade(Town t, PlacedBuilding b, BuildingDef next, dev.ages.building.Scanner.Result scan) {
        unindex(b);
        b.level = next.level;
        b.setBox(next.rx, next.rz, next.up, next.down);
        if (scan.input() != null) b.input = scan.input();
        if (scan.output() != null) b.output = scan.output();
        b.damaged = false;
        index(b);
        plugin.db().saveBuilding(b);
        recomputeClaims(t);
        plugin.production().schedule(b, 0);
        plugin.logistics().invalidate(b);
    }

    private void index(PlacedBuilding b) {
        byId.put(b.id, b);
        byCore.put(b.core, b);
        forChunks(b, ck -> byChunk.computeIfAbsent(ck, k -> new ArrayList<>()).add(b));
    }

    private void unindex(PlacedBuilding b) {
        byId.remove(b.id);
        byCore.remove(b.core);
        forChunks(b, ck -> {
            List<PlacedBuilding> l = byChunk.get(ck);
            if (l != null) { l.remove(b); if (l.isEmpty()) byChunk.remove(ck); }
        });
    }

    private void forChunks(PlacedBuilding b, Consumer<ChunkKey> c) {
        for (int cx = b.minX >> 4; cx <= b.maxX >> 4; cx++)
            for (int cz = b.minZ >> 4; cz <= b.maxZ >> 4; cz++)
                c.accept(new ChunkKey(b.core.world(), cx, cz));
    }

    // ------------------------------------------------------------------ write-behind persistence

    public void markDirty(PlacedBuilding b) { dirtyBuildings.add(b); }
    public void markTownDirty(Town t) { dirtyTowns.add(t); }
    public void markTxDirty(UUID town, Tx tx) { dirtyTx.put(tx, town); }

    /** Write everything that changed since the last flush. Called periodically, after money moves, and on shutdown. */
    public void flushNow() { flush(); }

    public void flush() {
        if (!dirtyBuildings.isEmpty()) {
            List<PlacedBuilding> live = new ArrayList<>();
            for (PlacedBuilding b : dirtyBuildings) if (byId.containsKey(b.id)) live.add(b);
            dirtyBuildings.clear();
            plugin.db().saveBuildings(live);
        }
        if (!dirtyTowns.isEmpty()) {
            List<Town> live = new ArrayList<>();
            for (Town t : dirtyTowns) if (towns.containsKey(t.id)) live.add(t);
            dirtyTowns.clear();
            plugin.db().saveBalances(live);
        }
        if (!dirtyTx.isEmpty()) {
            for (Map.Entry<Tx, UUID> e : dirtyTx.entrySet()) if (towns.containsKey(e.getValue())) plugin.db().insertTx(e.getValue(), e.getKey());
            dirtyTx.clear();
        }
    }

    // ------------------------------------------------------------------ territory

    /** After a config reload: re-apply building sizes from the (possibly changed) definitions and re-index them. */
    public void reboxAll() {
        Registries reg = plugin.reg();
        for (Town t : towns.values()) {
            for (PlacedBuilding b : t.buildings) {
                BuildingDef d = reg.effective(b);
                if (d == null) continue;
                unindex(b);
                b.setBox(d.rx, d.rz, d.up, d.down);
                index(b);
            }
        }
    }

    public void recomputeAll() { for (Town t : towns.values()) recomputeClaims(t); }

    /**
     * Territory = chunks around the center (radius grows with buildings and bonuses, capped per age) plus chunks around each
     * building's box (+margin, clamped to the age cap). Wilderness buildings (placement: anywhere) never claim land.
     */
    public void recomputeClaims(Town t) {
        Set<ChunkKey> old = townChunks.remove(t.id);
        if (old != null) for (ChunkKey ck : old) claims.remove(ck, t.id);
        Registries reg = plugin.reg();
        AgeDef age = reg.age(t.ageId);
        if (age == null) return;

        int inside = 0;
        double bonus = plugin.governance().effects(t).add("claim_radius_add");
        for (PlacedBuilding b : t.buildings) {
            BuildingDef d = reg.effective(b);
            if (d == null || d.anywhere) continue;
            inside++;
            if (!b.damaged) bonus += d.provide("claim_bonus");
        }
        int r = (int) Math.min(age.claimMax, age.claimBase + age.claimPerBuilding * inside + bonus);
        String w = t.center.world();
        Set<ChunkKey> set = new HashSet<>();
        addSquare(set, w, t.center.x() - r, t.center.z() - r, t.center.x() + r, t.center.z() + r);

        int margin = reg.settings.claimMargin;
        int cap = age.claimMax;
        for (PlacedBuilding b : t.buildings) {
            BuildingDef d = reg.effective(b);
            if (d == null || d.anywhere) continue;
            addSquare(set, w,
                    Math.max(b.minX - margin, t.center.x() - cap), Math.max(b.minZ - margin, t.center.z() - cap),
                    Math.min(b.maxX + margin, t.center.x() + cap), Math.min(b.maxZ + margin, t.center.z() + cap));
        }
        Set<ChunkKey> mine = new HashSet<>();
        for (ChunkKey ck : set) {
            UUID owner = claims.get(ck);
            if (owner == null || owner.equals(t.id)) { claims.put(ck, t.id); mine.add(ck); }
        }
        townChunks.put(t.id, mine);
    }

    public int claimedChunks(Town t) { Set<ChunkKey> s = townChunks.get(t.id); return s == null ? 0 : s.size(); }

    private static void addSquare(Set<ChunkKey> set, String world, int x0, int z0, int x1, int z1) {
        for (int cx = x0 >> 4; cx <= x1 >> 4; cx++)
            for (int cz = z0 >> 4; cz <= z1 >> 4; cz++)
                set.add(new ChunkKey(world, cx, cz));
    }
}
