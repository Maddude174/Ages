package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.config.BuildingDef;
import dev.ages.config.EconomyDef;
import dev.ages.config.Settings;
import dev.ages.hook.Eco;
import dev.ages.model.Perm;
import dev.ages.model.Town;
import dev.ages.model.Tx;
import dev.ages.util.InvUtil;
import dev.ages.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * The three kinds of money, kept apart:
 *  - PERSONAL funds: a player's Vault balance (never touched except by contribute/withdraw)
 *  - TREASURY: shared civilization money, fed by taxes, marketplace income and member contributions
 *  - RESOURCE POINTS: the plugin-specific currency buildings generate and that buildings/ages cost
 * Every movement is recorded in the persistent ledger.
 */
public final class Finance {
    private final AgesPlugin plugin;

    public Finance(AgesPlugin plugin) { this.plugin = plugin; }

    private Settings cfg() { return plugin.reg().settings; }
    private EconomyDef econ(Town t) { return plugin.reg().economy(t.econId); }

    // ------------------------------------------------------------------ pricing & payment

    /** Costs after government/economy/policy modifiers (item costs are never scaled). */
    public BuildingDef.Cost scaled(Town t, BuildingDef.Cost c) {
        double m = plugin.governance().effects(t).mult("building_cost_mult");
        if (m == 1.0) return c;
        return new BuildingDef.Cost(Math.ceil(c.points() * m * 10) / 10, Math.ceil(c.money() * m * 10) / 10, c.items());
    }

    /** Balances only (used for government/economy/policy decisions where the action permission already applies). */
    public String civProblem(Town t, BuildingDef.Cost c) {
        if (c.points() > t.points + 1e-9) return "Needs " + Text.num(c.points()) + " resource points (the civilization has " + Text.num(t.points) + ").";
        if (c.money() > t.money + 1e-9) return "Needs " + Text.num(c.money()) + " treasury money (the civilization has " + Text.num(t.money) + ").";
        return null;
    }

    /** Perms + balances + the buyer's items. Null = the player can pay. */
    public String payProblem(Player p, Town t, BuildingDef.Cost c) {
        UUID u = p.getUniqueId();
        if (c.points() > 0 && !t.can(u, Perm.SPEND_POINTS)) return "Your role cannot spend shared resource points.";
        if (c.money() > 0 && !t.can(u, Perm.SPEND_TREASURY)) return "Your role cannot spend treasury money.";
        String bal = civProblem(t, c);
        if (bal != null) return bal;
        for (var e : c.items().entrySet())
            if (InvUtil.countPlain(p.getInventory(), e.getKey()) < e.getValue())
                return "You need " + e.getValue() + "x " + Text.pretty(e.getKey()) + " in your inventory.";
        return null;
    }

    /** Charge after payProblem returned null. */
    public void pay(Player p, Town t, BuildingDef.Cost c, String type, String note) {
        c.items().forEach((m, n) -> InvUtil.removePlain(p.getInventory(), m, n));
        spend(t, p.getUniqueId(), c, type, note);
    }

    /** Charge shared balances only. */
    public void payCiv(Town t, UUID actor, BuildingDef.Cost c, String type, String note) { spend(t, actor, c, type, note); }

    private void spend(Town t, UUID actor, BuildingDef.Cost c, String type, String note) {
        if (c.points() > 0) { t.points -= c.points(); record(t, actor, type, "POINTS", -c.points(), note); }
        if (c.money() > 0) { t.money -= c.money(); record(t, actor, type, "MONEY", -c.money(), note); }
        plugin.towns().markTownDirty(t);
        plugin.towns().flushNow();
    }

    // ------------------------------------------------------------------ income

    public void earnPoints(Town t, double amount, String source) {
        if (amount <= 0) return;
        t.points += amount;
        record(t, null, "PRODUCTION", "POINTS", amount, source);
        plugin.towns().markTownDirty(t);
    }

    /** Money income goes to the treasury, unless the economy has no money (then it converts to points). */
    public void earnMoney(Town t, double amount, String source) {
        if (amount <= 0) return;
        EconomyDef e = econ(t);
        if (!e.moneyEnabled) { earnPoints(t, amount * e.moneyToPoints, source + " (converted from money)"); return; }
        t.money += amount;
        record(t, null, source.equals("tax") ? "TAX" : "PRODUCTION", "MONEY", amount, source);
        plugin.towns().markTownDirty(t);
    }

    // ------------------------------------------------------------------ contributions & treasury actions

    /** Contribute one stack (hand) or every accepted item (all) as resource points. Returns a message. */
    public String contributeItems(Player p, Town t, boolean all) {
        UUID u = p.getUniqueId();
        if (!t.can(u, Perm.CONTRIBUTE)) return "&cYour role cannot contribute.";
        double rate = plugin.governance().effects(t).mult("contribution_rate_mult");
        double points = 0;
        int count = 0;
        var inv = p.getInventory();
        List<Integer> slots = new ArrayList<>();
        if (all) { for (int i = 0; i < inv.getStorageContents().length; i++) slots.add(i); }
        else slots.add(inv.getHeldItemSlot());
        for (int slot : slots) {
            ItemStack s = inv.getItem(slot);
            if (s == null || s.getType() == Material.AIR) continue;
            Double v = cfg().contributionValues.get(s.getType());
            if (v == null || v <= 0 || s.hasItemMeta()) continue;   // custom items (cores, named tools...) are never taken
            points += s.getAmount() * v * rate;
            count += s.getAmount();
            inv.setItem(slot, null);
        }
        if (count == 0) return "&cNothing accepted. The civilization takes materials listed in settings.yml (economy.contributions.items).";
        t.points += points;
        double[] c = t.contributions.computeIfAbsent(u, k -> new double[2]);
        c[0] += points;
        plugin.db().saveContribution(t.id, u, c[0], c[1]);
        record(t, u, "CONTRIBUTE_ITEMS", "POINTS", points, p.getName() + " gave " + count + " items");
        plugin.towns().markTownDirty(t);
        plugin.towns().flushNow();
        return "&aContributed " + count + " items for " + Text.num(points) + " resource points.";
    }

    public String contributeMoney(Player p, Town t, double amount) {
        UUID u = p.getUniqueId();
        EconomyDef e = econ(t);
        if (!t.can(u, Perm.CONTRIBUTE)) return "&cYour role cannot contribute.";
        if (!e.moneyEnabled || !e.contributionMoney) return "&cYour economic system (" + Text.plain(e.name) + ") does not accept money contributions.";
        Eco eco = plugin.eco();
        if (eco == null) return "&cNo economy plugin (Vault) is available.";
        if (amount <= 0) return "&cAmount must be positive.";
        if (!eco.has(p, amount)) return "&cYou do not have " + eco.fmt(amount) + ".";
        if (!eco.take(p, amount)) return "&cPayment failed.";
        t.money += amount;
        double[] c = t.contributions.computeIfAbsent(u, k -> new double[2]);
        c[1] += amount;
        plugin.db().saveContribution(t.id, u, c[0], c[1]);
        record(t, u, "CONTRIBUTE_MONEY", "MONEY", amount, p.getName() + " paid in from personal funds");
        plugin.towns().markTownDirty(t);
        plugin.towns().flushNow();
        return "&aContributed " + eco.fmt(amount) + " to the treasury.";
    }

    public double withdrawLimit(Town t) {
        double extra = 0;
        for (var b : t.buildings) {
            BuildingDef d = plugin.reg().effective(b);
            if (d != null && !b.damaged) extra += d.provide("withdraw_limit");
        }
        EconomyDef e = econ(t);
        return e.withdrawLimit <= 0 ? 0 : e.withdrawLimit + extra + plugin.governance().effects(t).add("withdraw_limit_add");
    }

    public double withdrawnLast24h(Town t, UUID player) {
        long since = System.currentTimeMillis() - 86_400_000L;
        double sum = 0;
        for (Tx x : t.ledger) if (x.type.equals("WITHDRAW") && player.equals(x.actor) && x.ts >= since) sum += -x.amount;
        return sum;
    }

    public String withdraw(Player p, Town t, double amount) {
        UUID u = p.getUniqueId();
        if (!t.can(u, Perm.WITHDRAW_TREASURY)) return "&cYour role cannot withdraw from the treasury.";
        Eco eco = plugin.eco();
        if (eco == null) return "&cNo economy plugin (Vault) is available.";
        double limit = withdrawLimit(t);
        if (limit <= 0) return "&cYour economic system does not allow treasury withdrawals.";
        if (amount <= 0) return "&cAmount must be positive.";
        if (amount > t.money + 1e-9) return "&cThe treasury only holds " + Text.num(t.money) + ".";
        double used = withdrawnLast24h(t, u);
        if (used + amount > limit + 1e-9) return "&cDaily withdrawal limit: " + Text.num(limit) + " (you have taken " + Text.num(used) + " in the last 24h).";
        t.money -= amount;
        eco.give(p, amount);
        record(t, u, "WITHDRAW", "MONEY", -amount, p.getName() + " withdrew to personal funds");
        plugin.towns().markTownDirty(t);
        plugin.towns().flushNow();
        return "&aWithdrew " + eco.fmt(amount) + " from the treasury.";
    }

    public String convert(Player p, Town t, double money) {
        UUID u = p.getUniqueId();
        EconomyDef e = econ(t);
        if (!t.can(u, Perm.SPEND_TREASURY)) return "&cYour role cannot spend treasury money.";
        if (e.exchangeRate <= 0) return "&cYour economic system does not allow converting money to points.";
        if (money <= 0) return "&cAmount must be positive.";
        if (money > t.money + 1e-9) return "&cThe treasury only holds " + Text.num(t.money) + ".";
        double pts = money * e.exchangeRate;
        t.money -= money;
        t.points += pts;
        record(t, u, "CONVERT", "MONEY", -money, "Converted to points at " + e.exchangeRate);
        record(t, u, "CONVERT", "POINTS", pts, "Converted from treasury money");
        plugin.towns().markTownDirty(t);
        plugin.towns().flushNow();
        return "&aConverted " + Text.num(money) + " money into " + Text.num(pts) + " resource points.";
    }

    // ------------------------------------------------------------------ ledger

    /** Append to the ledger. Civilization-originated production/tax lines within the coalesce window are merged into one. */
    public void record(Town t, UUID actor, String type, String currency, double amount, String note) {
        long now = System.currentTimeMillis();
        double bal = currency.equals("POINTS") ? t.points : t.money;
        Tx head = t.ledger.peekFirst();
        long window = cfg().coalesceMinutes * 60_000L;
        if (actor == null && head != null && head.actor == null && head.type.equals(type) && head.currency.equals(currency)
                && head.note.equals(note) && now - head.ts <= window) {
            head.amount += amount;
            head.balance = bal;
            plugin.towns().markTxDirty(t.id, head);
            return;
        }
        Tx tx = new Tx(plugin.db().nextTxId(), now, actor, type, currency, amount, bal, note);
        t.ledger.addFirst(tx);
        while (t.ledger.size() > cfg().ledgerLoad) t.ledger.removeLast();
        plugin.towns().markTxDirty(t.id, tx);
    }
}
