package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.item.Items;
import dev.ages.model.Town;
import dev.ages.model.Tracked;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

/**
 * Persistent registry of plugin-spawned entities. Slots are counted from THIS registry, never from "what is
 * currently loaded", which is what prevents duplicates when chunks are unloaded or the server restarts.
 * A slot is freed only when the entity is confirmed dead/gone; the building's production timer then spawns exactly one replacement.
 */
public final class TrackedEntities {
    private final AgesPlugin plugin;
    private final Map<UUID, Tracked> byEntity = new HashMap<>();
    private final Map<UUID, Set<UUID>> byBuilding = new HashMap<>();
    private final Map<UUID, Integer> townVillagers = new HashMap<>();
    private final Map<UUID, Integer> misses = new HashMap<>();

    public TrackedEntities(AgesPlugin plugin) { this.plugin = plugin; }

    public void load(List<Tracked> list) {
        for (Tracked t : list) index(t);
    }

    private void index(Tracked t) {
        byEntity.put(t.entity, t);
        if (t.building != null) byBuilding.computeIfAbsent(t.building, k -> new HashSet<>()).add(t.entity);
        if (t.type.equals("VILLAGER")) townVillagers.merge(t.town, 1, Integer::sum);
    }

    private void unindex(Tracked t) {
        byEntity.remove(t.entity);
        misses.remove(t.entity);
        if (t.building != null) {
            Set<UUID> s = byBuilding.get(t.building);
            if (s != null) { s.remove(t.entity); if (s.isEmpty()) byBuilding.remove(t.building); }
        }
        if (t.type.equals("VILLAGER")) townVillagers.merge(t.town, -1, Integer::sum);
    }

    public Tracked get(UUID entity) { return byEntity.get(entity); }
    public int countBuilding(UUID building) { Set<UUID> s = byBuilding.get(building); return s == null ? 0 : s.size(); }
    public int villagers(UUID town) { return Math.max(0, townVillagers.getOrDefault(town, 0)); }

    /** Keep Town#villagers (used for population) in step with the registry. */
    public void refreshTown(Town t) { t.villagers = villagers(t.id); }

    public void add(Entity e, UUID town, UUID building, String type) {
        var pdc = e.getPersistentDataContainer();
        pdc.set(Items.TOWN, PersistentDataType.STRING, town.toString());
        if (building != null) pdc.set(Items.BUILDING, PersistentDataType.STRING, building.toString());
        e.setPersistent(true);
        var c = e.getLocation().getChunk();
        Tracked t = new Tracked(e.getUniqueId(), building, town, type, e.getWorld().getName(), c.getX(), c.getZ());
        index(t);
        plugin.db().saveTracked(t);
        Town tw = plugin.towns().byId(town);
        if (tw != null) refreshTown(tw);
    }

    public void remove(UUID entity) {
        Tracked t = byEntity.get(entity);
        if (t == null) return;
        unindex(t);
        plugin.db().deleteTracked(entity);
        Town tw = plugin.towns().byId(t.town);
        if (tw != null) refreshTown(tw);
    }

    /** Remember where an entity was when its chunk unloaded, so "unloaded" is never mistaken for "gone". */
    public void updateChunk(Entity e) {
        Tracked t = byEntity.get(e.getUniqueId());
        if (t == null) return;
        var c = e.getLocation().getChunk();
        t.world = e.getWorld().getName();
        t.cx = c.getX();
        t.cz = c.getZ();
        misses.remove(t.entity);
        plugin.db().saveTracked(t);
    }

    /**
     * A building was removed. Its entities deliberately KEEP their building id: if the same building is placed again
     * (relocation keeps its uuid) they re-attach automatically, and meanwhile they still count as residents.
     */
    public void release(UUID building) { /* intentionally nothing */ }

    /** Conversions: villagers of buildings that were merged into a new one move over to it. */
    public void reassign(Collection<UUID> from, UUID to, int capacity) {
        int free = capacity - countBuilding(to);
        for (UUID b : from) {
            Set<UUID> s = byBuilding.get(b);
            if (s == null) continue;
            for (UUID id : new ArrayList<>(s)) {
                Tracked t = byEntity.get(id);
                if (t == null) continue;
                s.remove(id);
                if (free > 0) {
                    t.building = to;
                    byBuilding.computeIfAbsent(to, k -> new HashSet<>()).add(id);
                    free--;
                } else {
                    t.building = null;
                }
                plugin.db().saveTracked(t);
            }
            if (s.isEmpty()) byBuilding.remove(b);
        }
    }

    /** Disbanding: remove the entities (loaded ones immediately, unloaded ones when they next load, as unknown orphans). */
    public void removeTown(UUID town) {
        for (Tracked t : new ArrayList<>(byEntity.values())) {
            if (!t.town.equals(town)) continue;
            Entity e = Bukkit.getEntity(t.entity);
            if (e != null) e.remove();
            unindex(t);
        }
        townVillagers.remove(town);
    }

    /**
     * Periodic check: an entity whose last known chunk is loaded, with its entities loaded, but which cannot be found
     * for two passes in a row is gone (killed by another plugin, despawned, ...): free its slot.
     */
    public void reconcile() {
        for (Tracked t : new ArrayList<>(byEntity.values())) {
            World w = Bukkit.getWorld(t.world);
            if (w == null || !w.isChunkLoaded(t.cx, t.cz) || !w.getChunkAt(t.cx, t.cz).isEntitiesLoaded()) continue;
            if (Bukkit.getEntity(t.entity) != null) { misses.remove(t.entity); continue; }
            int m = misses.merge(t.entity, 1, Integer::sum);
            if (m >= 2) {
                plugin.getLogger().info("Freed the slot of a missing " + t.type + " (" + t.entity + ").");
                remove(t.entity);
            }
        }
    }
}
