#!/usr/bin/env python3
"""
Authoring script for the shipped YAML (ages, buildings, governments, economies, policies, settings, shop).
The YAML is the source of truth and safe to edit by hand: this script just writes the defaults.
Run: python3 tools/generate_content.py && python3 tools/check_config.py && python3 tools/balance.py
"""
import os, sys, yaml
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
ROOT = os.path.join(HERE, "..", "src", "main", "resources")

class D(yaml.SafeDumper):
    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)

def dump(d):
    return yaml.dump(d, Dumper=D, sort_keys=False, default_flow_style=None, width=130, allow_unicode=True)

def write(folder, name, header, data):
    path = os.path.join(ROOT, folder, name + ".yml")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as fh:
        fh.write(header + "\n" + dump(data))

def clean(folder):
    d = os.path.join(ROOT, folder)
    os.makedirs(d, exist_ok=True)
    for f in os.listdir(d):
        if not f.startswith("_"): os.remove(os.path.join(d, f))

# ------------------------------------------------------------------ recipe helpers
def C(item, n=1):  # consumed item(s); list = any_of
    return {"any_of": item, "amount": n} if isinstance(item, list) else {"item": item, "amount": n}
def T(item, dur):  # tool worn down
    return {"any_of": item, "durability": dur} if isinstance(item, list) else {"item": item, "durability": dur}
def E(item, lo=1, hi=None, **kw):
    d = {"item": item, "min": lo, "max": hi if hi else lo}; d.update(kw); return d
def PCT(item, pct, lo=1, hi=None):      # percent entry (pick: one); AIR makes up the remainder
    return E(item, lo, hi, percent=pct)
def ALL(*e): return {"pick": "all", "entries": list(e)}
def ONE(*e): return {"pick": "one", "entries": list(e)}
def R(id, consume, produce, name=None, interval=None, optional=False):
    d = {"id": id}
    if name: d["name"] = name
    if interval: d["interval"] = interval
    if optional: d["optional"] = True
    d["consume"] = consume; d["produce"] = produce
    return d
def FN(interval=600, recipes=None, mode=None, type="processor", **kw):
    d = {"type": type, "interval": interval}
    if mode: d["mode"] = mode
    d.update(kw)
    if recipes: d["recipes"] = recipes
    return d

FUEL = C(["COAL", "CHARCOAL"], 1)
LOGS = [f"{w}_LOG" for w in ["OAK", "BIRCH", "SPRUCE", "JUNGLE", "ACACIA", "DARK_OAK", "CHERRY", "MANGROVE"]]
AXES = ["WOODEN_AXE", "STONE_AXE", "IRON_AXE"]
PICKS = ["WOODEN_PICKAXE", "STONE_PICKAXE", "IRON_PICKAXE"]
SHOVELS = ["WOODEN_SHOVEL", "STONE_SHOVEL", "IRON_SHOVEL"]
HOES = ["WOODEN_HOE", "STONE_HOE", "IRON_HOE"]
SEEDS = ["WHEAT_SEEDS", "BEETROOT_SEEDS", "MELON_SEEDS", "PUMPKIN_SEEDS"]
COOKED = ["COOKED_BEEF", "COOKED_PORKCHOP", "COOKED_MUTTON", "COOKED_CHICKEN", "COOKED_COD", "COOKED_SALMON"]

# ------------------------------------------------------------------ building registry
AGE_IDS = ["tribal", "village", "medieval", "industrial"]
buildings = {}     # id -> dict
age_of = {}

def pts(ph, interval):
    """resource points per CYCLE for a target of `ph` points per hour"""
    return round(ph * interval / 3600, 2)

def B(id, name, cat, age, core, scan, reqs, cost, desc, ph=0, interval=600, fn=None, always=None, tags=None, io=None,
      provides=None, limits=None, replaces=None, aliases=None, anywhere=False, shop=True, icon=None, upgrades=None, obsolete_in=None):
    d = {"id": id, "name": name, "description": desc, "category": cat, "age": age, "core_block": core}
    if icon: d["icon"] = icon
    if aliases: d["aliases"] = aliases
    d["scan"] = {"x": scan[0], "z": scan[1], "up": scan[2], "down": scan[3]}
    d["requirements"] = [{"material": g[2:], "min": n} if g.startswith("M:") else {"group": g, "min": n} for g, n in reqs]
    if cost:
        c = {}
        if cost.get("points"): c["points"] = cost["points"]
        if cost.get("treasury"): c["treasury"] = cost["treasury"]
        if cost.get("items"): c["items"] = cost["items"]
        if c: d["cost"] = c
    if tags: d["tags"] = tags
    if limits: d["limits"] = limits
    if replaces: d["replaces"] = replaces
    if obsolete_in: d["obsolete_in"] = obsolete_in
    if anywhere: d["placement"] = "anywhere"
    if io: d["logistics"] = {k: v for k, v in zip(("input", "output"), io) if v}
    f = dict(fn) if fn else None
    entries = list(always or [])
    if ph > 0: entries.insert(0, {"points": pts(ph, (f or {}).get("interval", interval))})
    if entries:
        if f is None: f = {"type": "none", "interval": interval}
        f["always"] = entries
    if f: d["function"] = f
    if provides: d["provides"] = provides
    if upgrades: d["upgrades"] = upgrades
    if not shop: d["shop"] = False
    buildings[id] = d
    age_of[id] = age

def U(age, cost, desc, scan=None, reqs=None, fn=None, provides=None, label=None):
    u = {}
    if label: u["label"] = label
    u["age"] = age
    u["cost"] = {k: v for k, v in cost.items() if v}
    u["description"] = desc
    if scan: u["scan"] = {"x": scan[0], "z": scan[1], "up": scan[2], "down": scan[3]}
    if reqs: u["requirements"] = [{"material": g[2:], "min": n} if g.startswith("M:") else {"group": g, "min": n} for g, n in reqs]
    if fn: u["function"] = fn
    if provides: u["provides"] = provides
    return u

CORE = ("CORE", "CORE")   # production buildings: the barrel core is both input and output

PLANKS_ANY = [f"{w}_PLANKS" for w in ["OAK", "BIRCH", "SPRUCE", "JUNGLE", "ACACIA", "DARK_OAK", "CHERRY", "MANGROVE"]]

# =====================================================================  TRIBAL
B("chiefs_hut", "&6Chief's Hut", "government", "tribal", "LODESTONE", (5, 5, 5, 1),
  [("wall_material", 30), ("door", 2), ("light_source", 2), ("bed", 2), ("banner", 1), ("carpet", 4)], None,
  ["The tribe's seat of leadership and its first core.", "Placing it founds your civilization.", "Needed to grow into the Village Age."],
  ph=18, provides={"claim_bonus": 4, "housing": 2}, limits={"max_per_town": 1, "max_per_player": 1}, aliases=["fireplace"])

B("tribal_hut", "&eTribal Hut", "community", "tribal", "HAY_BLOCK", (3, 3, 4, 1),
  [("wall_material", 16), ("bed", 2), ("light_source", 1)], {"points": 6},
  ["A simple shelter. Villagers move in as housing allows."],
  ph=6, fn=FN(900, type="spawner", entity="VILLAGER", cap=1, housing_limited=True), tags={"housing": 1},
  provides={"housing": 2}, limits={"max_per_town": 6, "max_per_player": 3}, aliases=["hut"], icon="OAK_DOOR")

B("storage_hut", "&6Storage Hut", "trade", "tribal", "PACKED_MUD", (4, 4, 3, 1),
  [("wall_material", 20), ("chest_any", 4), ("light_source", 1)], {"points": 8},
  ["Shared tribal storage and a logistics hub.", "Goods delivered here can be pulled back out."],
  ph=6, io=("BARREL", "CHEST"), provides={"storage": 1}, limits={"max_per_town": 2, "max_per_player": 1}, icon="BARREL")

B("forager", "&aForager", "food", "tribal", "BARREL", (5, 5, 3, 1),
  [("wall_material", 16), ("foliage", 20), ("light_source", 1)], {"points": 6},
  ["Forages berries, mushrooms and flowers.", "Often comes back empty-handed."],
  ph=6, io=CORE, aliases=["gatherers_hut"], icon="SWEET_BERRIES", limits={"max_per_town": 2, "max_per_player": 1},
  fn=FN(300, [R("forage", [], ONE(PCT("SWEET_BERRIES", 25, 1, 3), PCT("BROWN_MUSHROOM", 10, 1, 2), PCT("DANDELION", 10, 1, 2)), name="Forage")]))

B("hunters_hut", "&cHunter's Hut", "food", "tribal", "BARREL", (5, 5, 4, 1),
  [("wall_material", 24), ("door", 2), ("light_source", 1)], {"points": 8},
  ["Hunters bring back meat and small game.", "Put a bow and arrows (or a sword) in the barrel core:", "tools wear down, arrows are used up, hunts can fail."],
  ph=6, io=CORE, icon="BOW", limits={"max_per_town": 2, "max_per_player": 1},
  fn=FN(240, [
      R("bow_hunt", [T("BOW", 2), C("ARROW", 1)], ONE(PCT("BEEF", 15, 1, 2), PCT("PORKCHOP", 15, 1, 2), PCT("MUTTON", 10, 1, 2),
                                                     PCT("RABBIT", 15), PCT("CHICKEN", 10, 1, 2), PCT("LEATHER", 5)), name="Hunt with a bow"),
      R("sword_hunt", [T("STONE_SWORD", 3)], ONE(PCT("PORKCHOP", 20, 1, 2), PCT("MUTTON", 15, 1, 2), PCT("RABBIT", 10)), name="Hunt with a sword"),
      R("snare", [C("STICK", 2), C("STRING", 1)], ONE(PCT("RABBIT", 25), PCT("CHICKEN", 20)), name="Set snares")], mode="random"))

B("fishers_hut", "&bFisher's Hut", "food", "tribal", "BARREL", (6, 6, 3, 2),
  [("wall_material", 20), ("water", 12), ("fence", 4), ("light_source", 1)], {"points": 8},
  ["Fishes the nearby water. Fishing rods wear down."],
  ph=6, io=CORE, icon="FISHING_ROD", limits={"max_per_town": 2, "max_per_player": 1},
  fn=FN(270, [R("fish", [T("FISHING_ROD", 3)], ONE(PCT("COD", 35, 1, 3), PCT("SALMON", 20, 1, 2), PCT("PUFFERFISH", 3), PCT("TROPICAL_FISH", 2)), name="Fish")]))

TREES = [("oak", "OAK_LOG", "OAK_SAPLING"), ("birch", "BIRCH_LOG", "BIRCH_SAPLING"), ("spruce", "SPRUCE_LOG", "SPRUCE_SAPLING"),
         ("jungle", "JUNGLE_LOG", "JUNGLE_SAPLING"), ("acacia", "ACACIA_LOG", "ACACIA_SAPLING"), ("dark_oak", "DARK_OAK_LOG", "DARK_OAK_SAPLING"),
         ("cherry", "CHERRY_LOG", "CHERRY_SAPLING"), ("mangrove", "MANGROVE_LOG", "MANGROVE_PROPAGULE")]
B("woodcutter", "&2Woodcutter", "resources", "tribal", "BARREL", (7, 7, 6, 1),
  [("wall_material", 12), ("leaves", 20), ("light_source", 1)], {"points": 8},
  ["Fells trees in the grove around it.", "Choose the wood type in the building menu.", "Axes in the barrel wear down."],
  ph=6, io=CORE, icon="IRON_AXE", limits={"max_per_town": 2, "max_per_player": 1}, aliases=[f"logger_{t[0]}" for t in TREES],
  fn=FN(300, [R(t[0], [T(AXES, 3)], ALL(E(t[1], 3, 5), E(t[2], 1, 2, chance=0.35), E("STICK", 2, 4, chance=0.5)), name=t[0].replace("_", " ").title() + " logs") for t in TREES], mode="selected"))

B("workshop", "&6Workshop", "industry", "tribal", "BARREL", (5, 5, 4, 1),
  [("wall_material", 20), ("fletching_table", 1), ("light_source", 2)], {"points": 10},
  ["Crafts arrows and other basic supplies.", "Choose what to make in the building menu."],
  ph=6, io=CORE, icon="ARROW", limits={"max_per_town": 1, "max_per_player": 1},
  fn=FN(180, [
      R("arrows", [C("FLINT", 3), C("STICK", 3), C("FEATHER", 3)], ALL(E("ARROW", 12)), name="Arrows"),
      R("bow", [C("STRING", 3), C("STICK", 3)], ALL(E("BOW", 1)), name="Bow"),
      R("stone_sword", [C("COBBLESTONE", 2), C("STICK", 1)], ALL(E("STONE_SWORD", 1)), name="Stone sword"),
      R("stone_axe", [C("COBBLESTONE", 3), C("STICK", 2)], ALL(E("STONE_AXE", 1)), name="Stone axe"),
      R("stone_pickaxe", [C("COBBLESTONE", 3), C("STICK", 2)], ALL(E("STONE_PICKAXE", 1)), name="Stone pickaxe"),
      R("fishing_rod", [C("STICK", 3), C("STRING", 2)], ALL(E("FISHING_ROD", 1)), name="Fishing rod"),
      R("wooden_hoe", [C(PLANKS_ANY, 2), C("STICK", 2)], ALL(E("WOODEN_HOE", 1)), name="Wooden hoe")], mode="selected"))

B("burial_mound", "&8Burial Mound", "community", "tribal", "COAL_BLOCK", (4, 4, 3, 1),
  [("earth_mound", 30), ("memorial", 3)], {"points": 6},
  ["Where the tribe lays its dead.", "Members who die respawn here."],
  ph=6, provides={"respawn_point": 1}, limits={"max_per_town": 1, "max_per_player": 1}, icon="BONE")

# =====================================================================  VILLAGE
B("village_hall", "&6Village Hall", "government", "village", "BELL", (7, 7, 6, 1),
  [("wall_material", 60), ("door", 2), ("light_source", 4), ("lectern", 1), ("carpet", 8), ("banner", 2)], None,
  ["The village's seat of government.", "Replaces the Chief's Hut as your core.", "Collects taxes from residents."],
  ph=30, fn=FN(600, type="tax", per_resident=0.4), provides={"claim_bonus": 12, "housing": 4},
  limits={"max_per_town": 1}, replaces=["chiefs_hut"])

B("cottage", "&eCottage", "community", "village", "OAK_PLANKS", (4, 4, 5, 1),
  [("wall_material", 30), ("door", 2), ("bed", 4), ("light_source", 2), ("roof", 8), ("glass", 2)], {"points": 25},
  ["Proper housing for four.", "Replaces a Tribal Hut built in the same spot."],
  ph=8, fn=FN(900, type="spawner", entity="VILLAGER", cap=2, housing_limited=True), tags={"housing": 1}, provides={"housing": 4},
  limits={"max_per_town": 8, "max_per_player": 3}, replaces=["tribal_hut"], aliases=["house"], icon="OAK_DOOR",
  upgrades=[U("medieval", {"points": 60}, ["A stone cottage: room for six and a third villager."], scan=(5, 5, 6, 1),
              reqs=[("masonry", 20), ("roof", 12), ("glass", 4), ("bed", 6)], fn={"cap": 3}, provides={"housing": 2})])

B("storehouse", "&6Storehouse", "trade", "village", "SMOOTH_STONE", (6, 6, 5, 1),
  [("wall_material", 40), ("door", 2), ("chest_any", 8), ("light_source", 3)], {"points": 40},
  ["Stores general goods in chests.", "A logistics hub for rail networks."],
  ph=10, io=("CHEST", "CHEST"), provides={"storage": 3}, limits={"max_per_town": 2, "max_per_player": 1},
  replaces=["storage_hut"], aliases=["warehouse"], icon="CHEST")

B("granary", "&6Granary", "trade", "village", "BROWN_TERRACOTTA", (5, 5, 5, 1),
  [("wall_material", 36), ("door", 2), ("hay", 6), ("chest_any", 6), ("light_source", 2)], {"points": 35},
  ["Stores food in barrels. A smaller logistics hub."],
  ph=8, io=("BARREL", "BARREL"), provides={"storage": 2}, limits={"max_per_town": 2, "max_per_player": 1}, icon="BARREL")

B("marketplace", "&bMarketplace", "trade", "village", "BARREL", (6, 6, 5, 1),
  [("wall_material", 36), ("door", 2), ("light_source", 3), ("banner", 2)], {"points": 70},
  ["Traders buy food and goods from the barrel core", "and pay into the civilization's treasury."],
  ph=16, io=CORE, limits={"max_per_town": 2, "max_per_player": 1}, aliases=["trading_post"], icon="EMERALD",
  fn=FN(300, [
      R("bread", [C("BREAD", 4)], ALL({"money": 6}), name="Sell bread"),
      R("meat", [C(COOKED, 3)], ALL({"money": 3.4}), name="Sell cooked meat"),
      R("produce", [C(["CARROT", "POTATO", "BEETROOT", "APPLE"], 6)], ALL({"money": 4}), name="Sell produce"),
      R("fish", [C(["COD", "SALMON"], 4)], ALL({"money": 3}), name="Sell fish")], mode="random"),
  upgrades=[U("medieval", {"points": 150}, ["Faster trading and a wider market."], scan=(8, 8, 6, 1),
              reqs=[("wall_material", 60), ("light_source", 5), ("banner", 4)],
              fn={"interval": 240, "recipes": [R("goods", [C(["IRON_INGOT", "COPPER_INGOT", "GLASS", "BRICK"], 6)], ALL({"money": 8}), name="Sell crafted goods")]})])

FARM_RECIPES = [
    R("wheat", [T(HOES, 2)], ALL(E("WHEAT", 4, 8), E("WHEAT_SEEDS", 1, 3, chance=0.8)), name="Wheat"),
    R("carrot", [T(HOES, 2)], ALL(E("CARROT", 4, 8)), name="Carrots"),
    R("potato", [T(HOES, 2)], ALL(E("POTATO", 4, 8), E("POISONOUS_POTATO", 1, 1, chance=0.1)), name="Potatoes"),
    R("beetroot", [T(HOES, 2)], ALL(E("BEETROOT", 3, 6), E("BEETROOT_SEEDS", 1, 3, chance=0.7)), name="Beetroot"),
    R("melon", [T(HOES, 2)], ALL(E("MELON_SLICE", 6, 12)), name="Melons"),
    R("pumpkin", [T(HOES, 2)], ALL(E("PUMPKIN", 2, 4)), name="Pumpkins")]
B("farm", "&aFarm", "food", "village", "BARREL", (8, 8, 3, 2),
  [("farmland", 24), ("water", 2), ("fence", 8)], {"points": 35},
  ["Fenced fields. Choose the crop in the building menu.", "Hoes in the barrel wear down. Harvest is virtual."],
  ph=10, io=CORE, tags={"farming": 1}, limits={"max_per_town": 3, "max_per_player": 1}, icon="WHEAT",
  aliases=["wheat_farm", "carrot_farm", "potato_farm", "beetroot_farm", "melon_farm", "pumpkin_farm", "sugar_cane_farm"],
  fn=FN(600, FARM_RECIPES, mode="selected"),
  upgrades=[U("medieval", {"points": 80}, ["Irrigation channels: 33% faster harvests."], scan=(10, 10, 3, 2),
              reqs=[("farmland", 36), ("water", 4), ("fence", 12)], fn={"interval": 450})])

B("animal_farm", "&6Animal Farm", "food", "village", "BARREL", (7, 7, 3, 1),
  [("fence", 16), ("hay", 4), ("water", 1), ("light_source", 1)], {"points": 45},
  ["Pens for chickens, sheep, cattle and pigs.", "Choose the animal in the building menu; feed goes in the barrel."],
  ph=10, io=CORE, tags={"farming": 1}, limits={"max_per_town": 3, "max_per_player": 1}, icon="EGG",
  aliases=["chicken_coop", "sheep_pen", "cattle_ranch"],
  fn=FN(480, [
      R("chickens", [C(SEEDS, 4)], ALL(E("EGG", 4, 8), E("FEATHER", 1, 3, chance=0.7), E("CHICKEN", 1, 1, chance=0.25)), name="Chickens"),
      R("sheep", [T("SHEARS", 2), C("WHEAT", 3)], ONE(PCT("WHITE_WOOL", 60, 2, 4), PCT("BROWN_WOOL", 10, 2, 3), PCT("BLACK_WOOL", 10, 2, 3),
                                                     PCT("GRAY_WOOL", 5, 2, 3), PCT("LIGHT_GRAY_WOOL", 5, 2, 3)), name="Sheep (wool)"),
      R("cattle", [C("WHEAT", 4)], ALL(E("BEEF", 2, 4), E("LEATHER", 1, 2, chance=0.6)), name="Cattle"),
      R("pigs", [C("CARROT", 4)], ALL(E("PORKCHOP", 2, 4)), name="Pigs")], mode="selected"))

B("stone_quarry", "&7Stone Quarry", "resources", "village", "BARREL", (8, 8, 5, 5),
  [("natural_stone", 60), ("support_beam", 4), ("light_source", 2)], {"points": 40},
  ["Cuts stone, cobblestone and related materials.", "Pickaxes in the barrel wear down."],
  ph=8, io=CORE, anywhere=True, icon="STONE_PICKAXE", limits={"max_per_town": 2, "max_per_player": 1},
  fn=FN(300, [R("quarry", [T(PICKS, 3)], ALL(E("COBBLESTONE", 4, 8), E("STONE", 1, 3, chance=0.4), E("ANDESITE", 1, 3, chance=0.2),
                                              E("DIORITE", 1, 2, chance=0.15), E("GRANITE", 1, 2, chance=0.15), E("FLINT", 1, 2, chance=0.3), E("GRAVEL", 1, 3, chance=0.3)), name="Quarry stone")]))

B("charcoal_kiln", "&8Charcoal Kiln", "industry", "village", "BARREL", (4, 4, 4, 1),
  [("wall_material", 20), ("furnace_any", 2), ("light_source", 2)], {"points": 35},
  ["Burns logs into charcoal."],
  ph=8, io=CORE, icon="CHARCOAL", limits={"max_per_town": 2, "max_per_player": 1},
  fn=FN(300, [R("charcoal", [C(LOGS, 4)], ALL(E("CHARCOAL", 4)), name="Make charcoal")]))

B("clay_pit", "&6Clay Pit", "resources", "village", "BARREL", (7, 7, 3, 3),
  [("clay_block", 20), ("water", 6), ("support_beam", 4), ("light_source", 1)], {"points": 30},
  ["Digs clay from the riverbank. Shovels wear down."],
  ph=6, io=CORE, anywhere=True, icon="CLAY_BALL", limits={"max_per_town": 1, "max_per_player": 1},
  fn=FN(300, [R("clay", [T(SHOVELS, 3)], ALL(E("CLAY_BALL", 4, 8)), name="Dig clay")]))

B("sand_pit", "&eSand Pit", "resources", "village", "BARREL", (7, 7, 3, 3),
  [("sand_block", 40), ("support_beam", 4), ("light_source", 1)], {"points": 25},
  ["Shovels sand and gravel. Shovels wear down."],
  ph=6, io=CORE, anywhere=True, icon="SAND", limits={"max_per_town": 1, "max_per_player": 1},
  fn=FN(240, [R("sand", [T(SHOVELS, 3)], ALL(E("SAND", 6, 12), E("GRAVEL", 2, 5, chance=0.4)), name="Dig sand")]))

B("bakery", "&6Bakery", "food", "village", "BARREL", (4, 4, 5, 1),
  [("wall_material", 36), ("door", 2), ("furnace_any", 2), ("light_source", 3)], {"points": 50},
  ["Bakes wheat into bread and sweets."],
  ph=10, io=CORE, icon="BREAD", limits={"max_per_town": 1, "max_per_player": 1},
  fn=FN(240, [
      R("bread", [C("WHEAT", 9)], ALL(E("BREAD", 4)), name="Bread"),
      R("cookies", [C("WHEAT", 2), C("COCOA_BEANS", 1)], ALL(E("COOKIE", 10)), name="Cookies"),
      R("pie", [C("PUMPKIN", 1), C("SUGAR", 1), C("EGG", 1)], ALL(E("PUMPKIN_PIE", 1)), name="Pumpkin pie")], mode="selected"),
  upgrades=[U("medieval", {"points": 90}, ["A master baker: faster, and bakes cakes."], scan=(5, 5, 5, 1), reqs=[("furnace_any", 3)],
              fn={"interval": 200, "recipes": [R("cake", [C("MILK_BUCKET", 3), C("SUGAR", 2), C("EGG", 1), C("WHEAT", 3)], ALL(E("CAKE", 1), E("BUCKET", 3)), name="Cake (returns the buckets)")]})])

B("smokehouse", "&cSmokehouse", "food", "village", "BARREL", (4, 4, 5, 1),
  [("wall_material", 30), ("door", 2), ("furnace_any", 2), ("light_source", 2)], {"points": 45},
  ["Smokes and cooks meat and fish. Needs fuel."],
  ph=10, io=CORE, icon="COOKED_BEEF", limits={"max_per_town": 1, "max_per_player": 1},
  fn=FN(180, [R(f"smoke_{raw.lower()}", [C(raw, 8), FUEL], ALL(E(cooked, 9)), name="Smoke " + raw.replace("_", " ").title())
              for raw, cooked in [("BEEF", "COOKED_BEEF"), ("PORKCHOP", "COOKED_PORKCHOP"), ("MUTTON", "COOKED_MUTTON"),
                                  ("CHICKEN", "COOKED_CHICKEN"), ("COD", "COOKED_COD"), ("SALMON", "COOKED_SALMON")]], mode="random"))

B("tavern", "&6Tavern", "community", "village", "BARREL", (6, 6, 6, 1),
  [("wall_material", 50), ("door", 2), ("light_source", 6), ("chest_any", 3), ("stairs", 8)], {"points": 80},
  ["Travellers buy meals from the barrel core.", "Income goes to the treasury. Offers lodging."],
  ph=12, io=CORE, tags={"housing": 1}, provides={"housing": 2}, limits={"max_per_town": 1, "max_per_player": 1}, icon="BEEF",
  fn=FN(300, [
      R("meal", [C(COOKED, 2)], ALL({"money": 2.4}), name="Serve a meal"),
      R("bread", [C("BREAD", 3)], ALL({"money": 4}), name="Serve bread"),
      R("pie", [C("PUMPKIN_PIE", 1)], ALL({"money": 3.2}), name="Serve pie")], mode="random"),
  upgrades=[U("medieval", {"points": 140}, ["An inn: more rooms and honey mead."], scan=(7, 7, 7, 1),
              reqs=[("bed", 4), ("light_source", 8)], provides={"housing": 2},
              fn={"interval": 240, "recipes": [R("honey", [C("HONEY_BOTTLE", 2)], ALL({"money": 5}), name="Serve honey mead")]})])

B("pottery", "&6Pottery", "industry", "village", "BARREL", (5, 5, 4, 1),
  [("wall_material", 36), ("furnace_any", 2), ("light_source", 3), ("cauldron", 1)], {"points": 60},
  ["Fires clay into bricks, pots and terracotta.", "Choose the product in the building menu."],
  ph=10, io=CORE, icon="FLOWER_POT", limits={"max_per_town": 1, "max_per_player": 1}, aliases=["brick_kiln"],
  fn=FN(240, [
      R("bricks", [C("CLAY_BALL", 8), FUEL], ALL(E("BRICK", 8, 9)), name="Bricks"),
      R("flower_pot", [C("BRICK", 3)], ALL(E("FLOWER_POT", 1)), name="Flower pot"),
      R("decorated_pot", [C("BRICK", 4)], ALL(E("DECORATED_POT", 1)), name="Decorated pot"),
      R("terracotta", [C("CLAY_BALL", 4), FUEL], ALL(E("TERRACOTTA", 4)), name="Terracotta")], mode="selected"))

B("shrine", "&fShrine", "community", "village", "CHISELED_STONE_BRICKS", (3, 3, 4, 1),
  [("masonry", 16), ("candle", 2), ("flowers", 2), ("light_source", 2)], {"points": 35},
  ["A small place of devotion.", "Members who die may respawn here."],
  ph=20, provides={"respawn_point": 1}, tags={"faith": 1}, limits={"max_per_town": 2, "max_per_player": 1}, icon="CANDLE")

B("chapel", "&fChapel", "community", "village", "QUARTZ_BLOCK", (5, 5, 8, 1),
  [("wall_material", 40), ("door", 2), ("light_source", 4), ("bell", 1), ("lectern", 1), ("banner", 2), ("glass", 4), ("stairs", 6)], {"points": 100},
  ["A developed place of worship and rest.", "Members who die may respawn here."],
  ph=24, provides={"respawn_point": 1, "claim_bonus": 4, "housing": 1}, tags={"faith": 1}, limits={"max_per_town": 1, "max_per_player": 1},
  aliases=["church", "cathedral"], icon="BELL")

B("graveyard", "&8Graveyard", "community", "village", "POLISHED_DEEPSLATE", (7, 7, 3, 1),
  [("gravestone", 8), ("memorial", 4), ("fence", 12), ("light_source", 2)], {"points": 50},
  ["Fenced gravestones and candles.", "Members who die respawn here."],
  ph=10, provides={"respawn_point": 1}, limits={"max_per_town": 1, "max_per_player": 1}, icon="COBBLESTONE_WALL")

B("watchtower", "&7Watchtower", "military", "village", "LODESTONE", (4, 4, 14, 1),
  [("masonry", 40), ("ladder", 8), ("light_source", 3), ("fence", 4)], {"points": 60},
  ["Extends your borders and watches the land."],
  ph=12, provides={"claim_bonus": 8}, limits={"max_per_town": 3, "max_per_player": 1}, icon="LADDER")

# =====================================================================  MEDIEVAL
def mine(id, name, ore, tools, dur, out, cost, ph, desc, icon, upgrade_cost, age="medieval", up_age="industrial"):
    B(id, name, "resources", age, "BARREL", (8, 8, 5, 6),
      [("natural_stone", 100), (ore, 2), ("support_beam", 8), ("light_source", 6), ("rail", 4)], {"points": cost}, desc,
      ph=ph, io=CORE, tags={"mining": 1}, anywhere=True, limits={"max_per_town": 2, "max_per_player": 1}, icon=icon,
      fn=FN(360, [R(id.replace("_mine", ""), [T(tools, dur)], out, name="Mine")]),
      upgrades=[U(up_age, {"points": upgrade_cost}, ["Deeper shafts: 33% faster output."], scan=(10, 10, 6, 8),
                  reqs=[("support_beam", 14), ("light_source", 10), ("rail", 8)], fn={"interval": 270})])

B("keep", "&4Keep", "military", "medieval", "STONE_BRICKS", (11, 11, 10, 2),
  [("masonry", 160), ("door", 4), ("light_source", 8), ("bed", 4), ("ladder", 6), ("iron_bars", 4)], {"points": 500},
  ["A fortified stronghold that pushes your borders out.", "Members who die respawn here."],
  ph=36, provides={"respawn_point": 1, "claim_bonus": 16}, limits={"max_per_town": 1, "max_per_player": 1}, icon="STONE_BRICKS")

B("town_hall", "&6Town Hall", "government", "medieval", "GOLD_BLOCK", (9, 9, 8, 1),
  [("wall_material", 100), ("roof", 40), ("door", 6), ("light_source", 8), ("glass", 12), ("carpet", 20), ("banner", 4), ("bookshelf", 4)], None,
  ["The seat of the town's government.", "Replaces the Village Hall as your core.", "Collects larger taxes."],
  ph=48, fn=FN(600, type="tax", per_resident=0.8), provides={"claim_bonus": 20, "housing": 6}, limits={"max_per_town": 1}, replaces=["village_hall"])

B("manor_house", "&eManor House", "community", "medieval", "SPRUCE_PLANKS", (7, 7, 8, 1),
  [("wall_material", 90), ("door", 4), ("bed", 6), ("light_source", 6), ("roof", 20), ("glass", 8), ("carpet", 12)], {"points": 400},
  ["A lordly home for eight. Merges the cottages it stands over."],
  ph=24, fn=FN(900, type="spawner", entity="VILLAGER", cap=4, housing_limited=True), tags={"housing": 4}, provides={"housing": 8},
  limits={"max_per_town": 3, "max_per_player": 1}, replaces=["cottage", "townhouse"], icon="SPRUCE_DOOR",
  upgrades=[U("industrial", {"points": 500}, ["A grander manor: two more residents."], scan=(8, 8, 9, 1),
              reqs=[("wall_material", 120), ("glass", 12), ("carpet", 20)], fn={"cap": 6}, provides={"housing": 4})])

B("treasury", "&6Treasury", "trade", "medieval", "EMERALD_BLOCK", (5, 5, 5, 1),
  [("masonry", 60), ("door", 2), ("iron_bars", 6), ("light_source", 4), ("chest_any", 4), ("gilded", 2)], {"points": 300},
  ["Secures the civilization's wealth.", "Earns steady interest and raises the daily withdrawal limit."],
  ph=16, always=[{"money": 6}], interval=900, provides={"withdraw_limit": 400}, limits={"max_per_town": 1, "max_per_player": 1}, icon="GOLD_BLOCK")

B("bank", "&6Bank", "trade", "medieval", "BARREL", (6, 6, 5, 1),
  [("masonry", 80), ("door", 2), ("iron_bars", 8), ("chest_any", 4), ("light_source", 4), ("gilded", 4)], {"points": 450},
  ["Exchanges precious metals and gems for treasury money.", "Raises the daily withdrawal limit."],
  ph=16, io=CORE, always=[{"money": 4}], provides={"withdraw_limit": 600}, limits={"max_per_town": 1, "max_per_player": 1}, icon="GOLD_INGOT",
  fn=FN(600, [
      R("gold", [C("GOLD_INGOT", 2)], ALL({"money": 10}), name="Buy gold"),
      R("emerald", [C("EMERALD", 1)], ALL({"money": 34}), name="Buy emeralds"),
      R("diamond", [C("DIAMOND", 1)], ALL({"money": 45}), name="Buy diamonds")], mode="all"))

B("townhouse", "&eTownhouse", "community", "medieval", "STRIPPED_SPRUCE_WOOD", (5, 5, 8, 1),
  [("wall_material", 50), ("door", 4), ("bed", 8), ("light_source", 4), ("roof", 12), ("glass", 4)], {"points": 170},
  ["A multi-storey home for six. Merges cottages it stands over."],
  ph=12, fn=FN(900, type="spawner", entity="VILLAGER", cap=3, housing_limited=True), tags={"housing": 2}, provides={"housing": 6},
  limits={"max_per_town": 8, "max_per_player": 3}, replaces=["cottage"], icon="SPRUCE_DOOR")

B("villa", "&eVilla", "community", "medieval", "SMOOTH_SANDSTONE", (7, 7, 6, 1),
  [("wall_material", 80), ("door", 4), ("bed", 6), ("light_source", 6), ("roof", 16), ("glass", 10), ("flowers", 6), ("carpet", 10)], {"points": 280},
  ["A comfortable country villa with gardens."],
  ph=20, fn=FN(900, type="spawner", entity="VILLAGER", cap=3, housing_limited=True), tags={"housing": 3}, provides={"housing": 7},
  limits={"max_per_town": 4, "max_per_player": 2}, icon="SANDSTONE")

B("guardhouse", "&4Guardhouse", "military", "medieval", "RED_NETHER_BRICKS", (5, 5, 5, 1),
  [("wall_material", 40), ("door", 2), ("bed", 4), ("light_source", 4), ("iron_bars", 2)], {"points": 200},
  ["Trains an iron golem as a town guard.", "Feed iron blocks into the barrel at the building."],
  ph=12, io=("BARREL", None), limits={"max_per_town": 2, "max_per_player": 1}, icon="IRON_BLOCK",
  fn=FN(1800, type="spawner", entity="IRON_GOLEM", cap=2, consume=[C("IRON_BLOCK", 1)]))

B("stables", "&6Stables", "food", "medieval", "BARREL", (7, 7, 4, 1),
  [("fence", 20), ("hay", 8), ("water", 1), ("wall_material", 30), ("light_source", 2)], {"points": 220},
  ["Cares for horses. Produces leather, leads and the odd saddle."],
  ph=16, io=CORE, tags={"farming": 1}, limits={"max_per_town": 1, "max_per_player": 1}, icon="SADDLE",
  fn=FN(420, [R("horses", [C("WHEAT", 3), C("CARROT", 2)], ALL(E("LEATHER", 1, 3), E("LEAD", 1, 1, chance=0.15), E("SADDLE", 1, 1, chance=0.03)), name="Care for horses")]))

def armor(tier, mat, optional=False):
    return [R(f"{tier.lower()}_{k.lower()}", [C(mat, n)], ALL(E(f"{tier}_{k}", 1)), name=f"{tier.title()} {k.title()}", optional=optional)
            for k, n in [("HELMET", 5), ("CHESTPLATE", 8), ("LEGGINGS", 7), ("BOOTS", 4)]]
B("armory", "&7Armory", "industry", "medieval", "BARREL", (5, 5, 5, 1),
  [("wall_material", 40), ("anvil", 1), ("furnace_any", 1), ("light_source", 3), ("iron_bars", 2)], {"points": 320},
  ["Armour, shields and bows. Choose the item in the building menu."],
  ph=16, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="IRON_CHESTPLATE",
  fn=FN(360, armor("IRON", "IRON_INGOT") + armor("COPPER", "COPPER_INGOT", True) + [
      R("shield", [C("IRON_INGOT", 1), C(PLANKS_ANY, 6)], ALL(E("SHIELD", 1)), name="Shield"),
      R("bow", [C("STRING", 3), C("STICK", 3)], ALL(E("BOW", 1)), name="Bow")], mode="selected"),
  upgrades=[U("industrial", {"points": 700}, ["Diamond armour."], scan=(6, 6, 6, 1),
              reqs=[("anvil", 2), ("M:SMITHING_TABLE", 2), ("furnace_any", 2), ("light_source", 5)],
              fn={"interval": 330, "recipes": armor("DIAMOND", "DIAMOND")})])

mine("coal_mine", "&8Coal Mine", "ore_coal", PICKS, 4, ALL(E("COAL", 3, 6)), 240, 14, ["A timbered mine on a coal vein.", "Needs rails, props and light."], "COAL", 300)
mine("iron_mine", "&fIron Mine", "ore_iron", ["STONE_PICKAXE", "IRON_PICKAXE"], 5, ALL(E("RAW_IRON", 2, 4)), 280, 14, ["A mine on an iron vein."], "RAW_IRON", 340)
mine("copper_mine", "&6Copper Mine", "ore_copper", ["STONE_PICKAXE", "IRON_PICKAXE"], 5, ALL(E("RAW_COPPER", 3, 6)), 250, 14, ["A mine on a copper vein."], "RAW_COPPER", 300)
mine("gold_mine", "&eGold Mine", "ore_gold", ["IRON_PICKAXE", "DIAMOND_PICKAXE"], 5, ALL(E("RAW_GOLD", 1, 3)), 420, 14, ["Gold needs an iron pick.", "Slow, valuable output."], "RAW_GOLD", 450)

B("orchard", "&aOrchard", "food", "medieval", "BARREL", (8, 8, 6, 1),
  [("leaves", 30), ("composter", 1), ("fence", 8), ("light_source", 1)], {"points": 130},
  ["Tended fruit trees: apples, berries and saplings."],
  ph=12, io=CORE, tags={"farming": 1}, limits={"max_per_town": 2, "max_per_player": 1}, icon="APPLE",
  fn=FN(420, [R("fruit", [], ALL(E("APPLE", 2, 5), E("OAK_SAPLING", 1, 1, chance=0.3), E("SWEET_BERRIES", 1, 3, chance=0.3)), name="Harvest fruit")]))

B("plantation", "&aPlantation", "food", "medieval", "BARREL", (8, 8, 4, 2),
  [("sugar_cane_crop", 10), ("water", 4), ("sand_block", 8), ("fence", 8)], {"points": 150},
  ["Sugar cane, bamboo and cocoa. Choose in the building menu.", "Axes in the barrel wear down."],
  ph=12, io=CORE, tags={"farming": 1}, limits={"max_per_town": 2, "max_per_player": 1}, icon="SUGAR_CANE",
  fn=FN(480, [
      R("sugar_cane", [T(AXES, 2)], ALL(E("SUGAR_CANE", 6, 12)), name="Sugar cane"),
      R("bamboo", [T(AXES, 2)], ALL(E("BAMBOO", 6, 12)), name="Bamboo"),
      R("cocoa", [T(AXES, 2)], ALL(E("COCOA_BEANS", 3, 6)), name="Cocoa")], mode="selected"))

B("apiary", "&eApiary", "food", "medieval", "BARREL", (5, 5, 4, 1),
  [("beehive", 3), ("flowers", 12), ("fence", 6), ("light_source", 1)], {"points": 160},
  ["Bottles honey and shears honeycomb."],
  ph=14, io=CORE, tags={"farming": 1}, limits={"max_per_town": 1, "max_per_player": 1}, icon="HONEYCOMB",
  fn=FN(420, [R("honey", [C("GLASS_BOTTLE", 2)], ALL(E("HONEY_BOTTLE", 2)), name="Honey"),
              R("comb", [T("SHEARS", 1)], ALL(E("HONEYCOMB", 2, 4)), name="Honeycomb")], mode="all"))

B("smithy", "&8Smithy", "industry", "medieval", "BARREL", (5, 5, 5, 1),
  [("wall_material", 36), ("furnace_any", 3), ("light_source", 3), ("cauldron", 1)], {"points": 260},
  ["Smelts raw ore into ingots. Needs fuel."],
  ph=16, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="FURNACE",
  fn=FN(240, [R(f"smelt_{n}", [C(raw, 8), FUEL], ALL(E(ing, 9)), name="Smelt " + n)
              for n, raw, ing in [("iron", "RAW_IRON", "IRON_INGOT"), ("copper", "RAW_COPPER", "COPPER_INGOT"), ("gold", "RAW_GOLD", "GOLD_INGOT")]], mode="selected"))

def tools(tier, mat, optional=False):
    return [R(f"{tier.lower()}_{k.lower()}", [C(mat, n), C("STICK", 1 if k == "SWORD" else 2)], ALL(E(f"{tier}_{k}", 1)), name=f"{tier.title()} {k.title()}", optional=optional)
            for k, n in [("SWORD", 2), ("PICKAXE", 3), ("AXE", 3), ("SHOVEL", 1), ("HOE", 2)]]
B("blacksmith", "&8Blacksmith", "industry", "medieval", "BARREL", (5, 5, 5, 1),
  [("wall_material", 36), ("anvil", 1), ("furnace_any", 1), ("cauldron", 1), ("light_source", 3)], {"points": 300},
  ["Forges tools for hunters, loggers, miners and farmers.", "Level 1: stone, iron and copper tools.", "Upgrade for gold, diamond and netherite."],
  ph=16, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="ANVIL",
  fn=FN(300, [R(f"stone_{k.lower()}", [C("COBBLESTONE", n), C("STICK", 1 if k == "SWORD" else 2)], ALL(E(f"STONE_{k}", 1)), name=f"Stone {k.title()}")
              for k, n in [("SWORD", 2), ("PICKAXE", 3), ("AXE", 3), ("SHOVEL", 1), ("HOE", 2)]]
      + tools("IRON", "IRON_INGOT") + tools("COPPER", "COPPER_INGOT", True), mode="selected"),
  upgrades=[
      U("industrial", {"points": 600}, ["Gold and diamond tools."], scan=(6, 6, 6, 1), reqs=[("anvil", 2), ("furnace_any", 3), ("light_source", 5)],
        fn={"interval": 270, "recipes": tools("GOLDEN", "GOLD_INGOT") + tools("DIAMOND", "DIAMOND")}),
      U("industrial", {"points": 1500, "items": {"DIAMOND": 8}}, ["Netherite tools (no smithing template needed).", "Feed it a diamond tool and a netherite ingot."],
        scan=(7, 7, 7, 1), reqs=[("anvil", 3), ("furnace_any", 5), ("M:SMITHING_TABLE", 3), ("light_source", 8)],
        fn={"interval": 240, "recipes": [R(f"netherite_{k.lower()}", [C(f"DIAMOND_{k}", 1), C("NETHERITE_INGOT", 1)], ALL(E(f"NETHERITE_{k}", 1)), name=f"Netherite {k.title()}")
                                         for k in ["SWORD", "PICKAXE", "AXE", "SHOVEL", "HOE"]]})])

B("glassworks", "&bGlassworks", "industry", "medieval", "BARREL", (5, 5, 5, 1),
  [("wall_material", 40), ("furnace_any", 3), ("light_source", 4), ("chest_any", 2)], {"points": 240},
  ["Melts sand into glass and panes. Needs fuel."],
  ph=14, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="GLASS",
  fn=FN(240, [R("glass", [C(["SAND", "RED_SAND"], 8), FUEL], ALL(E("GLASS", 9)), name="Glass"),
              R("panes", [C("GLASS", 6)], ALL(E("GLASS_PANE", 16)), name="Glass panes")], mode="selected"))

B("weaver", "&dWeaver", "industry", "medieval", "BARREL", (4, 4, 4, 1),
  [("wall_material", 30), ("loom", 1), ("light_source", 3), ("door", 2)], {"points": 170},
  ["Spins string into wool and weaves carpets."],
  ph=12, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="WHITE_WOOL",
  fn=FN(240, [R("wool", [C("STRING", 4)], ALL(E("WHITE_WOOL", 1)), name="Wool"),
              R("carpet", [C("WHITE_WOOL", 2)], ALL(E("WHITE_CARPET", 3)), name="Carpet")], mode="selected"))

B("monastery", "&fMonastery", "community", "medieval", "BARREL", (7, 7, 7, 1),
  [("masonry", 80), ("bookshelf", 8), ("lectern", 2), ("light_source", 8), ("candle", 4), ("door", 4)], {"points": 450},
  ["Monks copy books and draw blank maps, slowly.", "A place of faith: members may respawn here."],
  ph=30, io=CORE, provides={"respawn_point": 1}, tags={"faith": 1}, limits={"max_per_town": 1, "max_per_player": 1}, icon="BOOK",
  fn=FN(1800, [R("book", [C("PAPER", 3), C("LEATHER", 1)], ALL(E("BOOK", 1)), name="Copy a book"),
               R("map", [C("PAPER", 8), C("COMPASS", 1)], ALL(E("MAP", 1)), name="Draw a blank map")], mode="selected"))

B("library", "&fLibrary", "community", "medieval", "BARREL", (6, 6, 6, 1),
  [("wall_material", 50), ("bookshelf", 12), ("lectern", 2), ("light_source", 6), ("carpet", 12)], {"points": 380},
  ["Scholars study the books you deliver and", "turn knowledge into resource points."],
  ph=30, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="BOOKSHELF",
  fn=FN(900, [R("study", [C("BOOK", 2)], ALL({"points": 3}), name="Study")]))

B("apothecary", "&5Apothecary", "industry", "medieval", "BARREL", (4, 4, 4, 1),
  [("wall_material", 30), ("brewing", 1), ("light_source", 3), ("door", 2)], {"points": 210},
  ["Prepares golden carrots and hearty stews."],
  ph=14, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="BREWING_STAND",
  fn=FN(300, [R("golden_carrot", [C("GOLD_NUGGET", 8), C("CARROT", 1)], ALL(E("GOLDEN_CARROT", 1)), name="Golden carrot"),
              R("stew", [C("BOWL", 1), C("RED_MUSHROOM", 1), C("BROWN_MUSHROOM", 1), C("DANDELION", 1)], ALL(E("SUSPICIOUS_STEW", 1)), name="Suspicious stew")], mode="selected"))

B("herbalist", "&aHerbalist", "food", "medieval", "BARREL", (5, 5, 3, 1),
  [("foliage", 25), ("fence", 6), ("light_source", 2), ("composter", 1)], {"points": 140},
  ["Gathers herbs, flowers and bone meal."],
  ph=12, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="FERN",
  fn=FN(300, [R("herbs", [], ONE(PCT("DANDELION", 20, 1, 2), PCT("POPPY", 15, 1, 2), PCT("FERN", 10, 1, 3), PCT("BONE_MEAL", 25, 1, 3), PCT("BROWN_MUSHROOM", 10)), name="Gather herbs")]))

B("bathhouse", "&bBathhouse", "community", "medieval", "BARREL", (5, 5, 4, 1),
  [("masonry", 40), ("water", 12), ("furnace_any", 2), ("light_source", 4)], {"points": 190},
  ["Heated baths: spare charcoal becomes civic pride", "(a few resource points)."],
  ph=12, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="WATER_BUCKET",
  fn=FN(600, [R("heat", [C("CHARCOAL", 8)], ALL({"points": 3}), name="Heat the baths")]))

# =====================================================================  INDUSTRIAL
B("city_hall", "&6City Hall", "government", "industrial", "DIAMOND_BLOCK", (12, 12, 10, 1),
  [("wall_material", 200), ("carpet", 40), ("banner", 8), ("light_source", 16), ("door", 8), ("glass", 20), ("gilded", 4)], None,
  ["The seat of a modern city.", "Replaces the Town Hall as your core."],
  ph=120, fn=FN(600, type="tax", per_resident=1.2), provides={"claim_bonus": 32, "housing": 10}, limits={"max_per_town": 1}, replaces=["town_hall"])

B("railway_station", "&6Railway Station", "infrastructure", "industrial", "POLISHED_ANDESITE", (8, 8, 6, 1),
  [("wall_material", 80), ("rail", 20), ("light_source", 8), ("chest_any", 8), ("door", 4), ("glass", 8)], {"points": 700},
  ["Joins your buildings by rail.", "Rails touching a building's area link it to the network.", "A logistics hub with extra throughput."],
  ph=40, io=("CHEST", "CHEST"), provides={"storage": 4, "logistics_capacity": 256}, limits={"max_per_town": 3, "max_per_player": 1}, icon="RAIL")

B("freight_depot", "&6Freight Depot", "infrastructure", "industrial", "SMOOTH_BASALT", (9, 9, 6, 1),
  [("wall_material", 100), ("rail", 30), ("chest_any", 16), ("light_source", 8), ("door", 4)], {"points": 800},
  ["A huge warehouse on the rails: the main storage hub."],
  ph=40, io=("BARREL", "BARREL"), provides={"storage": 8, "logistics_capacity": 512}, limits={"max_per_town": 1, "max_per_player": 1}, icon="CHEST_MINECART")

B("automation_works", "&6Automation Works", "infrastructure", "industrial", "REDSTONE_BLOCK", (8, 8, 6, 1),
  [("wall_material", 100), ("redstone_comp", 12), ("furnace_any", 4), ("iron_block", 4), ("rail", 10), ("light_source", 8)], {"points": 1200},
  ["Automated machinery that speeds up every", "production building in the civilization by 15%."],
  ph=60, provides={"production_speed": 0.15}, limits={"max_per_town": 1, "max_per_player": 1}, icon="PISTON")

B("telegraph_office", "&6Telegraph Office", "infrastructure", "industrial", "NOTE_BLOCK", (5, 5, 5, 1),
  [("wall_material", 60), ("redstone_comp", 6), ("iron_bars", 4), ("light_source", 4), ("door", 2)], {"points": 600},
  ["Fast communication: wider borders and a small", "production speed bonus."],
  ph=36, provides={"claim_bonus": 16, "production_speed": 0.05}, limits={"max_per_town": 1, "max_per_player": 1}, icon="NOTE_BLOCK")

B("factory", "&8Factory", "industry", "industrial", "BARREL", (8, 8, 7, 1),
  [("wall_material", 100), ("furnace_any", 4), ("iron_block", 2), ("light_source", 8), ("rail", 6)], {"points": 650},
  ["Bulk manufacturing. Choose the product in the building menu."],
  ph=40, io=CORE, limits={"max_per_town": 2, "max_per_player": 1}, icon="BLAST_FURNACE",
  fn=FN(120, [
      R("planks", [C("OAK_LOG", 8)], ALL(E("OAK_PLANKS", 36)), name="Planks (bulk)"),
      R("bricks", [C("CLAY_BALL", 16), FUEL], ALL(E("BRICK", 16)), name="Bricks (bulk)"),
      R("paper", [C("SUGAR_CANE", 12)], ALL(E("PAPER", 14)), name="Paper (bulk)"),
      R("iron", [C("RAW_IRON", 16), FUEL], ALL(E("IRON_INGOT", 18)), name="Iron (bulk)")], mode="selected"))

B("foundry", "&cFoundry", "industry", "industrial", "BARREL", (8, 8, 7, 1),
  [("masonry", 60), ("furnace_any", 4), ("cauldron", 1), ("light_source", 4)], {"points": 700},
  ["Smelts raw ore into ingots in bulk. Needs fuel.", "Upgrade to refine netherite."],
  ph=40, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="IRON_INGOT",
  fn=FN(200, [R(f"smelt_{n}", [C(raw, 16), FUEL], ALL(E(ing, 18)), name="Smelt " + n)
              for n, raw, ing in [("iron", "RAW_IRON", "IRON_INGOT"), ("copper", "RAW_COPPER", "COPPER_INGOT"), ("gold", "RAW_GOLD", "GOLD_INGOT")]], mode="selected"),
  upgrades=[U("industrial", {"points": 1500, "items": {"DIAMOND": 4}}, ["Refines ancient debris into netherite.", "You still bring the debris from the Nether."],
              scan=(9, 9, 8, 1), reqs=[("furnace_any", 6), ("cauldron", 3), ("iron_bars", 6), ("M:LAVA", 4)],
              fn={"recipes": [R("netherite_scrap", [C("ANCIENT_DEBRIS", 4), FUEL], ALL(E("NETHERITE_SCRAP", 4)), name="Refine debris"),
                              R("netherite_ingot", [C("NETHERITE_SCRAP", 4), C("GOLD_INGOT", 4)], ALL(E("NETHERITE_INGOT", 1)), name="Cast a netherite ingot")]})])

B("emerald_mine", "&aEmerald Mine", "resources", "industrial", "BARREL", (9, 9, 6, 7),
  [("natural_stone", 120), ("ore_emerald", 1), ("support_beam", 12), ("light_source", 8), ("rail", 8)], {"points": 900},
  ["Deep shafts into emerald country.", "Mostly rock; occasionally a gem."],
  ph=40, io=CORE, tags={"mining": 1}, anywhere=True, limits={"max_per_town": 1, "max_per_player": 1}, icon="EMERALD",
  fn=FN(360, [R("emerald", [T(["IRON_PICKAXE", "DIAMOND_PICKAXE"], 6)], ONE(PCT("EMERALD", 35, 1, 2), PCT("DIAMOND", 3)), name="Mine emeralds")]))

B("apartments", "&eApartments", "community", "industrial", "BRICKS", (6, 6, 12, 1),
  [("wall_material", 140), ("door", 8), ("bed", 16), ("light_source", 12), ("glass", 20), ("roof", 20), ("ladder", 8)], {"points": 700},
  ["A block of flats for sixteen. Merges townhouses it stands over."],
  ph=30, fn=FN(900, type="spawner", entity="VILLAGER", cap=8, housing_limited=True), tags={"housing": 4}, provides={"housing": 16},
  limits={"max_per_town": 4, "max_per_player": 2}, replaces=["townhouse"], icon="BRICKS")

B("grand_manor", "&eGrand Manor", "community", "industrial", "GILDED_BLACKSTONE", (9, 9, 10, 1),
  [("wall_material", 160), ("door", 6), ("bed", 10), ("light_source", 10), ("roof", 30), ("glass", 16), ("carpet", 24), ("gilded", 2)], {"points": 900},
  ["A sprawling estate. Merges the manor houses it stands over."],
  ph=50, fn=FN(900, type="spawner", entity="VILLAGER", cap=6, housing_limited=True), tags={"housing": 5}, provides={"housing": 12},
  limits={"max_per_town": 2, "max_per_player": 1}, replaces=["manor_house"], icon="GILDED_BLACKSTONE")

B("stock_exchange", "&6Stock Exchange", "trade", "industrial", "BARREL", (7, 7, 6, 1),
  [("masonry", 120), ("door", 4), ("iron_bars", 6), ("light_source", 8), ("gilded", 4), ("chest_any", 4)], {"points": 1300},
  ["Trades precious goods for treasury money,", "and raises the daily withdrawal limit."],
  io=CORE, always=[{"money": 12}], interval=600, provides={"withdraw_limit": 1500}, limits={"max_per_town": 1, "max_per_player": 1}, icon="GOLD_BLOCK",
  fn=FN(600, [R("gold", [C("GOLD_INGOT", 4)], ALL({"money": 22}), name="Trade gold"),
              R("emerald", [C("EMERALD", 2)], ALL({"money": 72}), name="Trade emeralds")], mode="all"))

B("university", "&fUniversity", "community", "industrial", "BARREL", (8, 8, 8, 1),
  [("masonry", 140), ("bookshelf", 16), ("lectern", 4), ("light_source", 10), ("glass", 16), ("carpet", 20)], {"points": 1200},
  ["Researchers turn books into resource points."],
  ph=80, io=CORE, limits={"max_per_town": 1, "max_per_player": 1}, icon="ENCHANTING_TABLE",
  fn=FN(900, [R("research", [C("BOOK", 4)], ALL({"points": 6}), name="Research")]))

# =====================================================================  AGES
def leaf(b, n=1, **kw):
    d = {"building": b, "count": n}; d.update(kw); return d

AGES = {
 "tribal": dict(name="&6Tribal Age", order=1, core="chiefs_hut", claim=(24, 3, 56), aliases=[],
                tags={"housing": (3, 10), "faith": (1, 2)}, req=None, cost=None, retire=[]),
 "village": dict(name="&aVillage Age", order=2, core="village_hall", claim=(40, 3, 80), aliases=[],
                 tags={"housing": (6, 24), "farming": (2, 5), "faith": (2, 5)},
                 req={"all_of": [leaf("chiefs_hut"), leaf("tribal_hut", 2), leaf("storage_hut"),
                                 {"any_of": [leaf("hunters_hut"), leaf("forager"), leaf("fishers_hut")]}, leaf("woodcutter")]},
                 cost={"points": 100, "items": {"COBBLESTONE": 32, "LEATHER": 4}}, retire=["chiefs_hut"]),
 "medieval": dict(name="&bMedieval Age", order=3, core="town_hall", claim=(64, 3, 128), aliases=[],
                  tags={"housing": (8, 48), "farming": (3, 10), "mining": (2, 4), "faith": (2, 6)},
                  req={"all_of": [leaf("village_hall"), leaf("marketplace"), leaf("storehouse"),
                                  {"any_of": [leaf("shrine"), leaf("chapel")]}, leaf("watchtower")]},
                  cost={"points": 600, "items": {"IRON_INGOT": 16, "GLASS": 16}}, retire=["village_hall"]),
 "industrial": dict(name="&cIndustrial Age", order=4, core="city_hall", claim=(96, 3, 192), aliases=["late_medieval"],
                    tags={"housing": (12, 96), "farming": (4, 14), "mining": (3, 8), "faith": (2, 8)},
                    req={"all_of": [leaf("town_hall"), leaf("bank"), leaf("treasury"), leaf("smithy"), leaf("glassworks"), leaf("library"),
                                    leaf("townhouse", 2), {"any_of": [leaf("coal_mine"), leaf("iron_mine")]}]},
                    cost={"points": 2000, "items": {"IRON_INGOT": 64, "GLASS": 32, "GOLD_INGOT": 8}}, retire=["town_hall"]),
}

# =====================================================================  GOVERNMENTS
P = lambda *a: list(a)
CITIZEN_BASE = ["BUILD", "CONTAINERS", "INTERACT", "USE_SHOP", "CONTRIBUTE", "VIEW_FINANCES", "VOTE"]
BUILDER = ["PURCHASE_BUILDINGS", "PLACE_BUILDINGS", "UPGRADE_BUILDINGS", "REMOVE_BUILDINGS"]
GOVERNMENTS = {
 "chiefdom": dict(name="&6Chiefdom", icon="LODESTONE", min_age=None, title="Chief", leader="chief", default="citizen", selection="appointed",
   desc=["Rule by a tribal chief.", "Every citizen may help buy and build:", "the tribe pools its effort."],
   roles={"chief": (100, "Chief", ["ALL"]),
          "elder": (70, "Elder", CITIZEN_BASE + BUILDER + ["SPEND_POINTS", "MANAGE_BUILDINGS", "ADVANCE_AGE", "INVITE", "KICK", "APPOINT_OFFICIALS", "MANAGE_POLICIES"]),
          "citizen": (40, "Citizen", CITIZEN_BASE + BUILDER + ["SPEND_POINTS"]),
          "recruit": (10, "Recruit", ["BUILD", "INTERACT", "CONTRIBUTE"])},
   mods={}, policies=["communal_labor", "tribute", "frugal_rule"], slots=2, cost={}, cooldown=24),
 "elder_council": dict(name="&eElder Council", icon="CAMPFIRE", min_age=None, title="Speaker", leader="speaker", default="citizen", selection="elected",
   desc=["The elders decide; the speaker is elected.", "Only elders spend shared resources.", "Contributions are valued more highly."],
   roles={"speaker": (100, "Speaker", ["ALL"]),
          "elder": (70, "Elder", CITIZEN_BASE + BUILDER + ["SPEND_POINTS", "SPEND_TREASURY", "MANAGE_BUILDINGS", "ADVANCE_AGE", "INVITE", "MANAGE_POLICIES"]),
          "citizen": (40, "Citizen", CITIZEN_BASE + ["PLACE_BUILDINGS", "REMOVE_BUILDINGS"]),
          "recruit": (10, "Recruit", ["BUILD", "INTERACT", "CONTRIBUTE"])},
   mods={"contribution_rate_mult": 1.15, "building_cost_mult": 0.95}, policies=["communal_labor", "frugal_rule", "tribute"], slots=2, cost={"points": 40}, cooldown=24),
 "monarchy": dict(name="&6Monarchy", icon="GOLDEN_HELMET", min_age="village", title="Monarch", leader="monarch", default="subject", selection="appointed",
   desc=["A crown rules; stewards manage the purse.", "Subjects may build but not spend.", "Lower building costs, wider borders, heavier taxes."],
   roles={"monarch": (100, "Monarch", ["ALL"]),
          "noble": (80, "Noble", CITIZEN_BASE + BUILDER + ["SPEND_POINTS", "MANAGE_BUILDINGS", "ADVANCE_AGE", "INVITE", "KICK", "APPOINT_OFFICIALS", "MANAGE_POLICIES"]),
          "steward": (60, "Steward", CITIZEN_BASE + BUILDER + ["SPEND_POINTS", "SPEND_TREASURY", "WITHDRAW_TREASURY", "INVITE"]),
          "subject": (30, "Subject", ["BUILD", "CONTAINERS", "INTERACT", "USE_SHOP", "CONTRIBUTE", "PLACE_BUILDINGS"])},
   mods={"building_cost_mult": 0.92, "money_output_mult": 1.05, "claim_radius_add": 8, "points_output_mult": 0.95},
   policies=["royal_charters", "land_grants", "frugal_rule"], slots=2, cost={"points": 150}, cooldown=48),
 "republic": dict(name="&bRepublic", icon="WHITE_BANNER", min_age="medieval", title="President", leader="president", default="citizen", selection="elected",
   desc=["Elected leadership and broad participation.", "Senators control purchases and the funds;", "citizens place what the senate buys."],
   roles={"president": (100, "President", ["ALL"]),
          "senator": (70, "Senator", CITIZEN_BASE + BUILDER + ["SPEND_POINTS", "SPEND_TREASURY", "MANAGE_BUILDINGS", "ADVANCE_AGE", "INVITE", "KICK", "APPOINT_OFFICIALS", "MANAGE_POLICIES", "MANAGE_RANKS"]),
          "citizen": (40, "Citizen", CITIZEN_BASE + ["PLACE_BUILDINGS", "REMOVE_BUILDINGS"]),
          "newcomer": (10, "Newcomer", ["BUILD", "INTERACT", "CONTRIBUTE", "VOTE"])},
   mods={"points_output_mult": 1.05, "housing_mult": 1.05}, policies=["civic_projects", "guild_charters", "frugal_rule"], slots=3, cost={"points": 400}, cooldown=72),
 "theocracy": dict(name="&fTheocracy", icon="BELL", min_age="village", title="High Priest", leader="high_priest", default="faithful", selection="appointed",
   desc=["Rule by the faith. Temples are favoured:", "more shrines and chapels, more resource points,", "but higher building costs."],
   roles={"high_priest": (100, "High Priest", ["ALL"]),
          "priest": (70, "Priest", CITIZEN_BASE + BUILDER + ["SPEND_POINTS", "MANAGE_BUILDINGS", "ADVANCE_AGE", "INVITE", "MANAGE_POLICIES"]),
          "faithful": (40, "Faithful", CITIZEN_BASE + ["PLACE_BUILDINGS", "REMOVE_BUILDINGS"]),
          "novice": (10, "Novice", ["BUILD", "INTERACT", "CONTRIBUTE"])},
   mods={"points_output_mult": 1.08, "building_cost_mult": 1.05, "tag_limit_add.faith": 2}, policies=["tithes", "communal_labor"], slots=2, cost={"points": 150}, cooldown=48),
}

ECONOMIES = {
 "barter": dict(name="&6Barter", icon="LEATHER", min_age=None, money=False, to_points=0.5, exchange=0, contrib_money=False, withdraw=0,
   desc=["Goods change hands, coins do not.", "Money income becomes resource points.", "Material contributions are valued higher."],
   mods={"contribution_rate_mult": 1.2}, policies=["communal_stores"], slots=1, cost={}, cooldown=24),
 "commons": dict(name="&aCommons", icon="WHEAT", min_age=None, money=True, to_points=0.5, exchange=0, contrib_money=True, withdraw=0,
   desc=["Everything is held in common.", "Strong output and contributions, weak trade.", "No treasury withdrawals."],
   mods={"points_output_mult": 1.1, "money_output_mult": 0.6, "contribution_rate_mult": 1.25}, policies=["communal_stores", "work_quotas"], slots=2, cost={"points": 40}, cooldown=24),
 "market": dict(name="&bMarket Economy", icon="EMERALD", min_age="village", money=True, to_points=0.5, exchange=0.3, contrib_money=True, withdraw=400,
   desc=["Trade drives the town.", "Better treasury income; treasury money can be", "converted to points and withdrawn within a limit."],
   mods={"money_output_mult": 1.2, "points_output_mult": 0.95}, policies=["open_market", "trade_tariffs"], slots=2, cost={"points": 80}, cooldown=24),
 "mercantile": dict(name="&6Mercantile", icon="GOLD_INGOT", min_age="medieval", money=True, to_points=0.5, exchange=0.25, contrib_money=True, withdraw=1000,
   desc=["Wealth above all.", "Large treasury income and withdrawals,", "but buildings cost more and output is lower."],
   mods={"money_output_mult": 1.3, "building_cost_mult": 1.1, "points_output_mult": 0.9}, policies=["open_market", "investment_bonds", "trade_tariffs"], slots=2, cost={"points": 300}, cooldown=48),
 "planned": dict(name="&cPlanned Economy", icon="PISTON", min_age="medieval", money=True, to_points=0.8, exchange=0.5, contrib_money=True, withdraw=0,
   desc=["The state directs production.", "More resource points and cheaper buildings,", "little treasury income, no withdrawals."],
   mods={"points_output_mult": 1.2, "money_output_mult": 0.7, "building_cost_mult": 0.96}, policies=["work_quotas", "investment_bonds"], slots=2, cost={"points": 300}, cooldown=48),
}

POLICIES = {
 "communal_labor": ("government", "&aCommunal Labor", "CHEST_MINECART", None, {"production_speed_mult": 1.10, "money_output_mult": 0.95}, {"points": 30}, None, ["Everyone works together: buildings", "produce 10% faster, taxes yield a little less."]),
 "tribute": ("government", "&6Tribute", "GOLD_NUGGET", None, {"points_output_mult": 1.10, "contribution_rate_mult": 0.9}, {"points": 40}, "fiscal", ["Citizens owe a tribute: +10% resource points,", "contributions are valued 10% lower."]),
 "frugal_rule": ("government", "&7Frugal Rule", "IRON_NUGGET", None, {"building_cost_mult": 0.92, "points_output_mult": 0.95}, {"points": 50}, "fiscal", ["Careful spending: buildings cost 10% less,", "output is 5% lower."]),
 "royal_charters": ("government", "&6Royal Charters", "PAPER", "village", {"money_output_mult": 1.05, "claim_radius_add": 4}, {"points": 120}, None, ["Crown charters: +5% treasury income,", "+4 border radius."]),
 "land_grants": ("government", "&2Land Grants", "MAP", "village", {"claim_radius_add": 12, "building_cost_mult": 1.05}, {"points": 100}, None, ["Settlers are granted land: +12 border radius,", "buildings cost 5% more."]),
 "tithes": ("government", "&fTithes", "BELL", "village", {"points_output_mult": 1.10}, {"points": 80}, "fiscal", ["The faithful tithe: +10% resource points."]),
 "civic_projects": ("government", "&bCivic Projects", "BRICKS", "medieval", {"housing_mult": 1.10, "production_speed_mult": 1.05}, {"points": 250}, None, ["Public works: +10% housing, +5% production speed."]),
 "guild_charters": ("government", "&eGuild Charters", "ANVIL", "medieval", {"money_output_mult": 1.10}, {"points": 250}, None, ["Guilds regulate trade: +10% treasury income."]),
 "communal_stores": ("economy", "&aCommunal Stores", "BARREL", None, {"contribution_rate_mult": 1.15}, {"points": 30}, None, ["Shared granaries: contributions are valued 15% higher."]),
 "work_quotas": ("economy", "&cWork Quotas", "CLOCK", None, {"production_speed_mult": 1.10, "money_output_mult": 0.9}, {"points": 80}, None, ["Production targets: +10% speed, -10% treasury income."]),
 "open_market": ("economy", "&bOpen Market", "EMERALD", "village", {"money_output_mult": 1.10}, {"points": 120}, None, ["Free trade: +10% treasury income."]),
 "trade_tariffs": ("economy", "&6Trade Tariffs", "GOLD_INGOT", "village", {"money_output_mult": 1.06, "contribution_rate_mult": 0.95}, {"points": 100}, None, ["Tariffs: +6% treasury income, contributions 5% lower."]),
 "investment_bonds": ("economy", "&6Investment Bonds", "PAPER", "medieval", {"building_cost_mult": 0.95}, {"points": 300}, None, ["Borrowing for growth: buildings cost 5% less."]),
}

# =====================================================================  WRITE EVERYTHING
for folder in ("buildings", "ages", "governments", "economies", "policies"): clean(folder)

for bid, d in buildings.items():
    write("buildings", bid, f"# {bid}: see buildings/_example.yml for every available option.", d)

for aid, a in AGES.items():
    d = {"id": aid, "name": a["name"], "order": a["order"], "core_building": a["core"]}
    if a["aliases"]: d["aliases"] = a["aliases"]
    d["claim"] = {"base_radius": a["claim"][0], "per_building": a["claim"][1], "max_radius": a["claim"][2]}
    d["tag_limits"] = {t: {"per_player": v[0], "per_town": v[1]} for t, v in a["tags"].items()}
    if a["req"]: d["requirements"] = a["req"]
    if a["cost"]: d["advance_cost"] = a["cost"]
    if a["retire"]: d["retire"] = a["retire"]
    write("ages", aid, f"# {aid}: requirements use all_of / any_of; retire = buildings phased out when this age is entered.", d)

for gid, g in GOVERNMENTS.items():
    d = {"id": gid, "name": g["name"], "description": g["desc"], "icon": g["icon"]}
    if g["min_age"]: d["min_age"] = g["min_age"]
    d.update({"leader_title": g["title"], "leader_role": g["leader"], "default_role": g["default"], "leader_selection": g["selection"], "allow_custom_roles": True})
    d["roles"] = {r: {"weight": w, "title": t, "permissions": p} for r, (w, t, p) in g["roles"].items()}
    if g["mods"]: d["modifiers"] = g["mods"]
    d["policies"] = g["policies"]; d["policy_slots"] = g["slots"]
    if g["cost"]: d["change_cost"] = g["cost"]
    d["change_cooldown_hours"] = g["cooldown"]
    write("governments", gid, f"# {gid}: roles, leader selection and modifiers. owner = technical ownership, separate from the leader.", d)

for eid, e in ECONOMIES.items():
    d = {"id": eid, "name": e["name"], "description": e["desc"], "icon": e["icon"]}
    if e["min_age"]: d["min_age"] = e["min_age"]
    d.update({"money_enabled": e["money"], "money_to_points": e["to_points"], "exchange_rate": e["exchange"],
              "contribution_money": e["contrib_money"], "withdraw_limit": e["withdraw"]})
    if e["mods"]: d["modifiers"] = e["mods"]
    d["policies"] = e["policies"]; d["policy_slots"] = e["slots"]
    if e["cost"]: d["change_cost"] = e["cost"]
    d["change_cooldown_hours"] = e["cooldown"]
    write("economies", eid, f"# {eid}: an economic system, independent of the government type.", d)

for pid, (kind, name, icon, min_age, fx, cost, excl, desc) in POLICIES.items():
    d = {"id": pid, "name": name, "description": desc, "icon": icon, "kind": kind}
    if min_age: d["min_age"] = min_age
    if excl: d["exclusive_group"] = excl
    d["effects"] = fx; d["cost"] = cost
    write("policies", pid, f"# {pid}: a {kind} policy.", d)

# ---- migration bookkeeping: which OLD default files are obsolete (not shipped any more)
old = [l.strip() for l in open(os.path.join(HERE, "old_defaults.txt")) if l.strip()] if os.path.exists(os.path.join(HERE, "old_defaults.txt")) else []
obsolete = []
for n in old:
    base = n[:-4]
    if base in ("tribal", "village", "medieval", "late_medieval"):
        if base not in AGES: obsolete.append(f"ages/{n}")
    elif base not in buildings:
        obsolete.append(f"buildings/{n}")
with open(os.path.join(ROOT, "obsolete-defaults.txt"), "w") as fh:
    fh.write("# Default files from older versions that are no longer shipped. They are backed up and removed on upgrade.\n")
    fh.write("\n".join(sorted(obsolete)) + "\n")

# ---- block groups the new content needs (appended once)
bg = os.path.join(ROOT, "blockgroups.yml")
text = open(bg).read()
have = set(yaml.safe_load(text).keys())
extra = {
 "leaves": "{tags: [minecraft:leaves]}",
 "smithing_table": "{materials: [SMITHING_TABLE]}",
 "loom": "{materials: [LOOM]}",
 "fletching_table": "{materials: [FLETCHING_TABLE]}",
 "brewing": "{materials: [BREWING_STAND]}",
 "ore_emerald": "{materials: [EMERALD_ORE, DEEPSLATE_EMERALD_ORE]}",
 "redstone_comp": "{materials: [PISTON, STICKY_PISTON, OBSERVER, REPEATER, COMPARATOR, REDSTONE_LAMP, REDSTONE_BLOCK, HOPPER, DROPPER, DISPENSER]}",
}
add = [f"{k}: {v}" for k, v in extra.items() if k not in have]
if add:
    with open(bg, "a") as fh: fh.write("\n# ---- added for the Ages 2.0 content\n" + "\n".join(add) + "\n")

print(f"{len(buildings)} buildings, {len(AGES)} ages, {len(GOVERNMENTS)} governments, {len(ECONOMIES)} economies, {len(POLICIES)} policies; {len(obsolete)} obsolete default files listed")

# =====================================================================  settings.yml + shop.yml
from values import value, POINT_VALUE, CONTRIB_RATE
CONTRIB = ["OAK_LOG", "BIRCH_LOG", "SPRUCE_LOG", "JUNGLE_LOG", "ACACIA_LOG", "DARK_OAK_LOG", "CHERRY_LOG", "MANGROVE_LOG", "COBBLESTONE", "STONE", "STONE_BRICKS",
           "BRICK", "CLAY_BALL", "SAND", "GLASS", "WHEAT", "CARROT", "POTATO", "BEETROOT", "BREAD", "BEEF", "PORKCHOP", "MUTTON", "CHICKEN", "COOKED_BEEF",
           "COOKED_PORKCHOP", "COOKED_MUTTON", "COOKED_CHICKEN", "COD", "SALMON", "LEATHER", "WHITE_WOOL", "STRING", "COAL", "CHARCOAL", "RAW_IRON", "IRON_INGOT",
           "COPPER_INGOT", "GOLD_INGOT", "PAPER", "BOOK", "DIAMOND", "EMERALD", "GUNPOWDER"]
contrib = "\n".join(f"      {m}: {max(0.05, round(value(m) * CONTRIB_RATE / POINT_VALUE, 2))}" for m in CONTRIB)

settings = f"""# Ages - global settings (this file was called town.yml in older versions; it is migrated automatically).
# Per-age rules live in ages/*.yml, per-building rules in buildings/*.yml, roles in governments/*.yml.

founding:
  min_distance_between_towns: 96     # blocks between civilization centers
  name_regex: "[A-Za-z0-9 '_-]{{3,24}}"
  recipe:                            # crafting recipe for the founding core (the first age's core building)
    enabled: true
    ingredients: {{CAMPFIRE: 1, FLINT: 1, STICK: 4}}   # shapeless

members:
  max: 50

defaults:                            # what a new civilization starts with
  government: chiefdom
  economy: barter

protection:
  block_mob_spawning: true           # hostile mobs cannot spawn inside civilization land
  block_mob_explosions: true         # creepers, ghasts etc. cannot damage civilization blocks
  tnt: never                         # allow | never

claims:
  building_margin: 12                # each building claims its area plus this many blocks

buildings:
  max_scan_radius: 20                # 20 = a 41x41x41 check, the largest allowed
  revalidate_delay_seconds: 3        # wait this long after block changes before re-checking a building

respawn:
  enabled: true                      # shrines, chapels, graveyards, keeps... act as civilization spawn points
  civilization_overrides_bed: false  # false: a bed or respawn anchor keeps priority. true: the civilization spawn wins.

production:
  max_catchup_cycles: 1              # missed cycles a building may catch up after being unloaded / the server being down. 1 = none.
  flush_interval_seconds: 30         # how often changed timers and balances are written to the database
  max_speed_bonus: 0.5               # cap on the civilization-wide speed bonus from buildings (0.5 = +50%)

economy:
  income_multiplier: 1.0             # scales ALL treasury money income. Buildings create money from nothing, so lower
                                     # this on servers with a tightly balanced economy.
  ledger:
    loaded_entries: 200              # ledger lines kept in memory per civilization (all are stored)
    coalesce_minutes: 60             # production/tax income within this window is merged into one ledger line
  contributions:                     # resource points per item when a member contributes materials (before economy modifiers)
    items:
{contrib}

limits:                              # shared limit pools: buildings list `tags: [housing]`; age files add per-age caps.
  tags:                              # the STRICTEST of all applicable caps wins. 0 = unlimited here.
    housing: {{per_player: 12}}
    farming: {{per_player: 4}}
    mining: {{per_player: 3}}
    faith: {{per_player: 3}}

villagers:
  untradeable: true                  # plugin-spawned villagers cannot be traded with

shop:
  remote_purchase: false             # true = buy from /ages anywhere; false = only at your civilization core

logistics:                           # rail networks that move goods between buildings
  enabled: true
  min_age: industrial                # the age that unlocks them (set to tribal to have them from the start)
  interval_seconds: 10
  max_rails_per_network: 4000
  items_per_building_per_run: 64
  items_per_network_per_run: 512     # railway stations and depots raise this

migration:
  legacy_money_cost_to_points: 0.1   # old building files with `cost: {{money: N}}` are read as N * this resource points
"""
open(os.path.join(ROOT, "settings.yml"), "w").write(settings)

shop = """# The catalogue is opened from your civilization core (or /ages). Buildings pick a category with `category:`.
# A category used by a building but missing here is created automatically (with a generic icon), so new buildings never
# need a change in this file. `slot` is optional (position in the 36-slot main menu: 10-16, 19-25).
categories:
  government:
    name: "&6Government"
    icon: BELL
    slot: 10
    description: ["Leadership, and the cores that", "move your civilization into the next age."]
  community:
    name: "&eHomes & Faith"
    icon: OAK_DOOR
    slot: 11
    description: ["Housing, places of worship and learning."]
  food:
    name: "&aFood & Farming"
    icon: WHEAT
    slot: 12
    description: ["Hunters, farms, animals and orchards."]
  resources:
    name: "&2Resources"
    icon: IRON_PICKAXE
    slot: 13
    description: ["Woodcutters, quarries and mines."]
  industry:
    name: "&cCrafts & Industry"
    icon: ANVIL
    slot: 14
    description: ["Turn raw materials into tools,", "goods and ingots."]
  trade:
    name: "&bStorage & Trade"
    icon: CHEST
    slot: 15
    description: ["Storage, markets and money."]
  military:
    name: "&4Defence"
    icon: IRON_SWORD
    slot: 16
    description: ["Towers, keeps and guards."]
  infrastructure:
    name: "&7Infrastructure"
    icon: RAIL
    slot: 19
    description: ["Railways and automation."]
"""
open(os.path.join(ROOT, "shop.yml"), "w").write(shop)
print("settings.yml and shop.yml written")
