#!/usr/bin/env python3
"""
Offline balance audit for Ages. Prices items in "coins" (tools/values.py) and resource points at POINT_VALUE coins,
then checks recipes, RP generation, pacing, upgrades, modifier extremes and loops. Run: python3 tools/balance.py [--detail]
Exit code 1 only for hard failures; warnings are advisory.
"""
import yaml, glob, os, sys, math, collections, copy
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from values import value, max_dur, SELL_RATIO, POINT_VALUE, CONTRIB_RATE, UNKNOWN
R = os.path.join(HERE, "..", "src", "main", "resources")
DETAIL = "--detail" in sys.argv
warns, fails = [], []
def hdr(t): print("\n" + "=" * 6, t, "=" * 6)
def load(f): return yaml.safe_load(open(f))
def avg(l): return sum(l) / len(l) if l else 0.0

ages = {a["id"]: a for a in (load(f) for f in glob.glob(f"{R}/ages/[!_]*.yml"))}
AGE_IDS = sorted(ages, key=lambda k: ages[k]["order"])
raw = {b["id"]: b for b in (load(f) for f in sorted(glob.glob(f"{R}/buildings/[!_]*.yml")))}
govs = {g["id"]: g for g in (load(f) for f in glob.glob(f"{R}/governments/[!_]*.yml"))}
econs = {e["id"]: e for e in (load(f) for f in glob.glob(f"{R}/economies/[!_]*.yml"))}
pols = {p["id"]: p for p in (load(f) for f in glob.glob(f"{R}/policies/[!_]*.yml"))}
settings = load(f"{R}/settings.yml")
CONTRIB = settings["economy"]["contributions"]["items"]

# ------------------------------------------------------------------ effective levels (mirrors BuildingDef#derive)
def levels(b):
    base = {"level": 1, "age": b["age"], "upgrade_cost": {}, "fn": copy.deepcopy(b.get("function")), "provides": dict(b.get("provides", {}))}
    out = [base]
    cur = base
    for n, u in enumerate(b.get("upgrades", []), start=2):
        nxt = copy.deepcopy(cur)
        nxt["level"] = n; nxt["age"] = u.get("age", b["age"]); nxt["upgrade_cost"] = u.get("cost", {})
        for k, v in u.get("provides", {}).items(): nxt["provides"][k] = nxt["provides"].get(k, 0) + v
        uf = u.get("function") or {}
        if nxt["fn"]:
            f = nxt["fn"]
            f.setdefault("recipes", []).extend(uf.get("recipes", []))
            f.setdefault("always", []).extend(uf.get("always", []))
            for k in ("interval", "cap", "per_resident"): 
                if k in uf: f[k] = uf[k]
        out.append(nxt); cur = nxt
    return out

# ------------------------------------------------------------------ pricing
def ing_value(i):
    items = i.get("any_of") or [i["item"]]
    if i.get("durability"): return avg([value(x) * i["durability"] / max_dur(x) for x in items]), True
    return avg([value(x) for x in items]) * i.get("amount", 1), False

def entry_value(e):
    if "points" in e: return e["points"] * POINT_VALUE
    if "money" in e: return e["money"]
    if e["item"] == "AIR": return 0.0
    return (e.get("min", 1) + e.get("max", e.get("min", 1))) / 2 * value(e["item"])

def out_value(p):
    es = p["entries"]
    if p.get("pick", "one") == "all":
        return sum(e.get("chance", 1.0) * entry_value(e) for e in es)
    pct = [e for e in es if "percent" in e]
    if pct:
        return sum(e["percent"] / 100.0 * entry_value(e) for e in pct)
    tw = sum(e.get("weight", 1) for e in es)
    return sum(e.get("weight", 1) * entry_value(e) for e in es) / tw

def out_points(p):
    es = p["entries"]
    if p.get("pick", "one") == "all": return sum(e.get("chance", 1.0) * e["points"] for e in es if "points" in e)
    pct = [e for e in es if "percent" in e]
    if pct: return sum(e["percent"] / 100.0 * e["points"] for e in pct if "points" in e)
    tw = sum(e.get("weight", 1) for e in es)
    return sum(e.get("weight", 1) * e["points"] for e in es if "points" in e) / tw

def cost_coins(c):
    return c.get("points", 0) * POINT_VALUE + c.get("treasury", 0) + sum(value(k) * v for k, v in c.get("items", {}).items())

def always_stats(fn):
    cyc = 3600 / fn.get("interval", 600)
    pts = sum(e["points"] for e in fn.get("always", []) if "points" in e) * cyc
    mon = sum(e["money"] for e in fn.get("always", []) if "money" in e) * cyc
    return pts, mon

# ------------------------------------------------------------------ 1. recipes
hdr("1. RECIPE CONVERSIONS (output value / input value)")
print("   item->item target 0.5-1.4 (crafting may cost a little); item->money 0.35-0.95; item->points at most 2x what contributing those items would give")
for bid, b in raw.items():
    for lv in levels(b)[-1:]:
        fn = lv["fn"]
        if not fn: continue
        for r in fn.get("recipes", []):
            cin = wear = 0.0
            contrib_pts = 0.0
            for i in r.get("consume", []):
                v, tool = ing_value(i)
                if tool: wear += v
                else:
                    cin += v
                    items = i.get("any_of") or [i["item"]]
                    contrib_pts += avg([CONTRIB.get(x, value(x) * CONTRIB_RATE / POINT_VALUE) for x in items]) * i.get("amount", 1)
            if cin < 1.5: continue
            es = r["produce"]["entries"]
            has_money = any("money" in e for e in es); has_pts = any("points" in e for e in es)
            out_v = out_value(r["produce"]); ratio = out_v / (cin + wear)
            tag = ""
            if has_money and not (0.35 <= ratio <= 0.95): tag = "  <-- money ratio"
            elif has_pts and not has_money:
                pr = out_points(r["produce"]) / max(contrib_pts, 1e-9)
                if pr > 2.0: tag = f"  <-- points {pr:.1f}x the contribution value"
            elif not has_money and not has_pts and not (0.3 <= ratio <= 1.4): tag = "  <-- item ratio"
            if tag: warns.append(f"{bid} recipe {r['id']} x{ratio:.2f}{tag.strip()}")
            if DETAIL or tag: print(f"  {bid:16} {r['id']:16} in {cin + wear:7.1f}  out {out_v:7.1f}  x{ratio:5.2f}{tag}")

# ------------------------------------------------------------------ 2. RP generation, cost and payback
hdr("2. RESOURCE POINT GENERATION (always-outputs) and payback of each building's own cost")
rp_rows = []
for bid, b in raw.items():
    lv = levels(b)[0]
    fn = lv["fn"] or {}
    pts, mon = always_stats(fn) if fn else (0, 0)
    cost = b.get("cost", {}).get("points", 0)
    rp_rows.append((b["age"], bid, pts, mon, cost))
for age, bid, pts, mon, cost in sorted(rp_rows, key=lambda r: (AGE_IDS.index(r[0]), -r[2])):
    pay = cost / pts if pts > 0 and cost > 0 else None
    tag = ""
    if pay is not None and AGE_IDS.index(age) >= 1 and (pay > 30 or pay < 1.0): tag = "  <-- payback"; warns.append(f"{bid}: RP payback {pay:.1f}h")
    if DETAIL or tag: print(f"  {age:10} {bid:18} {pts:6.1f} RP/hr {mon:5.1f} money/hr   cost {cost:5.0f} RP   payback {('%.1fh' % pay) if pay else '-':>7}{tag}")

# ------------------------------------------------------------------ 3. saturation, pacing
hdr("3. SATURATION: RP/hr with every building built to its limit, and the cost to get there")
def count_of(b):
    return b.get("limits", {}).get("max_per_town", 1) or 1
def level_at(b, age_i):
    lvs = [l for l in levels(b) if AGE_IDS.index(l["age"]) <= age_i]
    return lvs[-1]
sat = {}
cores = {a["core_building"]: k for k, a in ages.items()}
for ai, age in enumerate(AGE_IDS):
    rp = mon = cost_all = 0.0
    for bid, b in raw.items():
        if AGE_IDS.index(b["age"]) > ai: continue
        if bid in cores and cores[bid] != age: continue                       # retired cores do not count
        if any(bid in ages[a].get("retire", []) for a in AGE_IDS[:ai + 1]): continue
        n = count_of(b)
        lv = level_at(b, ai)
        pts, m = always_stats(lv["fn"]) if lv["fn"] else (0, 0)
        rp += n * pts; mon += n * m
        cost_all += n * b.get("cost", {}).get("points", 0)
    sat[age] = dict(rp=rp, mon=mon, cost=cost_all)
    print(f"  {age:11} {rp:7.0f} RP/hr  {mon:6.0f} money/hr   {cost_all:7.0f} RP to build everything   ({cost_all / rp if rp else 0:4.1f}h of income)")
    if age != "tribal" and rp and cost_all / rp > 16: warns.append(f"{age}: saturating takes {cost_all / rp:.1f}h of its own income")

hdr("4. PACING: hours of SATURATED income of an age to afford the next age core")
for i in range(1, len(AGE_IDS)):
    prev, nxt = AGE_IDS[i - 1], AGE_IDS[i]
    c = ages[nxt].get("advance_cost", {})
    hrs = c.get("points", 0) / sat[prev]["rp"]
    items = cost_coins({"items": c.get("items", {})})
    print(f"  {prev} -> {nxt}: {c.get('points', 0):6.0f} RP (+items worth ~{items:.0f} coins)   {hrs:4.1f}h at saturation")
    if not (0.5 <= hrs <= 6): warns.append(f"{prev}->{nxt}: {hrs:.1f}h of saturated income (aim 0.5-6h)")

# ------------------------------------------------------------------ 5. solo progression
hdr("5. SOLO PROGRESSION (one player, no contributions, greedy cheapest-first)")
def needed(cond, owned):
    """buildings still missing to satisfy a requirement tree; any_of picks the cheapest option"""
    if cond is None: return []
    if isinstance(cond, list): return sum((needed(c, owned) for c in cond), [])
    miss = []
    for k, v in cond.items():
        if k == "all_of": miss += needed(v, owned)
        elif k == "any_of":
            opts = [needed(o, owned) for o in v]
            miss += min(opts, key=lambda o: sum(raw[b]["cost"].get("points", 0) for b in o) if o else -1)
        elif k == "building":
            have = owned.get(v, 0); want = cond.get("count", 1)
            miss += [v] * max(0, want - have)
    return miss
owned = {"chiefs_hut": 1}
def ph(b):
    lv = level_at(raw[b], len(AGE_IDS) - 1)
    return always_stats(lv["fn"])[0] if lv["fn"] else 0
rp_hr = ph("chiefs_hut"); bank = 0.0; clock = 0.0
for i in range(1, len(AGE_IDS)):
    age = ages[AGE_IDS[i]]
    todo = sorted(needed(age.get("requirements"), owned), key=lambda b: raw[b].get("cost", {}).get("points", 0))
    for b in todo:
        c = raw[b].get("cost", {}).get("points", 0)
        if bank < c: dt = (c - bank) / rp_hr; clock += dt; bank += dt * rp_hr
        bank -= c; owned[b] = owned.get(b, 0) + 1; rp_hr += ph(b)
    c = age.get("advance_cost", {}).get("points", 0)
    if bank < c: dt = (c - bank) / rp_hr; clock += dt; bank += dt * rp_hr
    bank -= c
    # entering the age: the new core replaces the old one and retired buildings stop producing
    for r in age.get("retire", []):
        rp_hr -= owned.pop(r, 0) * ph(r)
    owned[age["core_building"]] = 1; rp_hr += ph(age["core_building"])
    print(f"  reaches {AGE_IDS[i]:11} after {clock:5.1f}h   ({len(todo)} required buildings bought; income now {rp_hr:5.0f} RP/hr)")
    if i == 1 and clock > 8: warns.append(f"a solo player needs {clock:.1f}h to leave the Tribal age")

# ------------------------------------------------------------------ 6. upgrades
hdr("6. UPGRADES")
for bid, b in raw.items():
    ls = levels(b)
    for i in range(1, len(ls)):
        a, c = ls[i - 1], ls[i]
        pa = always_stats(a["fn"])[0] if a["fn"] else 0
        pc = always_stats(c["fn"])[0] if c["fn"] else 0
        cost = c["upgrade_cost"].get("points", 0)
        extra = []
        if a["fn"] and c["fn"]:
            if a["fn"].get("interval") != c["fn"].get("interval"): extra.append(f"interval {a['fn'].get('interval')}->{c['fn'].get('interval')}s")
            nr = len(c["fn"].get("recipes", [])) - len(a["fn"].get("recipes", []))
            if nr: extra.append(f"+{nr} recipes")
            if a["fn"].get("cap") != c["fn"].get("cap"): extra.append(f"cap {a['fn'].get('cap')}->{c['fn'].get('cap')}")
        if c["provides"].get("housing", 0) != a["provides"].get("housing", 0): extra.append(f"housing +{c['provides'].get('housing', 0) - a['provides'].get('housing', 0):g}")
        base_cost = b.get("cost", {}).get("points", 0)
        tag = ""
        if base_cost and cost > base_cost * 6: tag = "  <-- far more than the base building"; warns.append(f"{bid} L{c['level']} costs {cost / base_cost:.1f}x its base")
        print(f"  {bid:16} L{c['level']} ({c['age']:10}) {cost:5.0f} RP   {', '.join(extra)}{tag}")

# ------------------------------------------------------------------ 7. modifier extremes
hdr("7. MODIFIER EXTREMES (what a civilization could stack using only the policies its government and economy actually offer)")
def pick(offered, slots, key, maximize):
    ps = sorted((pols[p] for p in offered if p in pols), key=lambda p: p["effects"].get(key, 1.0), reverse=maximize)
    chosen, groups = [], set()
    for p in ps:
        v = p["effects"].get(key, 1.0)
        if (maximize and v <= 1.0) or (not maximize and v >= 1.0) or len(chosen) >= slots: break
        grp = p.get("exclusive_group")
        if grp and grp in groups: continue
        chosen.append(v)
        if grp: groups.add(grp)
    return math.prod(chosen)
def extreme(key, maximize, with_policies=True):
    vals = []
    for g in govs.values():
        for e in econs.values():
            v = g.get("modifiers", {}).get(key, 1.0) * e.get("modifiers", {}).get(key, 1.0)
            if with_policies:
                v *= pick(g.get("policies", []), g.get("policy_slots", 2), key, maximize) * pick(e.get("policies", []), e.get("policy_slots", 2), key, maximize)
            vals.append(v)
    return max(vals) if maximize else min(vals)
for key, high_good in [("points_output_mult", True), ("money_output_mult", True), ("production_speed_mult", True), ("building_cost_mult", False), ("contribution_rate_mult", True)]:
    best = extreme(key, high_good)
    worst = extreme(key, not high_good, with_policies=False)
    print(f"  {key:24} best x{best:4.2f}   worst (no helpful policies) x{worst:4.2f}")
    if high_good and best > 1.7: warns.append(f"{key}: stackable up to x{best:.2f}")
    if not high_good and best < 0.7: warns.append(f"{key}: stackable down to x{best:.2f}")

# ------------------------------------------------------------------ 8. loops
hdr("8. RECIPE LOOPS")
edges = collections.defaultdict(list)
for bid, b in raw.items():
    fn = levels(b)[-1]["fn"]
    if not fn: continue
    for r in fn.get("recipes", []):
        cin = sum(ing_value(i)[0] for i in r.get("consume", []) if not i.get("durability"))
        if cin < 1.5: continue
        ratio = out_value(r["produce"]) / (cin + sum(ing_value(i)[0] for i in r.get("consume", []) if i.get("durability")))
        for i in r.get("consume", []):
            if i.get("durability"): continue
            for it in (i.get("any_of") or [i["item"]]):
                for e in r["produce"]["entries"]:
                    if "item" in e and e["item"] != "AIR": edges[it].append((e["item"], ratio, bid))
found = 0
def dfs(start, node, prod, path, seen):
    global found
    for nxt, ratio, bid in edges.get(node, []):
        p = prod * ratio
        if nxt == start:
            if p > 1.0: found += 1; print(f"  LOOP x{p:.2f}: {' -> '.join(path + [start])} (via {bid})"); warns.append(f"loop x{p:.2f} through {start}")
        elif nxt not in seen and len(path) < 6: dfs(start, nxt, p, path + [nxt], seen | {nxt})
for item in list(edges): dfs(item, item, 1.0, [item], {item})
if not found: print("  none")

if UNKNOWN: print("\nNOTE: no value defined for", sorted(UNKNOWN), "(treated as 0)")
hdr("RESULT")
print(f"{len(warns)} warning(s)")
for w in warns: print("  -", w)
sys.exit(1 if fails else 0)
