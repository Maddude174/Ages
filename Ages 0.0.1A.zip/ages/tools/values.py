"""Shared item values ("coins"), used by balance.py and by the content generator so sell prices derive from worth."""
VALUE = {
 "STICK": .1, "FLINT": .4, "COBBLESTONE": .3, "GRAVEL": .1, "SAND": .2, "RED_SAND": .2, "CLAY_BALL": .5, "STONE": .4,
 "STONE_BRICKS": .4, "BRICK": .8, "GLASS": .4, "COAL": 1.5, "CHARCOAL": 1.0, "RAW_IRON": 3, "IRON_INGOT": 3.5,
 "RAW_COPPER": 1.2, "COPPER_INGOT": 1.5, "RAW_GOLD": 5, "GOLD_INGOT": 6, "REDSTONE": 1, "LAPIS_LAZULI": 1.5,
 "DIAMOND": 60, "EMERALD": 40, "ANCIENT_DEBRIS": 150, "NETHERITE_SCRAP": 150, "NETHERITE_INGOT": 700, "IRON_BLOCK": 31.5,
 "SAPLING": .3, "SEEDS": .25, "WHEAT": 1, "BREAD": 3, "CARROT": .8, "POTATO": .8, "BEETROOT": .7, "MELON_SLICE": .3,
 "PUMPKIN": 1.5, "SUGAR_CANE": .8, "SUGAR": .8, "PAPER": .8, "BOOK": 4.4, "EGG": .5, "FEATHER": .3, "CHICKEN": 1,
 "BEEF": 1, "PORKCHOP": 1, "MUTTON": 1, "RABBIT": 1, "LEATHER": 2, "WOOL": 1.5, "COD": .8, "SALMON": 1, "PUFFERFISH": 1,
 "TROPICAL_FISH": 1, "POISONOUS_POTATO": .1, "HONEY_BOTTLE": 3, "HONEYCOMB": 2, "APPLE": 1.5, "SWEET_BERRIES": .5,
 "BROWN_MUSHROOM": .5, "COOKIE": .3, "PUMPKIN_PIE": 3.5, "COOKED_BEEF": 1.4, "COOKED_PORKCHOP": 1.4, "COOKED_MUTTON": 1.3,
 "COOKED_CHICKEN": 1.2, "COOKED_COD": 1.1, "COOKED_SALMON": 1.3, "GUNPOWDER": 1.8, "BONE_MEAL": .3, "BONE": .3,
 "ARROW": .2, "BOW": 1.5, "SHIELD": 4.2, "COCOA_BEANS": .5, "STRING": .5, "GLASS_BOTTLE": .4, "STICK_": .1,
 "MILK_BUCKET": 4, "BUCKET": 3.5, "CAKE": 8, "FLOWER_POT": 2.8, "DECORATED_POT": 3.4, "TERRACOTTA": .6, "MAP": 4, "COMPASS": 5, "GLASS_PANE": .2,
 "WHITE_CARPET": 1.0, "SADDLE": 8, "LEAD": 2, "GOLDEN_CARROT": 6.1, "SUSPICIOUS_STEW": 2.5, "BOWL": .3, "GOLD_NUGGET": .67, "DANDELION": .1,
 "POPPY": .1, "FERN": .1, "BAMBOO": .1, "RED_MUSHROOM": .5, "ANDESITE": .2, "DIORITE": .2, "GRANITE": .2, "IRON_NUGGET": .4, "HAY_BLOCK": 9,
 "LOG": .8, "PLANKS": .2, "OAK_SAPLING": .3, "SHEARS": 7.0, "FISHING_ROD": 1.3, "LAVA": 0,
}
DUR = {"WOODEN": 59, "STONE": 131, "COPPER": 190, "IRON": 250, "GOLDEN": 32, "DIAMOND": 1561, "NETHERITE": 2031}
TIER_MAT = {"WOODEN": "PLANKS", "STONE": "COBBLESTONE", "COPPER": "COPPER_INGOT", "IRON": "IRON_INGOT", "GOLDEN": "GOLD_INGOT", "DIAMOND": "DIAMOND"}
TOOL_N = {"SWORD": 2, "PICKAXE": 3, "AXE": 3, "SHOVEL": 1, "HOE": 2}
ARMOR_N = {"HELMET": 5, "CHESTPLATE": 8, "LEGGINGS": 7, "BOOTS": 4}
OTHER_DUR = {"SHEARS": 238, "FISHING_ROD": 64, "BOW": 384}
SELL_RATIO = 0.65          # shops/markets pay this fraction of fair value: selling is always worse than using the item
POINT_VALUE = 4.0          # one resource point is worth this many coins; contributions convert at CONTRIB_RATE of fair value
CONTRIB_RATE = 0.8
UNKNOWN = set()

def value(item):
    if item in VALUE: return VALUE[item]
    if item.endswith("_LOG") or item.endswith("_WOOD"): return VALUE["LOG"]
    if item.endswith("_PLANKS"): return VALUE["PLANKS"]
    if item.endswith("_SAPLING") or item == "MANGROVE_PROPAGULE": return VALUE["SAPLING"]
    if item.endswith("_SEEDS"): return VALUE["SEEDS"]
    if item.endswith("_WOOL"): return VALUE["WOOL"]
    parts = item.split("_", 1)
    if len(parts) == 2:
        tier, kind = parts
        if tier == "NETHERITE" and (kind in TOOL_N or kind in ARMOR_N):
            return value("DIAMOND_" + kind) + VALUE["NETHERITE_INGOT"]
        if tier in TIER_MAT and kind in TOOL_N:
            return TOOL_N[kind] * value(TIER_MAT[tier]) + (1 if kind == "SWORD" else 2) * VALUE["STICK"]
        if tier in TIER_MAT and kind in ARMOR_N:
            return ARMOR_N[kind] * value(TIER_MAT[tier])
    UNKNOWN.add(item)
    return 0.0

def max_dur(item):
    if item in OTHER_DUR: return OTHER_DUR[item]
    return DUR.get(item.split("_", 1)[0], 100)

def price(item):
    """Sell price: a fixed fraction of fair value."""
    return round(value(item) * SELL_RATIO, 2)
