#!/usr/bin/env python3
"""Offline structural check of the shipped YAML: mirrors the rules the plugin's loader enforces at startup.
Material names are verified by the plugin itself at startup; this script prints every material used so typos are easy to spot."""
import yaml, glob, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
R = os.path.join(HERE, "..", "src", "main", "resources")
err, warn = [], []
def load(f): return yaml.safe_load(open(f))

groups = load(f"{R}/blockgroups.yml")
cats = set(load(f"{R}/shop.yml")["categories"])
settings = load(f"{R}/settings.yml")
perm_src = open(os.path.join(HERE, "..", "src/main/java/dev/ages/model/Perm.java")).read()
PERMS = set(re.findall(r'^\s+([A-Z_]+)\("', perm_src, re.M))

ages = {a["id"]: a for a in (load(f) for f in glob.glob(f"{R}/ages/[!_]*.yml"))}
blds = {}
for f in sorted(glob.glob(f"{R}/buildings/[!_]*.yml")):
    b = load(f)
    if b["id"] != os.path.basename(f)[:-4]: err.append(f"{f}: id/filename mismatch")
    if b["id"] in blds: err.append("duplicate building " + b["id"])
    blds[b["id"]] = b
govs = {g["id"]: g for g in (load(f) for f in glob.glob(f"{R}/governments/[!_]*.yml"))}
econs = {e["id"]: e for e in (load(f) for f in glob.glob(f"{R}/economies/[!_]*.yml"))}
pols = {p["id"]: p for p in (load(f) for f in glob.glob(f"{R}/policies/[!_]*.yml"))}

materials = set()
DAMAGEABLE = re.compile(r'^(WOODEN|STONE|IRON|GOLDEN|DIAMOND|NETHERITE|COPPER)_(SWORD|PICKAXE|AXE|SHOVEL|HOE)$|^(BOW|FISHING_ROD|SHEARS|CROSSBOW)$')

def entries_ok(ctx, pm, container_out):
    pick = pm.get("pick", "one")
    es = pm.get("entries", [])
    if not es: err.append(f"{ctx}: no entries")
    pct = [e for e in es if "percent" in e]
    if pct:
        if pick != "one": err.append(f"{ctx}: percent needs pick: one")
        if len(pct) != len(es): err.append(f"{ctx}: percent must be on every entry")
        if sum(e["percent"] for e in pct) > 100.0001: err.append(f"{ctx}: percent totals {sum(e['percent'] for e in pct)} > 100")
        if any("weight" in e for e in es): err.append(f"{ctx}: mixing weight and percent")
    has_item = False
    for e in es:
        if "item" in e:
            if e["item"] != "AIR": has_item = True; materials.add(e["item"])
            if e["item"] != "AIR" and e.get("min", 1) < 1: err.append(f"{ctx}: item min < 1")
            if e.get("max", e.get("min", 1)) < e.get("min", 1): err.append(f"{ctx}: max < min")
        elif "points" not in e and "money" not in e: err.append(f"{ctx}: entry without item/points/money")
        if not 0 <= e.get("chance", 1) <= 1: err.append(f"{ctx}: chance out of range")
    return has_item

def recipes_ok(ctx, recs, has_in, has_out, ids):
    for r in recs:
        c2 = f"{ctx} recipe {r['id']}"
        if r["id"] in ids: err.append(f"{c2}: duplicate id")
        ids.add(r["id"])
        for ing in r.get("consume", []):
            for m in ([ing["item"]] if "item" in ing else ing.get("any_of", [])):
                materials.add(m)
                if "durability" in ing and not DAMAGEABLE.match(m) and not r.get("optional"): err.append(f"{c2}: {m} is not a known damageable item")
        if r.get("consume") and not has_in: err.append(f"{c2}: consumes but the building has no input container")
        if entries_ok(c2, r["produce"], has_out) and not has_out: err.append(f"{c2}: item outputs but no output container")

def cond_refs(c, out):
    if isinstance(c, list): [cond_refs(x, out) for x in c]
    elif isinstance(c, dict):
        for k, v in c.items():
            if k in ("all_of", "any_of"): cond_refs(v, out)
            elif k == "building": out.add(v)

aliases = {}
for bid, b in blds.items():
    if b["age"] not in ages: err.append(f"{bid}: unknown age {b['age']}")
    if b["category"] not in cats: warn.append(f"{bid}: category '{b['category']}' is not in shop.yml (will be created automatically)")
    materials.add(b["core_block"])
    for r in b["requirements"]:
        if "group" in r and r["group"] not in groups: err.append(f"{bid}: unknown group {r['group']}")
        if "material" in r: materials.add(r["material"])
    for ax in ("x", "z", "up", "down"):
        if b["scan"][ax] > settings["buildings"]["max_scan_radius"]: err.append(f"{bid}: scan too big")
    lg = b.get("logistics", {})
    in_ok, out_ok = "input" in lg, "output" in lg
    core_container = b["core_block"] in ("BARREL", "CHEST", "TRAPPED_CHEST")
    if (lg.get("input") == "CORE" or lg.get("output") == "CORE") and not core_container: err.append(f"{bid}: CORE container needs a chest/barrel core")
    for k in ("input", "output"):
        if lg.get(k) and lg[k] != "CORE": materials.add(lg[k])
    fn = b.get("function")
    ids = set()
    if fn:
        if fn.get("mode", "random") not in ("random", "first", "all", "selected"): err.append(f"{bid}: bad mode")
        if fn.get("mode") == "selected" and not fn.get("recipes"): err.append(f"{bid}: selected mode without recipes")
        if fn.get("interval", 300) < 1: err.append(f"{bid}: interval < 1")
        recipes_ok(bid, fn.get("recipes", []), in_ok, out_ok, ids)
        if fn.get("always"):
            if entries_ok(f"{bid} always", {"pick": "all", "entries": fn["always"]}, out_ok) and not out_ok: err.append(f"{bid}: always item output without container")
        if fn["type"] == "spawner":
            if "entity" not in fn: err.append(f"{bid}: spawner without entity")
            for c in fn.get("consume", []):
                materials.add(c["item"] if "item" in c else c["any_of"][0])
                if not in_ok: err.append(f"{bid}: spawner consumes but no input container")
    prev = ages[b["age"]]["order"] if b["age"] in ages else 0
    for n, u in enumerate(b.get("upgrades", []), start=2):
        ua = u.get("age", b["age"])
        if ua not in ages: err.append(f"{bid} L{n}: unknown age {ua}"); continue
        if ages[ua]["order"] < prev: err.append(f"{bid} L{n}: age goes backwards")
        prev = ages[ua]["order"]
        for r in u.get("requirements", []):
            if "group" in r and r["group"] not in groups: err.append(f"{bid} L{n}: unknown group {r['group']}")
            if "material" in r: materials.add(r["material"])
        uf = u.get("function", {})
        if uf and not fn: err.append(f"{bid} L{n}: function override without a base function")
        recipes_ok(f"{bid} L{n}", uf.get("recipes", []), in_ok, out_ok, ids)
    for al in b.get("aliases", []):
        if al in blds or al in aliases: err.append(f"{bid}: alias '{al}' collides with another building/alias")
        aliases[al] = bid
    for rep in b.get("replaces", []):
        if rep not in blds and rep not in aliases: warn.append(f"{bid}: replaces unknown building {rep}")
    for k in b.get("cost", {}).get("items", {}): materials.add(k)
    if b["age"] == "tribal" and b.get("cost", {}).get("treasury"): err.append(f"{bid}: tribal buildings should not cost treasury money")

ordered = sorted(ages.values(), key=lambda a: a["order"])
if len({a["order"] for a in ordered}) != len(ordered): err.append("ages share an order value")
cores = {}
for a in ordered:
    if a["core_building"] not in blds: err.append(f"age {a['id']}: core {a['core_building']} missing")
    elif blds[a["core_building"]]["category"] != "government": warn.append(f"age {a['id']}: core is not in category government")
    if a["core_building"] in cores: err.append(f"age {a['id']}: core reused")
    cores[a["core_building"]] = a["id"]
    refs = set(); cond_refs(a.get("requirements", {}), refs)
    for r in refs:
        if r not in blds and r not in aliases: err.append(f"age {a['id']}: requirement references unknown building {r}")
        elif r in blds and ages[blds[r]["age"]]["order"] >= a["order"]: err.append(f"age {a['id']}: requires {r} which belongs to this or a later age")
    for r in a.get("retire", []):
        if r not in blds: err.append(f"age {a['id']}: retire unknown {r}")
    for k in a.get("advance_cost", {}).get("items", {}): materials.add(k)
    for t, v in a.get("tag_limits", {}).items():
        if v.get("per_player", 0) > v.get("per_town", 0) > 0: warn.append(f"age {a['id']}: tag {t} per_player exceeds per_town")
first = ordered[0]
if "requirements" in first: err.append("the first age should have no requirements")
# single-player requirement: no population leaf anywhere in the shipped ages
if "population" in str(load(f"{R}/ages/{ordered[1]['id']}.yml").get("requirements", "")): err.append("population requirement present in the first advancement")

for gid, g in govs.items():
    for rn, r in g["roles"].items():
        for p in r["permissions"]:
            if p != "ALL" and p not in PERMS: err.append(f"gov {gid}: role {rn} unknown permission {p}")
    for k in ("leader_role", "default_role"):
        if g[k] not in g["roles"]: err.append(f"gov {gid}: {k} {g[k]} is not a role")
    if g.get("min_age") and g["min_age"] not in ages: err.append(f"gov {gid}: unknown min_age")
    for p in g.get("policies", []):
        if p not in pols: err.append(f"gov {gid}: unknown policy {p}")
        elif pols[p]["kind"] != "government": err.append(f"gov {gid}: policy {p} is not a government policy")
    leader = g["roles"][g["leader_role"]]["weight"]
    if any(r["weight"] >= leader for n, r in g["roles"].items() if n != g["leader_role"]): err.append(f"gov {gid}: the leader role must outrank every other role")
    # a role that can spend must also be able to buy
    for rn, r in g["roles"].items():
        perms = set(r["permissions"])
        if "ALL" not in perms and "PURCHASE_BUILDINGS" in perms and "SPEND_POINTS" not in perms and rn != g["leader_role"]:
            warn.append(f"gov {gid}: role {rn} may purchase but cannot spend points (it relies on others/ contributions)")
for eid, e in econs.items():
    if e.get("min_age") and e["min_age"] not in ages: err.append(f"economy {eid}: unknown min_age")
    for p in e.get("policies", []):
        if p not in pols: err.append(f"economy {eid}: unknown policy {p}")
        elif pols[p]["kind"] != "economy": err.append(f"economy {eid}: policy {p} is not an economy policy")
for pid, p in pols.items():
    if p.get("min_age") and p["min_age"] not in ages: err.append(f"policy {pid}: unknown min_age")
if settings["defaults"]["government"] not in govs: err.append("default government missing")
if settings["defaults"]["economy"] not in econs: err.append("default economy missing")
for m in settings["economy"]["contributions"]["items"]: materials.add(m)

print(f"{len(blds)} buildings, {len(ages)} ages, {len(govs)} governments, {len(econs)} economies, {len(pols)} policies, {len(groups)} block groups")
by = {}
for b in blds.values(): by.setdefault(b["age"], []).append(b["id"])
for a in ordered: print(f"  {a['id']:11} {len(by.get(a['id'], [])):3} buildings")
if "--materials" in sys.argv: print("MATERIALS:", " ".join(sorted(materials)))
for w in warn: print("WARN:", w)
print("ERRORS:" if err else "OK", *err, sep="\n")
sys.exit(1 if err else 0)
