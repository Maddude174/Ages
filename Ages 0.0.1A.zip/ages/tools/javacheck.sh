#!/bin/sh
# Offline compile check: no Paper jar here, so Bukkit symbols are unresolved. We hide those and show the rest:
# syntax errors and mismatches between the plugin's own classes.
cd "$(dirname "$0")/.."
rm -rf /tmp/agesout && mkdir -p /tmp/agesout
find src/main/java -name '*.java' > /tmp/ages_sources.txt
java -m jdk.compiler/com.sun.tools.javac.Main -proc:none -source 21 -target 21 -XDshould-stop.ifError=FLOW -Xmaxerrs 5000 -Xdiags:verbose -d /tmp/agesout @/tmp/ages_sources.txt 2> /tmp/ages_errors.txt
python3 - <<'PY'
import re, glob, os
mine = set()
for f in glob.glob("src/main/java/**/*.java", recursive=True):
    src = open(f).read()
    mine.add(os.path.basename(f)[:-5])
    mine.update(re.findall(r'\b(?:class|record|interface|enum)\s+(\w+)', src))
txt = open("/tmp/ages_errors.txt").read()
blocks = re.split(r'\n(?=src/main/java/\S+\.java:\d+: error:)', txt)
shown = 0
for b in blocks:
    if "error:" not in b: continue
    head = b.splitlines()[0]
    if "does not exist" in head: continue
    m = re.search(r'symbol:\s+class (\w+)', b)
    if m and m.group(1) not in mine: continue            # unresolved library type (Bukkit, Adventure, Vault)
    if re.search(r'symbol:\s+variable [A-Z]\w*\s', b): continue                    # static use of an unresolved library class
    if re.search(r'symbol:\s+method (getLogger|getServer|getDataFolder|getCommand|saveResource|getFile)\(', b): continue   # JavaPlugin members
    if "is ambiguous" in head: continue                                       # overload ambiguity caused by an unresolved Material/Player
    if "does not override or implement" in head: continue                      # @Override against an unresolved library interface
    if "incompatible types" in b and re.search(r'(Material|Player|Block|Entity|Component|ItemStack|Inventory|Location|World)', b): continue
    print(b.rstrip()); print(); shown += 1
print(f"== {shown} relevant error(s) ==")
PY
