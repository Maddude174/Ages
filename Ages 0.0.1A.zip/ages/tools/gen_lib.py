"""Helpers for authoring the shipped YAML. The YAML itself is the source of truth and safe to edit by hand."""
import yaml

class Dumper(yaml.SafeDumper):
    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)

def dump(d):
    return yaml.dump(d, Dumper=Dumper, sort_keys=False, default_flow_style=None, width=118, allow_unicode=True)

# ---- ingredients
def C(item, n=1):
    return {"any_of": item, "amount": n} if isinstance(item, list) else {"item": item, "amount": n}
def T(tools, dur):
    return {"any_of": tools, "durability": dur} if isinstance(tools, list) else {"item": tools, "durability": dur}

# ---- output entries
def E(item, lo, hi=None, percent=None, weight=None, chance=None):
    d = {"item": item, "min": lo, "max": hi if hi is not None else lo}
    if percent is not None: d["percent"] = percent
    if weight is not None: d["weight"] = weight
    if chance is not None: d["chance"] = chance
    return d
def AIR(percent): return {"item": "AIR", "percent": percent}
def PTS(n, chance=None):
    d = {"points": n}
    if chance is not None: d["chance"] = chance
    return d
def MON(n, chance=None):
    d = {"money": n}
    if chance is not None: d["chance"] = chance
    return d
def ONE(*e): return {"pick": "one", "entries": list(e)}
def ALL(*e): return {"pick": "all", "entries": list(e)}

def R(consume, produce, id=None, name=None, interval=None, optional=False):
    d = {}
    if id: d["id"] = id
    if name: d["name"] = name
    if interval: d["interval"] = interval
    d["consume"] = consume
    d["produce"] = produce
    if optional: d["optional"] = True
    return d

AXES = ["WOODEN_AXE", "STONE_AXE", "IRON_AXE"]
PICKS = ["WOODEN_PICKAXE", "STONE_PICKAXE", "IRON_PICKAXE"]
SHOVELS = ["WOODEN_SHOVEL", "STONE_SHOVEL", "IRON_SHOVEL"]
HOES = ["WOODEN_HOE", "STONE_HOE", "IRON_HOE"]
FUEL = C(["COAL", "CHARCOAL"], 1)
LOGS = [f"{w}_LOG" for w in ["OAK", "BIRCH", "SPRUCE", "JUNGLE", "ACACIA", "DARK_OAK", "CHERRY", "MANGROVE"]]
AGES = ["tribal", "village", "medieval", "industrial"]
PROD_MULT = [1, 1, 2, 2]
COMM_MULT = [1, 2, 3, 4]

def round5(x, step=5): return max(step, int(round(x / step)) * step)

class Catalogue:
    def __init__(self):
        self.items = []     # (age, dict, rph, lim tuple)

    def B(self, id, name, cat, age, core, scan, reqs, rph, desc, *, pb=4.0, cost_items=None, free=False,
          shop=True, tags=None, lim=None, limits=None, anywhere=False, io=None, stores=None, provides=None,
          replaces=None, aliases=None, mode=None, interval=600, recipes=None, spawner=None, tax=None,
          upgrades=None, icon=None, always=None, obsolete_in=None, points=True, cost_points=None):
        d = {"id": id, "name": name, "description": desc, "category": cat, "age": age, "core_block": core}
        if icon: d["icon"] = icon
        if not shop: d["shop"] = False
        if aliases: d["aliases"] = aliases
        if replaces: d["replaces"] = replaces
        if obsolete_in: d["obsolete_in"] = obsolete_in
        if tags: d["tags"] = tags
        d["scan"] = {"x": scan[0], "z": scan[1], "up": scan[2], "down": scan[3]}
        d["requirements"] = [({"material": g[2:], "min": n} if g.startswith("M:") else {"group": g, "min": n}) for g, n in reqs]
        cost = {}
        pts = cost_points if cost_points is not None else round5(rph * pb)
        if not free and pts: cost["points"] = pts
        if cost_items: cost["items"] = cost_items
        if cost: d["cost"] = cost
        if limits: d["limits"] = limits
        if anywhere: d["placement"] = "anywhere"
        lg = {}
        if io == "core": lg = {"input": "CORE", "output": "CORE"}
        elif io: lg = {k: v for k, v in (("input", io[0]), ("output", io[1])) if v}
        if stores: lg["stores"] = stores
        if lg: d["logistics"] = lg
        alw = list(always or [])
        if points and rph:
            alw.insert(0, PTS(round(rph * interval / 3600.0, 2)))
        fn = None
        if recipes:
            fn = {"type": "processor", "interval": interval}
            if mode: fn["mode"] = mode
            fn["recipes"] = recipes
        elif spawner:
            fn = {"type": "spawner", "interval": interval, **spawner}
        elif tax:
            fn = {"type": "tax", "interval": interval, **tax}
        elif alw:
            fn = {"type": "none", "interval": interval}
        if fn is not None and alw: fn["always"] = alw
        if fn is not None: d["function"] = fn
        if provides: d["provides"] = provides
        if upgrades: d["upgrades"] = upgrades
        self.items.append((age, d, rph, lim, id))
        return d

    def get(self, id):
        return next(d for a, d, r, l, i in self.items if i == id)

def U(age, points, desc, scan=None, reqs=None, fn=None, provides=None, items=None, always=None, label=None):
    u = {}
    if label: u["label"] = label
    u["age"] = age
    cost = {"points": points}
    if items: cost["items"] = items
    u["cost"] = cost
    u["description"] = desc
    if scan: u["scan"] = {"x": scan[0], "z": scan[1], "up": scan[2], "down": scan[3]}
    if reqs: u["requirements"] = [({"material": g[2:], "min": n} if g.startswith("M:") else {"group": g, "min": n}) for g, n in reqs]
    f = dict(fn or {})
    if always: f["always"] = always
    if f: u["function"] = f
    if provides: u["provides"] = provides
    return u

def LIM(base, kind, age):
    """Per-age caps for a building: from its own age on. kind: prod | comm | fixed."""
    start = AGES.index(age)
    mult = PROD_MULT if kind == "prod" else COMM_MULT if kind == "comm" else [1, 1, 1, 1]
    return tuple(None if i < start else base * mult[i] for i in range(4))
