# Ages 0.2

Civilizations grow through four ages, **Tribal, Village, Medieval, Industrial**, by building structures that unlock bigger ones.
Everything (ages, buildings, recipes, governments, economies, policies, roles, shop categories) is YAML. War and diplomacy are
**not** part of this version.

> **Verification status.** No Minecraft server or Paper jar was available while writing this. What *was* checked by script:
> every YAML file (structure, cross-references, recipe consistency), the economy balance, and the Java sources with a real
> `javac` pass for syntax and mismatches between the plugin's own classes (`tools/javacheck.sh`). Bukkit/Paper API calls could not
> be compiled, so expect to fix a few compile errors on the first Gradle build, and test in-game before relying on it.

## Build and run
1. Java 21 and Gradle (or IntelliJ). Set `paperVersion` in `gradle.properties` to your server's Paper version.
2. `gradle build`, copy `build/libs/Ages-0.2.0.jar` to `plugins/`. Optional: Vault + an economy plugin (only needed for the
   personal-funds features: money contributions and treasury withdrawals).
3. On first start the defaults are written to `plugins/Ages/`. **A broken definition is skipped with a precise console message and the
   rest still loads**; only "no valid ages" or unreadable settings stop the plugin. `/ages reload` keeps the old config on a fatal error.

## How play works
1. Craft the founding core (campfire + flint + 4 sticks, configurable) or `/ages core`. **Build a Chief's Hut first**, then place the core at
   its centre. The area is validated, then you name your civilization in chat. You become the technical owner **and** the first leader.
2. **Right-click your core** for the catalogue (or `/ages`). Buildings are sold as core blocks for **resource points**. Buy, build the
   structure, place the core: the area is scanned and the building activates (or tells you exactly what is missing).
3. Buildings generate resource points and goods on timers. Right-click any building's core for its **building menu**: status, live production
   timer, recipe choice, upgrade, storage access, relocation.
4. Open **`/ages`** for the civilization overview: advancement checklist, buildings, treasury and ledger, government, economy, members and roles.
   Every blocked button says why (role, requirement, funds, limit, cooldown).

## Ages and advancement
| Age | Core (replaces) | Requirements to enter | Cost |
|---|---|---|---|
| Tribal | Chief's Hut | none (start) | - |
| Village | Village Hall (Chief's Hut) | Chief's Hut, 2 Tribal Huts, Storage Hut, **one of** Hunter's Hut / Forager / Fisher's Hut, Woodcutter | 100 RP + a few items |
| Medieval | Town Hall (Village Hall) | Village Hall, Marketplace, Storehouse, **Shrine or Chapel**, Watchtower | 600 RP + items |
| Industrial | City Hall (Town Hall) | Town Hall, Bank, Treasury, Smithy, Glassworks, Library, 2 Townhouses, **Coal or Iron Mine** | 2000 RP + items |

* Requirements are trees: `all_of` / `any_of` nest freely, with leaves `building` (count, level), `tag`, `members`, `points`, `treasury`, `population`.
  The shipped ages use **no population requirement**, so one player can advance alone.
* **Transactional handoff.** The new core is validated first; only then, in one database transaction, the new building is registered, the old core
  and the age's `retire` list are unregistered, and the age changes. Any failure rolls everything back: the Chief's Hut stays intact.
* Conversions use `replaces: [tribal_hut]`: placing a Cottage over a Tribal Hut absorbs it (its villagers move over). Merging works the same way
  (a Manor House replaces several Cottages). `obsolete_in` stops new placements of an old building type.

> **Note on the spec:** the Tribal section lists "2 Huts, Chief's Hut, Hunter's Hut" and the Village section lists a longer set (adds Storage Hut,
> Woodcutter, and Hunter OR Forager OR Fisher). I implemented the **longer Village list** for entering the Village (it contains the shorter one).
> Change `ages/village.yml` if you meant the shorter list.

## Buildings and production (all YAML)
66 buildings: 9 Tribal, 19 Village, 26 Medieval, 12 Industrial, plus upgrade levels. Highlights of what the format can express:
* **Core block per building** (`core_block`). Production buildings ship with **barrel cores** used as input *and* output (`logistics: {input: CORE, output: CORE}`);
  other buildings use separate container blocks or none. The building menu has "open storage" buttons, so a chest/barrel core still works.
* **Recipes** with several inputs and outputs, `mode: random | first | all | selected` (owner picks in the menu), per-recipe `interval`, `optional` recipes.
* **Chance outputs** with `percent` (remainder = nothing), `weight`, or independent `chance`; **`AIR`** is a valid result. Example (Forager):
  berries 25%, mushrooms 10%, flowers 10%, nothing 55%.
* **Durability inputs** (`- {item: BOW, durability: 2}`), consumed items, and `any_of` alternatives. Hunter's Hut uses a bow + arrows, a sword, or snares.
* **Outputs can also be resource points or treasury money** (`{points: 2}`, `{money: 6}`), and `always:` outputs fire every cycle regardless of recipes.
* **Timers are timestamps** stored in the database (`next_run`): they survive restarts, a min-heap means only due buildings are looked at, and
  `production.max_catchup_cycles` (default 1) decides whether missed cycles pile up. The core UI shows the live time to the next production and the last status.
* Validation reports invalid materials, malformed recipes, impossible quantities (min > max, non-damageable durability items), and percent totals above 100%.

## Economy: three kinds of money, kept apart
* **Personal funds**: a player's Vault balance (only touched by contribute/withdraw).
* **Treasury**: shared money, fed by taxes, marketplace/bank income and member contributions; spent with `SPEND_TREASURY`, withdrawn within a daily limit.
* **Resource points (RP)**: the plugin's own currency, generated by buildings; **buildings and ages cost RP**. Spending needs `SPEND_POINTS`.
* **Contributions**: members give materials (rates in `settings.yml`, derived from the value table) or money. Contributing never grants political authority.
* **Persistent ledger**: every contribution, purchase, upgrade, withdrawal, conversion and policy change is recorded with the actor; production income is merged into hourly lines.

## Governments, economies, policies
| Government | Leader chosen by | Character |
|---|---|---|
| Chiefdom | appointment | citizens may buy and build together |
| Elder Council | election | only elders spend; contributions valued +15%; costs -5% |
| Monarchy (Village) | appointment | subjects build but cannot spend; costs -8%, wider borders, +5% treasury income |
| Republic (Medieval) | election | senators control funds; citizens place what the senate buys; +5% points/housing |
| Theocracy (Village) | appointment | +8% points, +2 faith buildings, costs +5% |

| Economy | Character |
|---|---|
| Barter | no money: money income becomes points; contributions +20% |
| Commons | +10% points, -40% money, +25% contributions, no withdrawals |
| Market (Village) | +20% money, conversion to points, withdrawals up to 400/day |
| Mercantile (Medieval) | +30% money, costs +10%, withdrawals 1000/day |
| Planned (Medieval) | +20% points, -30% money, costs -4%, favourable conversion |

13 policies (government and economy kinds, slot-limited, some exclusive) add modifiers. Modifier keys: `building_cost_mult`, `points_output_mult`, `money_output_mult`,
`production_speed_mult`, `contribution_rate_mult`, `housing_mult`, `claim_radius_add`, `withdraw_limit_add`, `tag_limit_add.<tag>`.
**Technical owner (disband, transfer) and political leader are separate seats.** Owner-only permissions are never part of a role's `ALL`.

## Permissions (action based)
`BUILD CONTAINERS INTERACT` - `USE_SHOP PURCHASE_BUILDINGS PLACE_BUILDINGS UPGRADE_BUILDINGS REMOVE_BUILDINGS MANAGE_BUILDINGS ADVANCE_AGE` -
`CONTRIBUTE SPEND_POINTS SPEND_TREASURY WITHDRAW_TREASURY VIEW_FINANCES COLLECT_TAXES` - `INVITE KICK MANAGE_RANKS APPOINT_OFFICIALS VOTE` -
`CHANGE_SETTINGS CHANGE_GOVERNMENT CHANGE_ECONOMY MANAGE_POLICIES` - owner-only: `DISBAND TRANSFER_OWNERSHIP`.
Roles come from the government; civilizations can add custom roles (`/ages rank`, if the government allows). You can only manage roles and members below your own weight and never grant what you lack.

## Limits
Per building (`limits.max_per_town` / `max_per_player`; `per_town` / `per_player` also accepted), per age (`building_limits`), and **shared tag pools**:
buildings declare `tags: {housing: 2}`; caps per player and per civilization live in `settings.yml` (`limits.tags`) and each age's `tag_limits`. The strictest cap wins,
so a big civilization cannot bypass limits by having every member place the maximum.

## Quality-of-life features
* **Disband**: `/ages disband` (confirm) or the GUI; owner-only by default. Removes records, ledger and spawned villagers; blocks stay.
* **Relocate**: building menu "Remove / relocate" or just break the core. The core item keeps its **level and identity** (so its villagers re-attach) and a chest/barrel
  core's contents are handed back. The core of your current age cannot be removed.
* **Respawn**: shrines, chapels, graveyards, burial mounds, keeps and monasteries are spawn points. A bed/anchor keeps priority unless
  `respawn.civilization_overrides_bed: true`.
* **Villagers**: persistent registry in the database; slots are counted from it (not from what is loaded), so no duplicates after unloads/restarts; a death frees exactly one slot and the
  timer refills it; plugin villagers cannot be traded with; orphans from older versions are adopted or removed.
* **`town.yml` is now `settings.yml`** (the spec said `.txt`; it is YAML, so `.yml`). Migrated automatically, your values carried over.
* **New content appears after a restart**: new files in `ages/ buildings/ governments/ economies/ policies/` are picked up, new categories are created automatically,
  and new shipped defaults are added to existing installs without overwriting your edits (a file you deleted is remembered, not restored).

## Migrating from 0.1
On first start the plugin backs up your old default files to `plugins/Ages/backup/`, replaces them, removes obsolete ones, renames `town.yml`, and keeps your settings values.
Saved buildings under old ids keep working through `aliases` (e.g. `hut` -> `tribal_hut`, `wheat_farm` -> `farm`, `royal_court` -> `city_hall`); `late_medieval` -> `industrial`.
Old civilizations get an owner (their highest rank), the default government and economy. Building files with `cost: {money: N}` still load (read as RP, see `settings.yml`).
Removed: war/diplomacy permissions and buildings (embassy, cannon, powder mill). Your own custom files are never touched.

## Commands
`/ages` (GUI) - `info buildings logistics treasury` - `invite accept leave kick` - `contribute hand|all|money <n>`, `withdraw <n>`, `convert <n>` -
`government|economy [list|set <id>]`, `policy [list|<id>]` - `vote <player>`, `leader <player>`, `owner transfer <player>` - `rank list|create|delete|perm|set` -
`disband` - admin (`ages.admin`): `core`, `give <building>`, `reload`. `ages.bypass` ignores protection.

## Tools (`tools/`)
`check_config.py` (YAML structure and references), `balance.py` (economy audit: recipe ratios, RP payback and pacing, solo progression, upgrade costs, modifier stacking, recipe loops;
currently **0 warnings**), `javacheck.sh` (offline javac pass), `generate_content.py` (authored the shipped YAML; the YAML is the source of truth and safe to edit by hand).
Solo progression with no contributions, per the audit: Village in ~3h, Medieval in ~11h, Industrial in ~29h of play (faster with contributions and extra producers).

## Not included
War, diplomacy and alliances (separate specification). Rail logistics, the map hook, visual minecarts, and protection of item frames/pistons are unchanged or still open.
