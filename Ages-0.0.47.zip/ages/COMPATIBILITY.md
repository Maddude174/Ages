# Ages — version compatibility notes

## What we do
- **Bukkit/Paper API only** — no NMS, no CraftBukkit imports, no reflection into server internals.
- **Config-driven materials & entities** — building cores, costs, recipes use string ids resolved at load.
- **Soft resolution** via `Materials` / `Entities` with historical aliases (e.g. GRASS → SHORT_GRASS).
- **PersistentDataContainer** for core items — not display names (survives locale/rename of item names).
- **Adventure** components for chat/GUI text.
- **api-version: 1.21** in plugin.yml marks the *minimum* API the plugin was built against.

## What you do when Minecraft updates
1. Set `paperVersion` in `gradle.properties` to the new Paper API and recompile.
2. Boot once; read the console for `unknown material` / `unknown entity` warnings.
3. Fix those strings in YAML, or add aliases in `Materials.java` / `Entities.java`.
4. Test founding, production, cannons, WorldGuard, dynmap, PAPI.

## What still can break
- Mojang **renames** materials or entity enum constants not covered by aliases.
- **Removed** APIs if Paper drops something we call (rare if we stay on documented API).
- Soft-depends (Vault, WorldGuard, dynmap, PAPI) changing their APIs — those hooks need separate updates.
- Java toolchain: currently **Java 21** (matches modern Paper).

## Not guaranteed
- Running a jar built for 1.21 on a much older server.
- Data packs or custom item plugins that change vanilla material behaviour.
