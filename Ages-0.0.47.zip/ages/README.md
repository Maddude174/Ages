# Ages

Civilization building and era progression for Paper 1.21.x (Java 21).

Build a settlement, place specialized buildings, run production chains, adopt a government and economy, and advance through ages. Current release is **0.0.3A** (early alpha).

## Features

- **Ages:** Neolithic → Tribal → Village → Medieval → Industrial (config-driven)
- **Buildings:** category folders, upgrades, progressive recipes, limits/tags, optional conflicts
- **Governments & economies:** roles (inheritance/bundles), policies, elections for elected govs
- **Diplomacy:** alliances, hostile, truce, war goals, tributary/settlement, revolt vs revolution
- **Siege:** cannons (gunpowder + cobble ammo), building disable/destroy, war score
- **Integrations (soft):** Vault, WorldGuard, dynmap, PlaceholderAPI

## Install

1. Drop the jar in `plugins/`
2. Start once; review generated config under `plugins/Ages/`
3. Dependencies: **Vault** + an economy plugin + a permissions plugin (e.g. LuckPerms)
4. Optional: WorldGuard, dynmap, PlaceholderAPI

On default-file upgrades, DefaultsSync may back up old YAMLs under `plugins/Ages/backup/`.

## Commands (players)

| Command | Purpose |
|---------|---------|
| `/ages menu` | Civilization GUI |
| `/ages info` | Civ summary |
| `/ages invite` / `accept` / `leave` / `kick` | Membership |
| `/ages rank …` | Roles |
| `/ages contribute` / `withdraw` / `treasury` | Economy |
| `/ages government` / `economy` / `policy` | Civic systems |
| `/ages vote` / `leader` / `owner` | Leadership |
| `/ages diplomacy` | Relations list / GUI entry |
| `/ages ally` / `breakally` / `hostile` / `truce` | Peace-time diplomacy |
| `/ages war` / `tributary` / `release` | War & tributary |
| `/ages revolt` | Break free if tributary/settlement |
| `/ages civilwar` / `revolution` | Internal civil war |
| `/ages rebel` | Join active opposition |
| `/ages accept_diplo <civ>` | Accept ally/truce proposal |
| `/ages core` / `fireplace` / `give` | Core items (perms) |

## Admin (`ages.admin`)

`/ages admin list|info|points|money|setpoints|setmoney|gov|econ|age|leader|owner|disband|repair|tp|election|relation|warscore|endwar|tribute|warlog`

Also: `/ages reload`

## Permissions

| Permission | Default | Meaning |
|------------|---------|---------|
| `ages.admin` | op | Admin tools, give cores, reload |
| `ages.bypass` | op | Ignore town protection |
| `ages.creative.bypass` | op | Buy/place cores in creative when denied |

## Config tips

- Buildings: `plugins/Ages/buildings/<category>/`
- Governments / economies / policies / ages: matching folders
- `settings.yml`: shop, protection (`tnt`, `tnt_requires_online`), diplomacy, governance elections, `buildings.conflict_scope`
- Optional `materials-aliases.yml` for renamed materials (see `COMPATIBILITY.md`)
- Town dumps: `plugins/Ages/Towns/`

## Building

```text
paperVersion=1.21.x-R0.1-SNAPSHOT   # gradle.properties
./gradlew build
```

## Alpha notice

Systems and YAML formats may change. Report bugs with MC version, server software, relevant config, and stack traces.

## Docs

- **CHANGELOG.md** — version history  
- **COMPATIBILITY.md** — cross-version guidance  


## Metrics (bStats)

Ages submits anonymous usage charts (civ counts, age/gov/econ mix, soft-depends, feature flags). No player names or UUIDs.

- Toggle: `settings.yml` → `metrics.enabled`
- Global opt-out: `plugins/bStats/config.yml`
- Register the plugin at https://bstats.org and set `MetricsHook.PLUGIN_ID` if you fork
