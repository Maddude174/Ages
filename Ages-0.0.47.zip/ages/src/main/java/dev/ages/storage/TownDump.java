package dev.ages.storage;

import dev.ages.AgesPlugin;
import dev.ages.config.BuildingDef;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Rank;
import dev.ages.model.Town;
import dev.ages.model.Tx;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

/**
 * Writes one human-readable YAML per civilization under plugins/Ages/Towns/
 * so server admins can inspect members, diplomacy-ish state, buildings and balances
 * without opening the SQLite database.
 */
public final class TownDump {
    private final AgesPlugin plugin;
    private final File dir;

    public TownDump(AgesPlugin plugin) {
        this.plugin = plugin;
        this.dir = new File(plugin.getDataFolder(), "Towns");
    }

    public File dir() { return dir; }

    public void ensureDir() {
        if (!dir.exists() && !dir.mkdirs()) {
            plugin.getLogger().warning("Could not create Towns folder at " + dir.getAbsolutePath());
        }
    }

    /** Safe filename from town name + short id. */
    private File fileFor(Town t) {
        String safe = t.name == null ? "town" : t.name.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (safe.isBlank()) safe = "town";
        String shortId = t.id.toString().substring(0, 8);
        return new File(dir, safe + "_" + shortId + ".yml");
    }

    public void dump(Town t) {
        if (t == null) return;
        ensureDir();
        YamlConfiguration y = new YamlConfiguration();
        y.set("id", t.id.toString());
        y.set("name", t.name);
        y.set("age", t.ageId);
        y.set("created", t.created);
        y.set("owner", t.owner == null ? null : t.owner.toString());
        y.set("leader", t.leader == null ? null : t.leader.toString());
        y.set("government", t.govId);
        y.set("economy", t.econId);
        y.set("points", t.points);
        y.set("treasury", t.money);
        y.set("villagers", t.villagers);
        y.set("policies", new ArrayList<>(t.policies));

        if (t.center != null) {
            y.set("center.world", t.center.world());
            y.set("center.x", t.center.x());
            y.set("center.y", t.center.y());
            y.set("center.z", t.center.z());
        }
        if (t.core != null) {
            y.set("core.world", t.core.world());
            y.set("core.x", t.core.x());
            y.set("core.y", t.core.y());
            y.set("core.z", t.core.z());
        }

        // Members
        List<Map<String, Object>> members = new ArrayList<>();
        for (Map.Entry<UUID, String> e : t.members.entrySet()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("uuid", e.getKey().toString());
            String name = Bukkit.getOfflinePlayer(e.getKey()).getName();
            m.put("name", name != null ? name : "?");
            m.put("rank", e.getValue());
            double[] c = t.contributions.get(e.getKey());
            if (c != null) {
                m.put("contributed_points", c.length > 0 ? c[0] : 0);
                m.put("contributed_money", c.length > 1 ? c[1] : 0);
            }
            members.add(m);
        }
        y.set("members", members);

        // Ranks
        List<Map<String, Object>> ranks = new ArrayList<>();
        for (Rank r : t.ranks.values()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", r.name);
            m.put("title", r.title);
            m.put("weight", r.weight);
            List<String> perms = new ArrayList<>();
            r.perms.forEach(p -> perms.add(p.name()));
            m.put("permissions", perms);
            ranks.add(m);
        }
        y.set("ranks", ranks);

        // Buildings
        List<Map<String, Object>> buildings = new ArrayList<>();
        for (PlacedBuilding b : t.buildings) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", b.id.toString());
            m.put("type", b.defId);
            m.put("level", b.level);
            m.put("damaged", b.damaged);
            m.put("owner", b.owner == null ? null : b.owner.toString());
            m.put("recipe", b.recipe);
            if (b.core != null) {
                m.put("core", b.core.world() + " " + b.core.x() + "," + b.core.y() + "," + b.core.z());
            }
            BuildingDef def = plugin.reg().building(b.defId);
            if (def != null) m.put("display", def.name);
            buildings.add(m);
        }
        y.set("buildings", buildings);

        // Recent ledger (newest first, capped)
        List<Map<String, Object>> ledger = new ArrayList<>();
        int n = 0;
        for (Tx tx : t.ledger) {
            if (n++ >= 25) break;
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("ts", tx.ts);
            m.put("type", tx.type);
            m.put("currency", tx.currency);
            m.put("amount", tx.amount);
            m.put("balance", tx.balance);
            m.put("note", tx.note);
            if (tx.actor != null) m.put("actor", tx.actor.toString());
            ledger.add(m);
        }
        y.set("recent_ledger", ledger);

        y.options().header("""
            Auto-generated by Ages for server admins.
            Do not edit while the server is running — this file is overwritten on town saves.
            Source of truth is ages.db.
            """);

        File out = fileFor(t);
        try {
            y.save(out);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Failed to write town dump " + out.getName(), e);
        }
    }

    public void dumpAll() {
        ensureDir();
        for (Town t : plugin.towns().all()) dump(t);
    }

    public void delete(Town t) {
        File f = fileFor(t);
        if (f.exists() && !f.delete()) {
            plugin.getLogger().warning("Could not delete town dump " + f.getName());
        }
    }
}
