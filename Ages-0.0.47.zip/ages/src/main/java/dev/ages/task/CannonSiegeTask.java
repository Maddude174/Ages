package dev.ages.task;

import dev.ages.AgesPlugin;
import dev.ages.config.BuildingDef;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Relation;
import dev.ages.model.Town;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Container;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Slow siege artillery. Each undamaged cannon on a long cooldown lobs propelled primed TNT at an enemy (ammo: 3 gunpowder + 1 cobblestone in the core)
 * building during HOSTILE or WAR. Hits feed war score and siege pressure (devastation).
 */
public final class CannonSiegeTask implements Runnable {
    public static final String META_ATTACKER = "ages_cannon_attacker";
    public static final String META_DEFENDER = "ages_cannon_defender";
    public static final String META_CANNON = "ages_cannon_id";

    /** Base seconds between shots at level 1 (upgrades reduce slightly). */
    private static final int BASE_COOLDOWN_SEC = 180; // 3 minutes
    private static final int MIN_COOLDOWN_SEC = 90;

    private final AgesPlugin plugin;

    public CannonSiegeTask(AgesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        if (!plugin.reg().settings.diplomacyEnabled) return;
        long now = System.currentTimeMillis();
        for (Town t : plugin.towns().all()) {
            for (PlacedBuilding pb : t.buildings) {
                if (!"cannon".equals(pb.defId) || pb.damaged) continue;
                BuildingDef def = plugin.reg().effective(pb);
                if (def == null) continue;
                // Reuse nextRun as siege ready timestamp
                if (pb.nextRun > now) continue;

                int range = rangeFor(pb.level);
                int height = heightFor(pb.level);
                World w = Bukkit.getWorld(pb.core.world());
                if (w == null || !w.isChunkLoaded(pb.core.x() >> 4, pb.core.z() >> 4)) continue;

                Target target = findTarget(t, pb, range, height);
                if (target == null) {
                    // Still "ready" but nothing to shoot; short retry
                    pb.nextRun = now + 30_000L;
                    plugin.towns().markDirty(pb);
                    continue;
                }

                if (!consumeAmmo(w, pb)) {
                    pb.nextRun = now + 60_000L;
                    plugin.towns().markDirty(pb);
                    continue;
                }
                Location from = new Location(w, pb.core.x() + 0.5, pb.core.y() + 1.5, pb.core.z() + 0.5);
                Location to = new Location(w, target.building.core.x() + 0.5,
                        target.building.core.y() + 1.0, target.building.core.z() + 0.5);
                fireTnt(from, to, t, target.town, pb);
                int cd = Math.max(MIN_COOLDOWN_SEC, BASE_COOLDOWN_SEC - (pb.level - 1) * 30);
                pb.nextRun = now + cd * 1000L;
                plugin.towns().markDirty(pb);

                // Siege pressure: slow economic bleed on the defender
                applySiegePressure(t, target.town, pb.level);
            }
        }
    }

    private void fireTnt(Location from, Location to, Town attacker, Town defender, PlacedBuilding cannon) {
        World w = from.getWorld();
        if (w == null) return;
        TNTPrimed tnt = (TNTPrimed) w.spawnEntity(from, EntityType.TNT);
        tnt.setFuseTicks(fuseTicks(from, to));
        tnt.setYield(3.5f + cannon.level * 0.5f); // harder than vanilla 4.0 when upgraded
        tnt.setIsIncendiary(false);
        tnt.setMetadata(META_ATTACKER, new FixedMetadataValue(plugin, attacker.id.toString()));
        tnt.setMetadata(META_DEFENDER, new FixedMetadataValue(plugin, defender.id.toString()));
        tnt.setMetadata(META_CANNON, new FixedMetadataValue(plugin, cannon.id.toString()));
        // Ballistic arc toward target, with slight random miss so not every shot is perfect
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        double miss = 1.5 + rnd.nextDouble() * 2.5; // 1.5–4 blocks lateral scatter at aim point
        double angle = rnd.nextDouble() * Math.PI * 2;
        Location aim = to.clone().add(Math.cos(angle) * miss, (rnd.nextDouble() - 0.5) * 1.5, Math.sin(angle) * miss);
        Vector delta = aim.toVector().subtract(from.toVector());
        double dist = Math.max(1.0, delta.length());
        double speed = Math.min(2.2, 0.9 + dist / 40.0);
        Vector vel = delta.clone().normalize().multiply(speed);
        vel.setY(vel.getY() + Math.min(1.2, dist / 50.0) + 0.35);
        // Small velocity noise
        vel.add(new Vector((rnd.nextDouble() - 0.5) * 0.15, (rnd.nextDouble() - 0.5) * 0.08, (rnd.nextDouble() - 0.5) * 0.15));
        tnt.setVelocity(vel);

        for (var u : attacker.members.keySet()) {
            var p = Bukkit.getPlayer(u);
            if (p != null) p.sendActionBar(Text.c("&8Cannon fired on &f" + defender.name));
        }
    }

    private static int fuseTicks(Location from, Location to) {
        double dist = from.distance(to);
        // Land roughly when the arc arrives (20 ticks = 1s)
        return Math.max(30, Math.min(80, (int) (dist * 1.2)));
    }

    private void applySiegePressure(Town attacker, Town defender, int level) {
        // Slow devastation: drain stores and raise war score without instant wipe
        double drain = 2.0 + level * 1.5;
        if (defender.points > 0) {
            double take = Math.min(defender.points, drain);
            defender.points -= take;
            attacker.points += take * 0.25;
            plugin.finance().record(defender, null, "SIEGE", "POINTS", -take, "Siege pressure from " + attacker.name);
            plugin.towns().markTownDirty(defender);
            plugin.towns().markTownDirty(attacker);
        }
        plugin.diplomacy().addWarScore(attacker, defender, 8 + level * 2);
        Relation r = plugin.diplomacy().get(attacker, defender);
        if (r != null && r.state == Relation.State.WAR && r.warScore > 0 && r.warScore % 100 < 15) {
            // Occasional structural shock: disable an extra random building
            List<PlacedBuilding> candidates = new ArrayList<>();
            for (PlacedBuilding b : defender.buildings) if (!b.damaged && !"cannon".equals(b.defId)) candidates.add(b);
            if (!candidates.isEmpty()) {
                PlacedBuilding victim = candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
                plugin.buildings().setDisabled(victim, true);
                plugin.diplomacy().addWarScore(attacker, defender, 20);
            }
        }
    }

    private record Target(Town town, PlacedBuilding building) {}

    /**
     * Prefer the closest operational (not disabled) enemy core in range.
     * Disabled buildings remain valid targets but rank lower than any operational one at similar range.
     * Among equal preference, closer wins.
     */
    private Target findTarget(Town attacker, PlacedBuilding cannon, int range, int height) {
        PlacedBuilding best = null;
        Town bestTown = null;
        double bestScore = Double.MAX_VALUE;
        for (Town enemy : plugin.towns().all()) {
            if (enemy.id.equals(attacker.id)) continue;
            if (!plugin.diplomacy().hostileOrWar(attacker, enemy)) continue;
            for (PlacedBuilding eb : enemy.buildings) {
                if (!eb.core.world().equals(cannon.core.world())) continue;
                double dx = eb.core.x() - cannon.core.x();
                double dy = eb.core.y() - cannon.core.y();
                double dz = eb.core.z() - cannon.core.z();
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > range || Math.abs(dy) > height) continue;
                // Operational preferred; disabled allowed but scored worse
                double score = dist + (eb.damaged ? range + 16.0 : 0.0);
                if (score < bestScore) {
                    bestScore = score;
                    best = eb;
                    bestTown = enemy;
                }
            }
        }
        return best == null ? null : new Target(bestTown, best);
    }

    /** 3 gunpowder + 1 cobblestone from the core inventory (dispenser). */
    private boolean consumeAmmo(World w, PlacedBuilding cannon) {
        var block = w.getBlockAt(cannon.core.x(), cannon.core.y(), cannon.core.z());
        if (!(block.getState() instanceof Container c)) return false;
        Inventory inv = c.getInventory();
        if (!inv.contains(Material.GUNPOWDER, 3) || !inv.contains(Material.COBBLESTONE, 1)) return false;
        inv.removeItem(new ItemStack(Material.GUNPOWDER, 3));
        inv.removeItem(new ItemStack(Material.COBBLESTONE, 1));
        if (block.getState() instanceof Container c2) c2.update();
        return true;
    }

    private static int rangeFor(int level) {
        return switch (Math.max(1, level)) {
            case 1 -> 32;
            case 2 -> 48;
            default -> 64;
        };
    }

    private static int heightFor(int level) {
        return switch (Math.max(1, level)) {
            case 1 -> 8;
            case 2 -> 12;
            default -> 16;
        };
    }
}
