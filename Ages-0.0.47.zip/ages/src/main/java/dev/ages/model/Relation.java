package dev.ages.model;

import java.util.UUID;

/** Exactly one state between two civilizations (unordered pair stored with sorted UUIDs). */
public final class Relation {
    public enum State {
        NEUTRAL,
        HOSTILE,
        ALLIED,
        ALLIED_DEFENSIVE,
        WAR,
        TRUCE,
        TRIBUTARY,
        SETTLEMENT
    }

    public final UUID a; // lower UUID
    public final UUID b; // higher UUID
    public State state = State.NEUTRAL;
    /** For TRIBUTARY / SETTLEMENT: the overlord civilization. */
    public UUID overlord;
    /** For WAR: aggressor. */
    public UUID aggressor;
    /** War goal id: none, tributary, conquest, total_war, political, raid, revolt, revolution */
    public String warGoal = "none";
    public int warScore; // 0..1000
    public long since = System.currentTimeMillis();
    public long truceUntil; // epoch ms when TRUCE ends
    /** Alliance id shared by multi-civ allies (null if bilateral only). */
    public String allianceId;
    /** Tribute rate 0..1 of tax/production skim, set by overlord government. */
    public double tributeRate;

    public Relation(UUID x, UUID y) {
        if (x.compareTo(y) <= 0) { a = x; b = y; }
        else { a = y; b = x; }
    }

    public UUID other(UUID self) {
        return self.equals(a) ? b : a;
    }

    public boolean involves(UUID id) {
        return a.equals(id) || b.equals(id);
    }
}
