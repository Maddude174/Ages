package dev.ages.model;

import java.util.EnumSet;
import java.util.Set;

/**
 * A civilization role. Weights decide who outranks whom.
 * Roles may inherit permissions from a parent role, then grant/deny extras.
 */
public final class Rank {
    public final String name;
    /** Display title (e.g. "Chief"). Defaults to the name. */
    public String title;
    /** Higher weight outranks lower. You can only manage ranks and members below your own weight. */
    public int weight;
    public final Set<Perm> perms = EnumSet.noneOf(Perm.class);
    /** Parent role id for inheritance (resolved at government load). */
    public String inherits;
    /** Max members with this rank at once; -1 = unlimited. */
    public int maxHolders = -1;
    /** May appoint/demote ranks strictly below this weight. */
    public boolean canAppoint = false;
    /** Soft tags for UI / future rules: military, diplomatic, economic, civic. */
    public final Set<String> authority = new java.util.LinkedHashSet<>();

    public Rank(String name, int weight) {
        this.name = name;
        this.title = name;
        this.weight = weight;
    }

    public Rank copy() {
        Rank r = new Rank(name, weight);
        r.title = title;
        r.perms.addAll(perms);
        r.inherits = inherits;
        r.maxHolders = maxHolders;
        r.canAppoint = canAppoint;
        r.authority.addAll(authority);
        return r;
    }

    public boolean has(Perm p) {
        return perms.contains(p);
    }
}
