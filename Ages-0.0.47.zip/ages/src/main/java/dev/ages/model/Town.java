package dev.ages.model;

import java.util.*;

/** A civilization. Kept as "Town" internally for compatibility with stored data. */
public final class Town {
    public final UUID id;
    public String name;
    public String ageId;
    /** Fixed anchor of the territory (where the first core was placed). */
    public final BlockPos center;
    /** Core block of the CURRENT age: the shop and the respawn anchor. Older cores are retired. */
    public BlockPos core;
    public final long created;

    /** Technical owner: can disband and transfer ownership. NOT necessarily the political leader. */
    public UUID owner;
    /** Political leader: holds the government's leader role. Chosen according to the government type. */
    public UUID leader;
    public String govId;
    public String econId;
    /** Shared resource points: the plugin-specific currency for buildings and ages. */
    public double points;
    /** Shared treasury money (separate from players' personal Vault funds). */
    public double money;
    public long govChangedAt, econChangedAt;
    /** Epoch ms when the current voting window closes (0 = no open election). */
    public long electionEndsAt;
    /** Epoch ms when the next election opens (elected governments only). */
    public long nextElectionAt;
    /** If non-null, this town is a civil-war opposition linked to the parent civilization (no founding core). */
    public UUID shadowOf;


    public final Set<String> policies = new LinkedHashSet<>();
    public final Map<UUID, UUID> votes = new HashMap<>();                 // voter -> candidate
    public final Map<UUID, double[]> contributions = new HashMap<>();     // player -> {points, money}
    public final Deque<Tx> ledger = new ArrayDeque<>();                   // newest first

    public final Map<UUID, String> members = new LinkedHashMap<>();
    public final Map<String, Rank> ranks = new LinkedHashMap<>();
    public final List<PlacedBuilding> buildings = new ArrayList<>();

    // runtime only
    public final Set<UUID> invites = new HashSet<>();
    public int villagers;

    public Town(UUID id, String name, String ageId, BlockPos center, long created) {
        this.id = id;
        this.name = name;
        this.ageId = ageId;
        this.center = center;
        this.core = center;
        this.created = created;
    }

    public boolean isOwner(UUID p) { return p != null && p.equals(owner); }

    public Rank rankOf(UUID player) {
        String r = members.get(player);
        return r == null ? null : ranks.get(r);
    }

    /** Owner-only actions are always allowed for the owner; everything else comes from the player's role. */
    public boolean can(UUID player, Perm perm) {
        if (perm.ownerOnly && isOwner(player)) return true;
        Rank r = rankOf(player);
        return r != null && r.perms.contains(perm);
    }

    public int weightOf(UUID player) {
        Rank r = rankOf(player);
        return r == null ? -1 : r.weight;
    }

    public int population(boolean players, boolean villagerCount) {
        return (players ? members.size() : 0) + (villagerCount ? villagers : 0);
    }

    /**
     * Buildings of a type at or above a level.
     * @param undamagedOnly if true, Disabled buildings are ignored (limits/shop); if false, they still count (age progress).
     * @param canonical maps ids/aliases to the primary building id; null = exact match only
     */
    public int count(String defId, int minLevel, boolean undamagedOnly, java.util.function.Function<String, String> canonical) {
        String want = canonical != null ? canonical.apply(defId) : defId;
        if (want == null) want = defId;
        int n = 0;
        for (PlacedBuilding b : buildings) {
            if (b.level < minLevel) continue;
            if (undamagedOnly && b.damaged) continue;
            String have = canonical != null ? canonical.apply(b.defId) : b.defId;
            if (have == null) have = b.defId;
            if (want.equalsIgnoreCase(have) || want.equalsIgnoreCase(b.defId)) n++;
        }
        return n;
    }

    /** Working (undamaged) buildings — used for limits and most gameplay checks. */
    public int count(String defId, int minLevel) {
        return count(defId, minLevel, true, null);
    }

    public int count(String defId) { return count(defId, 1); }

    /** All buildings of a type, including damaged. Used for limits. */
    public int countAll(String defId) {
        int n = 0;
        for (PlacedBuilding b : buildings) if (b.defId.equals(defId)) n++;
        return n;
    }

    public int countOwned(UUID owner, String defId) {
        int n = 0;
        for (PlacedBuilding b : buildings) if (b.defId.equals(defId) && b.owner.equals(owner)) n++;
        return n;
    }
}
