package dev.ages.listener;

import dev.ages.AgesPlugin;
import dev.ages.config.Settings;
import dev.ages.item.Items;
import dev.ages.model.*;
import dev.ages.util.Containers;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.minecart.ExplosiveMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Territory protection (role based), mob spawn/explosion protection, respawn points, rail-network and
 * building-integrity marking.
 */
public final class TownListener implements Listener {
    private static final Set<CreatureSpawnEvent.SpawnReason> ALLOWED_HOSTILE = EnumSet.of(
            CreatureSpawnEvent.SpawnReason.COMMAND, CreatureSpawnEvent.SpawnReason.CUSTOM,
            CreatureSpawnEvent.SpawnReason.SPAWNER_EGG, CreatureSpawnEvent.SpawnReason.DISPENSE_EGG,
            CreatureSpawnEvent.SpawnReason.EGG, CreatureSpawnEvent.SpawnReason.SPAWNER,
            CreatureSpawnEvent.SpawnReason.SLIME_SPLIT, CreatureSpawnEvent.SpawnReason.CURED,
            CreatureSpawnEvent.SpawnReason.INFECTION, CreatureSpawnEvent.SpawnReason.BUILD_WITHER,
            CreatureSpawnEvent.SpawnReason.BUILD_IRONGOLEM, CreatureSpawnEvent.SpawnReason.BUILD_SNOWMAN);

    private final AgesPlugin plugin;

    public TownListener(AgesPlugin plugin) { this.plugin = plugin; }

    private boolean denied(Player p, Block b, Perm perm) {
        Town t = plugin.towns().at(b);
        if (t == null || p.hasPermission("ages.bypass") || t.can(p.getUniqueId(), perm)) return false;
        p.sendActionBar(Text.c("&cThis land belongs to " + t.name + "."));
        return true;
    }

    private boolean ownerOrManager(Player p, PlacedBuilding pb) {
        if (p.hasPermission("ages.bypass") || pb.owner.equals(p.getUniqueId())) return true;
        Town t = plugin.towns().byId(pb.townId);
        return t != null && t.can(p.getUniqueId(), Perm.MANAGE_BUILDINGS);
    }

    // ------------------------------------------------------------------ building / breaking

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (denied(e.getPlayer(), e.getBlock(), Perm.BUILD)) { e.setCancelled(true); return; }
        PlacedBuilding pb = plugin.towns().containerOf(BlockPos.of(e.getBlock()));
        // a chest/barrel CORE is handled by CoreListener (removal rules); other building containers belong to the building's owner
        if (pb != null && !pb.core.equals(BlockPos.of(e.getBlock())) && !ownerOrManager(e.getPlayer(), pb)) {
            e.setCancelled(true);
            Text.msg(e.getPlayer(), "&cThat container belongs to someone else's building.");
        }
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (Items.coreId(e.getItemInHand()) != null) return; // CoreListener decides
        if (denied(e.getPlayer(), e.getBlock(), Perm.BUILD)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (denied(e.getPlayer(), e.getBlock(), Perm.BUILD)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (denied(e.getPlayer(), e.getBlock(), Perm.BUILD)) e.setCancelled(true);
    }

    private static boolean isUsable(Material m) {
        return Tag.DOORS.isTagged(m) || Tag.TRAPDOORS.isTagged(m) || Tag.BUTTONS.isTagged(m)
                || Tag.FENCE_GATES.isTagged(m) || m == Material.LEVER;
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        Block b = e.getClickedBlock();
        if (b == null || e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        Material m = b.getType();
        Perm need = Containers.isContainer(m) ? Perm.CONTAINERS : isUsable(m) ? Perm.INTERACT : null;
        if (need == null) return;
        if (denied(p, b, need)) { e.setCancelled(true); return; }
        if (need == Perm.CONTAINERS) {
            PlacedBuilding pb = plugin.towns().containerOf(BlockPos.of(b));
            if (pb != null && !ownerOrManager(p, pb)) {
                e.setCancelled(true);
                p.sendActionBar(Text.c("&cThis container belongs to another member's building."));
            }
        }
    }

    // ------------------------------------------------------------------ mobs and explosions

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (!plugin.reg().settings.blockMobSpawns || !(e.getEntity() instanceof Enemy)) return;
        if (ALLOWED_HOSTILE.contains(e.getSpawnReason())) return;
        if (plugin.towns().at(e.getLocation()) != null) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        Settings s = plugin.reg().settings;
        Entity src = e.getEntity();
        boolean cannonShot = src instanceof TNTPrimed && src.hasMetadata(dev.ages.task.CannonSiegeTask.META_ATTACKER);
        boolean tnt = src instanceof TNTPrimed || src instanceof ExplosiveMinecart;
        Iterator<Block> it = e.blockList().iterator();
        java.util.Set<java.util.UUID> hitBuildings = new java.util.HashSet<>();
        while (it.hasNext()) {
            Block b = it.next();
            BlockPos pos = BlockPos.of(b);
            Town land = plugin.towns().at(pos);
            if (land == null) continue;
            // Founding/age cores always protected from blast removal list
            if (plugin.towns().isTownCore(pos)) { it.remove(); continue; }
            boolean inConflict = landInConflict(land);
            boolean protect;
            if (cannonShot) {
                protect = false; // siege shells always interact with buildings
            } else if (tnt) {
                // Peacetime: respect tnt setting. Wartime (Hostile/War): TNT can damage this civ's land.
                protect = s.tntAllowed() ? false : !inConflict;
            } else {
                protect = s.blockMobExplosions;
            }
            if (!protect && tnt && s.tntRequiresOnline && !hasOnlineMember(land)) {
                protect = true; // safety: no online members → no TNT damage
            }
            if (protect) { it.remove(); continue; }
            PlacedBuilding core = plugin.towns().core(pos);
            if (core != null) {
                plugin.buildings().coreDestroyed(core);
                continue;
            }
            for (PlacedBuilding pb : plugin.towns().buildingsAt(pos)) {
                if (!hitBuildings.add(pb.id)) continue;
                plugin.buildings().structuralHit(pb, b);
            }
        }
        if (cannonShot) {
            try {
                java.util.UUID atk = java.util.UUID.fromString(src.getMetadata(dev.ages.task.CannonSiegeTask.META_ATTACKER).get(0).asString());
                java.util.UUID def = java.util.UUID.fromString(src.getMetadata(dev.ages.task.CannonSiegeTask.META_DEFENDER).get(0).asString());
                Town attacker = plugin.towns().byId(atk);
                Town defender = plugin.towns().byId(def);
                if (attacker != null && defender != null) {
                    plugin.diplomacy().addWarScore(attacker, defender, 25);
                }
            } catch (Exception ignored) {}
        }
    }

    // ------------------------------------------------------------------ integrity marking

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void dirtyBreak(BlockBreakEvent e) { plugin.buildings().markDirty(e.getBlock()); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void dirtyPlace(BlockPlaceEvent e) { plugin.buildings().markDirty(e.getBlock()); }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void dirtyBurn(BlockBurnEvent e) { plugin.buildings().markDirty(e.getBlock()); }

    // ------------------------------------------------------------------ rail networks

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void railPlaced(BlockPlaceEvent e) {
        if (Tag.RAILS.isTagged(e.getBlock().getType())) plugin.logistics().railChanged(e.getBlock());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void railBroken(BlockBreakEvent e) {
        if (Tag.RAILS.isTagged(e.getBlock().getType())) plugin.logistics().railChanged(e.getBlock());
    }

    // ------------------------------------------------------------------ respawn

    /**
     * Respawn at the nearest working civilization spawn point (burial mound, shrine, chapel, graveyard, keep...).
     * A bed or respawn anchor keeps priority unless settings.yml has respawn.civilization_overrides_bed: true.
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent e) {
        Settings s = plugin.reg().settings;
        if (!s.respawnEnabled) return;
        if ((e.isBedSpawn() || e.isAnchorSpawn()) && !s.civOverridesBed) return;
        Player p = e.getPlayer();
        Town t = plugin.towns().of(p.getUniqueId());
        if (t == null) return;
        Location from = p.getLocation().getWorld() != null ? p.getLocation() : e.getRespawnLocation();
        PlacedBuilding pb = plugin.towns().respawnPoint(t, from);
        if (pb == null) return;
        Location l = plugin.towns().safeSpawn(pb);
        if (l != null) e.setRespawnLocation(l);
    }

    
    private boolean hasOnlineMember(Town land) {
        if (land == null) return false;
        for (java.util.UUID u : land.members.keySet()) {
            if (Bukkit.getPlayer(u) != null) return true;
        }
        return false;
    }

    private boolean landInConflict(Town land) {
        if (land == null || plugin.diplomacy() == null) return false;
        for (var r : plugin.diplomacy().of(land)) {
            if (r.state == dev.ages.model.Relation.State.WAR || r.state == dev.ages.model.Relation.State.HOSTILE)
                return true;
        }
        return false;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer != null && plugin.diplomacy() != null)
            plugin.diplomacy().onPlayerKill(killer, victim);
    }
}
