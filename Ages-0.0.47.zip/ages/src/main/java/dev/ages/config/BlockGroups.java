package dev.ages.config;

import dev.ages.util.Materials;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

/**
 * groups.yml: named sets of blocks ("any light source", "any planks").
 * A group can combine materials, vanilla block tags and other groups.
 */
public final class BlockGroups {
    private final Map<String, Set<Material>> resolved = new HashMap<>();

    public Set<Material> get(String name) { return resolved.get(name.toLowerCase()); }

    /** Loads and merges any number of files, so groups can live in blockgroups.yml and blockgroups/*.yml. */
    public void load(List<File> files, List<String> errors) {
        load(files, errors, null);
    }

    /** @param notes optional soft warnings (unknown tags/materials); hard errors still go to errors */
    public void load(List<File> files, List<String> errors, List<String> notes) {
        List<String> soft = notes != null ? notes : errors;
        Map<String, ConfigurationSection> raw = new LinkedHashMap<>();
        for (File file : files) {
            YamlConfiguration y = new YamlConfiguration();
            try {
                y.load(file);
            } catch (Exception e) {
                errors.add(file.getName() + ": cannot read (" + e.getMessage() + ")");
                continue;
            }
            for (String k : y.getKeys(false)) {
                ConfigurationSection s = y.getConfigurationSection(k);
                if (s == null) continue;
                if (k.equalsIgnoreCase("item_groups")) {
                    for (String ik : s.getKeys(false)) {
                        ConfigurationSection is = s.getConfigurationSection(ik);
                        if (is != null) raw.put(ik.toLowerCase(), is);
                    }
                } else {
                    raw.put(k.toLowerCase(), s);
                }
            }
        }
        for (String k : raw.keySet()) resolve(k, raw, new ArrayDeque<>(), errors, soft);
    }

    private Set<Material> resolve(String name, Map<String, ConfigurationSection> raw, Deque<String> stack, List<String> errors, List<String> soft) {
        Set<Material> done = resolved.get(name);
        if (done != null) return done;
        if (stack.contains(name)) {
            errors.add("groups.yml: group cycle involving '" + name + "'");
            return Set.of();
        }
        ConfigurationSection s = raw.get(name);
        if (s == null) {
            errors.add("groups.yml: unknown group '" + name + "'");
            return Set.of();
        }
        stack.push(name);
        Set<Material> out = EnumSet.noneOf(Material.class);
        for (String m : s.getStringList("materials")) {
            Material mat = Materials.match(m);
            if (mat == null) soft.add("groups.yml: group '" + name + "' has unknown material '" + m + "' (ignored)");
            else out.add(mat);
        }
        for (String t : s.getStringList("tags")) {
            NamespacedKey key = NamespacedKey.fromString(t.toLowerCase());
            Tag<Material> tag = null;
            if (key != null) {
                tag = Bukkit.getTag(Tag.REGISTRY_BLOCKS, key, Material.class);
                if (tag == null) tag = Bukkit.getTag(Tag.REGISTRY_ITEMS, key, Material.class);
            }
            if (tag == null) soft.add("groups.yml: group '" + name + "' has unknown tag '" + t + "' (ignored)");
            else out.addAll(tag.getValues());
        }
        for (String g : s.getStringList("groups")) out.addAll(resolve(g.toLowerCase(), raw, stack, errors, soft));
        stack.pop();
        resolved.put(name, out);
        return out;
    }
}
