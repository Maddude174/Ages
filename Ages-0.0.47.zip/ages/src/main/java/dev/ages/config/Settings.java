package dev.ages.config;

import dev.ages.util.Materials;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

/** Global rules from settings.yml (formerly town.yml). */
public final class Settings {
    // founding
    public int minTownDistance = 96;
    public String nameRegex = "[A-Za-z0-9 '_-]{3,24}";
    public boolean recipeEnabled = true;
    public final Map<Material, Integer> recipe = new LinkedHashMap<>();
    public int maxMembers = 50;
    public String defaultGovernment = "chiefdom";
    public String defaultEconomy = "barter";

    // protection
    public boolean blockMobSpawns = true;
    public boolean blockMobExplosions = true;
    /** allow | never. Anything else (e.g. the old "war_only") behaves like never. */
    public String tnt = "never";

    public int claimMargin = 12;
    public int maxScanRadius = 20;
    public int revalidateDelaySeconds = 3;
    /** town | player — building conflicts: checked for whole civ or only the placing player. */
    public String conflictScope = "town";
    /** When true, TNT only damages civ land if that civ has at least one member online. */
    public boolean tntRequiresOnline = true;
    /** Send anonymous usage stats via bStats (respects the global bStats opt-out). */
    public boolean metricsEnabled = true;
    /**
     * When the civ economy has money_enabled: false, building money costs are dropped and
     * resource-point costs are multiplied by this (default 2 = double RP).
     */
    public double noMoneyPurchasePointsMult = 2.0;

    // respawn
    public boolean respawnEnabled = true;
    /** false (default): a bed/anchor spawn keeps priority. true: the civilization spawn point overrides beds. */
    public boolean civOverridesBed = false;

    // production
    /** How many missed cycles a building may catch up after being unloaded or the server being down. 1 = none. */
    public int maxCatchupCycles = 1;
    public int flushIntervalSeconds = 30;
    public double maxSpeedBonus = 0.5;

    // economy
    public double incomeMultiplier = 1.0;
    public int ledgerLoad = 200;
    public int coalesceMinutes = 60;
    public final Map<Material, Double> contributionValues = new LinkedHashMap<>();
    public double legacyMoneyToPoints = 0.1;

    // limits shared by tag: {perPlayer, perTown}
    public final Map<String, int[]> tagLimits = new HashMap<>();

    // villagers & gui
    public boolean villagersUntradeable = true;
    public boolean shopRemotePurchase = false;
    /** When true, creative-mode players cannot buy or place building cores (unless ages.creative.bypass). */
    public boolean denyCreativePurchase = true;

    // diplomacy / war (global master switch)
    public boolean diplomacyEnabled = true;
    public int allianceMaxSize = 5;
    public int truceMinHours = 24;
    public int truceMaxHours = 168;
    public int diplomacyLogRetentionDays = 30;

    // governance / elections
    /** Full election cycle length (days). Elected governments open a vote every cycle. */
    public int electionCycleDays = 7;
    /** How long voting stays open before tallies (days). Must be <= electionCycleDays. */
    public int electionVotingDays = 3;

    // rail logistics
    public boolean logisticsEnabled = true;
    /** Rail logistics unlock with this age (set it to the first age to have them from the start). */
    public String logisticsMinAge = "industrial";
    public int logisticsIntervalSeconds = 10;
    public int maxRailsPerNetwork = 4000;
    public int itemsPerBuildingPerRun = 64;
    public int itemsPerNetworkPerRun = 512;

    public boolean tntAllowed() { return tnt.equalsIgnoreCase("allow"); }

    public static Settings load(File file, List<String> errors) {
        Settings s = new Settings();
        YamlConfiguration y = new YamlConfiguration();
        try {
            y.load(file);
        } catch (Exception e) {
            errors.add("settings.yml: cannot read (" + e.getMessage() + ")");
            return s;
        }
        s.minTownDistance = y.getInt("founding.min_distance_between_towns", s.minTownDistance);
        s.nameRegex = y.getString("founding.name_regex", s.nameRegex);
        s.recipeEnabled = y.getBoolean("founding.recipe.enabled", y.getBoolean("founding.fireplace_recipe", true));
        ConfigurationSection rs = y.getConfigurationSection("founding.recipe.ingredients");
        if (rs != null) for (String k : rs.getKeys(false)) {
            Material m = Materials.match(k);
            if (m == null) errors.add("settings.yml: founding recipe has unknown material '" + k + "'");
            else s.recipe.put(m, Math.max(1, rs.getInt(k)));
        }
        if (s.recipe.isEmpty()) { s.recipe.put(Material.CAMPFIRE, 1); s.recipe.put(Material.FLINT, 1); s.recipe.put(Material.STICK, 4); }
        s.maxMembers = y.getInt("members.max", s.maxMembers);
        s.defaultGovernment = y.getString("defaults.government", s.defaultGovernment).toLowerCase();
        s.defaultEconomy = y.getString("defaults.economy", s.defaultEconomy).toLowerCase();

        s.blockMobSpawns = y.getBoolean("protection.block_mob_spawning", true);
        s.blockMobExplosions = y.getBoolean("protection.block_mob_explosions", true);
        s.tnt = y.getString("protection.tnt", "never");
        s.tntRequiresOnline = y.getBoolean("protection.tnt_requires_online", true);
        s.claimMargin = y.getInt("claims.building_margin", s.claimMargin);
        s.maxScanRadius = y.getInt("buildings.max_scan_radius", s.maxScanRadius);
        s.revalidateDelaySeconds = y.getInt("buildings.revalidate_delay_seconds", s.revalidateDelaySeconds);
        s.conflictScope = y.getString("buildings.conflict_scope", "town");
        if (s.conflictScope == null) s.conflictScope = "town";
        s.conflictScope = s.conflictScope.toLowerCase();
        if (!s.conflictScope.equals("player") && !s.conflictScope.equals("town")) s.conflictScope = "town";

        s.respawnEnabled = y.getBoolean("respawn.enabled", true);
        s.civOverridesBed = y.getBoolean("respawn.civilization_overrides_bed", false);

        s.maxCatchupCycles = Math.max(1, y.getInt("production.max_catchup_cycles", 1));
        s.flushIntervalSeconds = Math.max(5, y.getInt("production.flush_interval_seconds", 30));
        s.maxSpeedBonus = Math.max(0, y.getDouble("production.max_speed_bonus", 0.5));

        s.incomeMultiplier = Math.max(0, y.getDouble("economy.income_multiplier", 1.0));
        s.noMoneyPurchasePointsMult = Math.max(1.0, y.getDouble("economy.no_money_purchase_points_mult", 2.0));
        s.ledgerLoad = Math.max(20, y.getInt("economy.ledger.loaded_entries", 200));
        s.coalesceMinutes = Math.max(1, y.getInt("economy.ledger.coalesce_minutes", 60));
        s.legacyMoneyToPoints = Math.max(0, y.getDouble("migration.legacy_money_cost_to_points", 0.1));
        ConfigurationSection cv = y.getConfigurationSection("economy.contributions.items");
        if (cv != null) for (String k : cv.getKeys(false)) {
            Material m = Materials.match(k);
            if (m == null) errors.add("settings.yml: contribution value for unknown material '" + k + "'");
            else s.contributionValues.put(m, cv.getDouble(k));
        }

        ConfigurationSection tl = y.getConfigurationSection("limits.tags");
        if (tl != null) for (String k : tl.getKeys(false))
            s.tagLimits.put(k.toLowerCase(), new int[]{tl.getInt(k + ".per_player", 0), tl.getInt(k + ".per_town", 0)});

        s.villagersUntradeable = y.getBoolean("villagers.untradeable", true);
        s.shopRemotePurchase = y.getBoolean("shop.remote_purchase", false);
        s.denyCreativePurchase = y.getBoolean("shop.deny_creative_purchase", true);
        s.metricsEnabled = y.getBoolean("metrics.enabled", true);
        s.diplomacyEnabled = y.getBoolean("diplomacy.enabled", true);
        s.allianceMaxSize = y.getInt("diplomacy.alliance_max_size", 5);
        s.truceMinHours = y.getInt("diplomacy.truce_min_hours", 24);
        s.truceMaxHours = y.getInt("diplomacy.truce_max_hours", 168);
        s.diplomacyLogRetentionDays = y.getInt("diplomacy.log_retention_days", 30);
        s.electionCycleDays = Math.max(1, y.getInt("governance.election_cycle_days", 7));
        s.electionVotingDays = Math.max(1, y.getInt("governance.election_voting_days", 3));
        if (s.electionVotingDays > s.electionCycleDays) s.electionVotingDays = s.electionCycleDays;

        s.logisticsEnabled = y.getBoolean("logistics.enabled", true);
        s.logisticsMinAge = y.getString("logistics.min_age", "industrial").toLowerCase();
        s.logisticsIntervalSeconds = Math.max(2, y.getInt("logistics.interval_seconds", 10));
        s.maxRailsPerNetwork = Math.max(50, y.getInt("logistics.max_rails_per_network", 4000));
        s.itemsPerBuildingPerRun = Math.max(1, y.getInt("logistics.items_per_building_per_run", 64));
        s.itemsPerNetworkPerRun = Math.max(1, y.getInt("logistics.items_per_network_per_run", 512));
        return s;
    }
}
