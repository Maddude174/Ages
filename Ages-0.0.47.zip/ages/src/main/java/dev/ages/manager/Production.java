package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.config.BuildingDef;
import dev.ages.config.BuildingDef.Entry;
import dev.ages.config.BuildingDef.Ingredient;
import dev.ages.config.BuildingDef.Kind;
import dev.ages.config.BuildingDef.Recipe;
import dev.ages.config.Effects;
import dev.ages.config.Settings;
import dev.ages.model.BlockPos;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Town;
import dev.ages.util.InvUtil;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Entity;
import org.bukkit.entity.IronGolem;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

/**
 * Production driven by TIMESTAMPS, not countdowns. Every building stores the epoch-millis of its next production
 * (persisted, so timers survive restarts). A min-heap of due times means each second only the buildings that are actually
 * due are looked at, however many exist. Everything a building does is read from its YAML: recipes, inputs, outputs,
 * durability, chances, AIR, points and money.
 */
public final class Production implements Runnable {
    private record Slot(long at, UUID id, int ver) {}

    private record Roll(List<ItemStack> items, double points, double money) {
        boolean empty() { return items.isEmpty() && points == 0 && money == 0; }
    }

    private final AgesPlugin plugin;
    private final PriorityQueue<Slot> heap = new PriorityQueue<>(Comparator.comparingLong(Slot::at));
    private final Map<UUID, Integer> versions = new HashMap<>();
    private int tick;

    public Production(AgesPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------------ scheduling

    private long intervalMs(Town t, BuildingDef def, Integer recipeInterval) {
        int sec = recipeInterval != null ? recipeInterval : def.function.interval;
        return Math.max(1000L, (long) (sec * 1000L / plugin.governance().speed(t)));
    }

    /** Set the next production time. at = 0 means "one full interval from now". Persisted. */
    public void schedule(PlacedBuilding pb, long at) {
        BuildingDef def = plugin.reg().effective(pb);
        Town t = plugin.towns().byId(pb.townId);
        if (def == null || def.function == null || t == null) return;
        if (def.function.type.equals("none") && def.function.always.isEmpty()) return;
        if (at <= 0) at = System.currentTimeMillis() + intervalMs(t, def, null);
        pb.nextRun = at;
        push(pb.id, at);
        plugin.towns().markDirty(pb);
    }

    private void push(UUID id, long at) {
        int v = versions.merge(id, 1, Integer::sum);
        heap.add(new Slot(at, id, v));
    }

    public void unschedule(PlacedBuilding pb) { versions.remove(pb.id); }

    /** Startup: queue every building at its persisted timestamp. A building with no timestamp gets one full interval. */
    public void initAll() {
        heap.clear();
        versions.clear();
        for (Town t : plugin.towns().all()) {
            for (PlacedBuilding pb : t.buildings) {
                BuildingDef def = plugin.reg().effective(pb);
                if (def == null || def.function == null) continue;
                if (def.function.type.equals("none") && def.function.always.isEmpty()) continue;
                if (pb.nextRun > 0) push(pb.id, pb.nextRun);
                else schedule(pb, 0);
            }
        }
    }

    /** After a reload: keep timestamps but make sure every building with a function is queued. */
    public void rescheduleMissing() {
        for (Town t : plugin.towns().all())
            for (PlacedBuilding pb : t.buildings)
                if (!versions.containsKey(pb.id)) {
                    BuildingDef def = plugin.reg().effective(pb);
                    if (def != null && def.function != null) { if (pb.nextRun > 0) push(pb.id, pb.nextRun); else schedule(pb, 0); }
                }
    }

    // ------------------------------------------------------------------ the loop (once per second)

    @Override
    public void run() {
        tick++;
        long now = System.currentTimeMillis();
        try {
            Settings s = plugin.reg().settings;
            if (tick % 60 == 0) plugin.tracked().reconcile();
            if (tick % s.flushIntervalSeconds == 0) plugin.towns().flush();
            plugin.buildings().processDirty(now);
            int guard = 0;
            while (!heap.isEmpty() && heap.peek().at() <= now && guard++ < 500) {
                Slot slot = heap.poll();
                Integer cur = versions.get(slot.id());
                if (cur == null || cur != slot.ver()) continue; // superseded or building removed
                PlacedBuilding pb = plugin.towns().building(slot.id());
                if (pb == null) continue;
                try {
                    execute(pb, now);
                } catch (Exception ex) {
                    plugin.getLogger().log(Level.WARNING, "Error in building " + pb.defId, ex);
                    schedule(pb, now + 60_000);
                }
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "Production loop error", ex);
        }
    }

    private void requeue(PlacedBuilding pb, long at) { push(pb.id, at); } // timestamp unchanged: still due when it becomes possible

    private void execute(PlacedBuilding pb, long now) {
        BuildingDef def = plugin.reg().effective(pb);
        Town t = plugin.towns().byId(pb.townId);
        if (def == null || t == null || def.function == null) return;
        var f = def.function;
        World w = Bukkit.getWorld(pb.core.world());
        if (w == null || !w.isChunkLoaded(pb.core.x() >> 4, pb.core.z() >> 4)) { requeue(pb, now + 15_000); return; }
        if (pb.damaged) {
            // Disabled: no production; 50% of always-points becomes ongoing RP decay each interval
            double alwaysPts = 0;
            for (Entry e : f.always) {
                if (e.kind() == Kind.POINTS) alwaysPts += (e.min() + e.max()) / 2.0;
            }
            double decay = alwaysPts * 0.5;
            if (decay > 0) {
                t.points = Math.max(0, t.points - decay);
                plugin.finance().record(t, null, "DECAY", "POINTS", -decay,
                        Text.plain(def.root().name) + " disabled");
                plugin.towns().markTownDirty(t);
            }
            pb.lastStatus = "Disabled: restore structure to repair";
            requeue(pb, now + intervalMs(t, def, null));
            return;
        }

        long baseMs = intervalMs(t, def, null);
        int maxCatchup = plugin.reg().settings.maxCatchupCycles;
        int cycles = 1;
        long overdue = now - pb.nextRun;
        if (maxCatchup > 1 && pb.nextRun > 0 && overdue > baseMs) cycles = (int) Math.min(maxCatchup, 1 + overdue / baseMs);

        Integer used = null;
        for (int i = 0; i < cycles; i++) {
            Integer u = runOnce(t, pb, def, w);
            if (u != null) used = u;
        }
        schedule(pb, now + intervalMs(t, def, used));
    }

    // ------------------------------------------------------------------ one production cycle

    private Integer runOnce(Town t, PlacedBuilding pb, BuildingDef def, World w) {
        var f = def.function;
        if (!f.always.isEmpty()) {
            Roll r = rollAll(f.always);
            deliver(t, pb, def, r, inv(pb.output));
        }
        switch (f.type) {
            case "processor" -> { return processor(t, pb, def); }
            case "spawner" -> spawner(t, pb, def, w);
            case "tax" -> income(t, pb, def, f.perResident * t.population(true, true), "tax");
            case "sell" -> sell(t, pb, def);
            default -> { if (pb.lastStatus.isEmpty() || pb.lastStatus.startsWith("Damaged")) pb.lastStatus = "Running"; }
        }
        return null;
    }

    private Integer processor(Town t, PlacedBuilding pb, BuildingDef def) {
        var f = def.function;
        if (f.recipes.isEmpty()) { pb.lastStatus = "Running"; return null; }
        Inventory in = inv(pb.input), out = inv(pb.output);
        List<Recipe> available = new ArrayList<>();
        var reg = plugin.reg();
        var age = reg.age(t.ageId);
        int ageOrder = age != null ? age.order : 0;
        for (Recipe r : f.recipes) {
            // require_level / require_age are MINIMUMS: higher levels/ages still unlock lower recipes
            if (r.requireLevel() > pb.level) continue;
            if (r.requireAge() != null) {
                var need = reg.age(r.requireAge());
                if (need != null && need.order > ageOrder) continue;
            }
            available.add(r);
        }
        if (available.isEmpty()) { pb.lastStatus = "No unlocked recipes"; return null; }
        List<Recipe> order = new ArrayList<>();
        switch (f.mode) {
            case "selected" -> {
                String key = pb.recipe == null ? "" : pb.recipe;
                List<Recipe> exact = new ArrayList<>();
                List<Recipe> family = new ArrayList<>();
                for (Recipe r : available) {
                    if (r.id().equals(key)) exact.add(r);
                    else if (r.selectKey().equals(key)) family.add(r);
                }
                if (!exact.isEmpty()) {
                    order.addAll(exact);
                } else if (!family.isEmpty()) {
                    family.sort((a, b) -> Integer.compare(b.requireLevel(), a.requireLevel()));
                    order.addAll(family);
                } else {
                    order.add(available.get(0));
                }
            }
            case "random" -> { order.addAll(available); Collections.shuffle(order); }
            default -> order.addAll(available);   // first / all
        }
        boolean all = f.mode.equals("all");
        Integer interval = null;
        String problem = null;
        boolean ran = false;
        for (Recipe r : order) {
            String p = tryRecipe(t, pb, def, r, in, out);
            if (p == null) {
                ran = true;
                if (r.interval() != null) interval = r.interval();
                if (!all) break;
            } else if (problem == null) {
                problem = p;
            }
        }
        // If the ordered list failed on inputs, only report "Needs …" when no unlocked recipe could run
        if (!ran && problem != null && problem.startsWith("Needs")) {
            boolean anyOk = false;
            String firstNeed = problem;
            for (Recipe r : available) {
                String chk = checkRecipe(r, in, out);
                if (chk == null) { anyOk = true; break; }
                if (firstNeed == null) firstNeed = chk;
            }
            if (anyOk) {
                // Retry full available list so a different recipe can run this cycle
                for (Recipe r : available) {
                    String p = tryRecipe(t, pb, def, r, in, out);
                    if (p == null) {
                        ran = true;
                        if (r.interval() != null) interval = r.interval();
                        break;
                    }
                }
            } else {
                problem = firstNeed;
            }
        }
        pb.lastStatus = ran ? "Running" : (problem == null ? "Idle" : problem);
        return interval;
    }

    /** Dry-run: inputs present and outputs would fit (no consume/produce). */
    private String checkRecipe(Recipe r, Inventory in, Inventory out) {
        for (Ingredient i : r.consume()) {
            if (in == null) return "No input container found";
            boolean ok = i.durability() > 0 ? InvUtil.hasTool(in, i.anyOf()) : InvUtil.count(in, i.anyOf()) >= i.amount();
            if (!ok) return "Needs " + (i.durability() > 0 ? "a " : i.amount() + "x ") + names(i) + (i.durability() > 0 ? " (wears " + i.durability() + ")" : "");
        }
        Roll roll = roll(r.entries(), r.pickOne());
        if (!roll.items().isEmpty()) {
            if (out == null) return "No output container found";
            if (!InvUtil.fits(out, roll.items())) return "Output container is full";
        }
        return null;
    }

    /** Runs a recipe if possible. Returns null on success, otherwise the reason it could not run. */
    private String tryRecipe(Town t, PlacedBuilding pb, BuildingDef def, Recipe r, Inventory in, Inventory out) {
        for (Ingredient i : r.consume()) {
            if (in == null) return "No input container found";
            boolean ok = i.durability() > 0 ? InvUtil.hasTool(in, i.anyOf()) : InvUtil.count(in, i.anyOf()) >= i.amount();
            if (!ok) return "Needs " + (i.durability() > 0 ? "a " : i.amount() + "x ") + names(i) + (i.durability() > 0 ? " (wears " + i.durability() + ")" : "");
        }
        Roll roll = roll(r.entries(), r.pickOne());
        if (!roll.items().isEmpty()) {
            if (out == null) return "No output container found";
            if (!InvUtil.fits(out, roll.items())) return "Output container is full";
        }
        for (Ingredient i : r.consume()) {
            if (i.durability() > 0) InvUtil.damage(in, i.anyOf(), i.durability());
            else InvUtil.take(in, i.anyOf(), i.amount());
        }
        deliver(t, pb, def, roll, out);
        return null;
    }

    private static String names(Ingredient i) {
        List<String> n = new ArrayList<>();
        for (var m : i.anyOf()) { if (n.size() == 3) { n.add("..."); break; } n.add(Text.pretty(m)); }
        return String.join("/", n);
    }

    /** Hand out a roll: items to the container, points and money to the civilization (with economy modifiers). */
    private void deliver(Town t, PlacedBuilding pb, BuildingDef def, Roll roll, Inventory out) {
        if (roll.empty()) return;
        if (out != null && !roll.items().isEmpty()) out.addItem(roll.items().toArray(new ItemStack[0]));
        Effects fx = plugin.governance().effects(t);
        String label = Text.plain(def.root().name);
        if (roll.points() > 0) plugin.finance().earnPoints(t, roll.points() * fx.mult("points_output_mult"), label);
        if (roll.money() > 0) routeMoney(t, pb, def, roll.money(), label);
    }

    /**
     * Money income: share to civ treasury from economy.income_to_civ (+ policy income_to_civ add),
     * remainder stored on the building for core-GUI collection. Barter converts all to points.
     */
    private void routeMoney(Town t, PlacedBuilding pb, BuildingDef def, double raw, String source) {
        if (raw <= 0) return;
        Effects fx = plugin.governance().effects(t);
        double amount = raw * fx.mult("money_output_mult") * plugin.reg().settings.incomeMultiplier;
        var e = plugin.reg().economy(t.econId);
        if (!e.moneyEnabled) {
            plugin.finance().earnPoints(t, amount * e.moneyToPoints, source + " (converted from money)");
            return;
        }
        double share = Math.max(0, Math.min(1, e.incomeToCiv + fx.add("income_to_civ")));
        var gov = plugin.reg().government(t.govId);
        if (gov != null && gov.forceIncomeToCiv) share = 1.0;
        double toCiv = amount * share;
        double toBuilding = amount - toCiv;
        if (toCiv > 0) plugin.finance().earnMoney(t, toCiv, source);
        if (toBuilding > 0) {
            double cap = def.function != null && def.function.maxStored > 0 ? def.function.maxStored : 1_000_000;
            pb.stored = Math.min(cap, pb.stored + toBuilding);
            plugin.towns().markDirty(pb);
        }
    }

    // ------------------------------------------------------------------ rolling outputs

    private Roll roll(List<Entry> entries, boolean pickOne) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        if (pickOne) {
            double total = 0;
            for (Entry e : entries) total += e.weight();
            double pick = rnd.nextDouble() * total;
            for (Entry e : entries) {
                pick -= e.weight();
                if (pick < 0) return fromEntries(List.of(e), rnd);
            }
            return new Roll(List.of(), 0, 0);
        }
        List<Entry> hit = new ArrayList<>();
        for (Entry e : entries) if (e.chance() >= 1.0 || rnd.nextDouble() < e.chance()) hit.add(e);
        return fromEntries(hit, rnd);
    }

    private Roll rollAll(List<Entry> entries) { return roll(entries, false); }

    private Roll fromEntries(List<Entry> hit, ThreadLocalRandom rnd) {
        List<ItemStack> items = new ArrayList<>();
        double points = 0, money = 0;
        for (Entry e : hit) {
            switch (e.kind()) {
                case ITEM -> {
                    Material mat = e.item();
                    if (mat == null && e.group() != null) {
                        var set = plugin.reg().groups.get(e.group());
                        if (set != null && !set.isEmpty()) {
                            var arr = set.toArray(new Material[0]);
                            mat = arr[rnd.nextInt(arr.length)];
                        }
                    }
                    if (mat != null && mat.isItem()) {
                        int qty = (int) (e.min() == e.max() ? e.min() : rnd.nextInt((int) e.min(), (int) e.max() + 1));
                        items.add(new ItemStack(mat, qty));
                    }
                }
                case POINTS -> points += amount(e, rnd);
                case MONEY -> money += amount(e, rnd);
                case AIR -> { }
            }
        }
        return new Roll(items, points, money);
    }

    private static double amount(Entry e, ThreadLocalRandom rnd) {
        return e.min() == e.max() ? e.min() : Math.round((e.min() + rnd.nextDouble() * (e.max() - e.min())) * 100) / 100.0;
    }

    // ------------------------------------------------------------------ other function types

    private void spawner(Town t, PlacedBuilding pb, BuildingDef def, World w) {
        var f = def.function;
        if (f.entity == null) return;
        var tracked = plugin.tracked();
        int have = tracked.countBuilding(pb.id);
        if (have >= f.cap) { pb.lastStatus = "Full (" + have + "/" + f.cap + ")"; return; }
        if (f.housingLimited && tracked.villagers(t.id) >= plugin.towns().housing(t)) { pb.lastStatus = "No free housing"; return; }
        if (!f.consume.isEmpty()) {
            Inventory in = inv(pb.input);
            if (in == null) { pb.lastStatus = "No input container found"; return; }
            for (Ingredient i : f.consume) {
                boolean ok = i.durability() > 0 ? InvUtil.hasTool(in, i.anyOf()) : InvUtil.count(in, i.anyOf()) >= i.amount();
                if (!ok) { pb.lastStatus = "Needs " + i.amount() + "x " + names(i); return; }
            }
            for (Ingredient i : f.consume) {
                if (i.durability() > 0) InvUtil.damage(in, i.anyOf(), i.durability());
                else InvUtil.take(in, i.anyOf(), i.amount());
            }
        }
        Location loc = spawnSpot(pb, w);
        if (loc == null) { pb.lastStatus = "No free space to spawn"; return; }
        Entity en = w.spawnEntity(loc, f.entity);
        if (en instanceof IronGolem g) g.setPlayerCreated(true); // defends, but never attacks players
        if (en instanceof org.bukkit.entity.Mob mob) mob.setRemoveWhenFarAway(false);
        tracked.add(en, t.id, pb.id, f.entity.name());
        pb.lastStatus = "Running (" + (have + 1) + "/" + f.cap + ")";
    }

    private Location spawnSpot(PlacedBuilding pb, World w) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        int rx = Math.max(1, pb.maxX - pb.core.x()), rz = Math.max(1, pb.maxZ - pb.core.z());
        for (int i = 0; i < 16; i++) {
            int x = pb.core.x() + rnd.nextInt(-rx, rx + 1);
            int z = pb.core.z() + rnd.nextInt(-rz, rz + 1);
            for (int y = pb.maxY; y >= pb.minY; y--) {
                if (w.getBlockAt(x, y, z).getType().isSolid()
                        && w.getBlockAt(x, y + 1, z).isPassable() && !w.getBlockAt(x, y + 1, z).isLiquid()
                        && w.getBlockAt(x, y + 2, z).isPassable())
                    return new Location(w, x + 0.5, y + 1, z + 0.5);
            }
        }
        return null;
    }

    /** tax / sell income: same routing as production money (building store + optional civ share). */
    private void income(Town t, PlacedBuilding pb, BuildingDef def, double amount, String source) {
        if (amount <= 0) return;
        // Legacy payout: owner forces 100% to building store (ignore civ share)
        if (def.function != null && "owner".equalsIgnoreCase(def.function.payout)) {
            Effects fx = plugin.governance().effects(t);
            double v = amount * fx.mult("money_output_mult") * plugin.reg().settings.incomeMultiplier;
            double cap = def.function.maxStored > 0 ? def.function.maxStored : 1_000_000;
            pb.stored = Math.min(cap, pb.stored + v);
            plugin.towns().markDirty(pb);
        } else {
            routeMoney(t, pb, def, amount, source.equals("tax") ? "tax" : Text.plain(def.root().name));
        }
        pb.lastStatus = "Running";
    }

    private void sell(Town t, PlacedBuilding pb, BuildingDef def) {
        Inventory in = inv(pb.input);
        if (in == null) { pb.lastStatus = "No input container found"; return; }
        var f = def.function;
        int budget = f.maxItems;
        double earned = 0;
        ItemStack[] c = in.getContents();
        for (int i = 0; i < c.length && budget > 0; i++) {
            ItemStack s = c[i];
            if (s == null) continue;
            Double price = f.prices.get(s.getType());
            if (price == null) continue;
            int n = Math.min(budget, s.getAmount());
            earned += price * n;
            budget -= n;
            if (n == s.getAmount()) in.setItem(i, null);
            else { s.setAmount(s.getAmount() - n); in.setItem(i, s); }
        }
        if (earned > 0) income(t, pb, def, earned, "sale");
        else pb.lastStatus = "Nothing to sell";
    }

    private Inventory inv(BlockPos p) {
        if (p == null) return null;
        Block b = p.block();
        if (b == null || !b.getWorld().isChunkLoaded(p.x() >> 4, p.z() >> 4)) return null;
        return b.getState(false) instanceof Container c ? c.getInventory() : null;
    }
}
