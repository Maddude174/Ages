package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.config.*;
import dev.ages.model.*;
import dev.ages.util.Text;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Government type, economic system, policies, leadership and ownership. The three are independent:
 *  - the government decides roles/permissions and how the political leader is chosen
 *  - the economy decides how money, points and contributions behave
 *  - policies add modifiers on top of either
 *  - the technical OWNER (disband, transfer) is a separate seat from the political LEADER
 */
public final class Governance {
    private final AgesPlugin plugin;

    public Governance(AgesPlugin plugin) { this.plugin = plugin; }

    private Registries reg() { return plugin.reg(); }

    // ------------------------------------------------------------------ modifiers

    /** Government + economy + active policies + building bonuses, combined. */
    public Effects effects(Town t) {
        Effects e = new Effects();
        e.apply(reg().government(t.govId).modifiers);
        e.apply(reg().economy(t.econId).modifiers);
        for (String pid : t.policies) {
            PolicyDef p = reg().policy(pid);
            if (p != null) e.apply(p.effects);
        }
        double speed = 0;
        for (PlacedBuilding b : t.buildings) {
            BuildingDef d = reg().effective(b);
            if (d != null && !b.damaged) speed += d.provide("production_speed");
        }
        e.apply(Map.of("production_speed_bonus", Math.min(reg().settings.maxSpeedBonus, speed)));
        return e;
    }

    /** Total production speed factor (2.0 = twice as fast). */
    public double speed(Town t) {
        Effects e = effects(t);
        return Math.max(0.1, e.mult("production_speed_mult") * (1 + e.add("production_speed_bonus")));
    }

    // ------------------------------------------------------------------ government

    /** Install a government's roles; members keep their role if it exists there, otherwise get the default role. */
    public void applyGovernment(Town t, GovernmentDef g) {
        Map<String, Rank> roles = new LinkedHashMap<>();
        for (Rank r : g.roles.values()) roles.put(r.name, r.copy());
        for (Map.Entry<UUID, String> e : t.members.entrySet()) if (!roles.containsKey(e.getValue())) e.setValue(g.defaultRole);
        t.ranks.clear();
        t.ranks.putAll(roles);
        t.govId = g.id;
        t.votes.clear();
        t.electionEndsAt = 0;
        t.nextElectionAt = 0;
        if (g.leaderSelection.equals("none")) {
            // Leaderless: demote any previous leader role holders
            if (g.leaderRole != null) {
                for (Map.Entry<UUID, String> e : t.members.entrySet())
                    if (e.getValue().equals(g.leaderRole)) e.setValue(g.defaultRole);
            }
            t.leader = null;
        } else {
            UUID leader = t.leader;
            if (g.leaderSelection.equals("owner") || leader == null || !t.members.containsKey(leader))
                leader = t.members.containsKey(t.owner) ? t.owner : t.members.keySet().stream().findFirst().orElse(null);
            setLeaderRaw(t, g, leader);
            if (g.leaderSelection.equals("elected")) {
                t.nextElectionAt = System.currentTimeMillis() + 3_600_000L; // first election in 1 hour
            }
        }
    }

    private void setLeaderRaw(Town t, GovernmentDef g, UUID leader) {
        if (g.leaderRole != null) {
            for (Map.Entry<UUID, String> e : t.members.entrySet())
                if (e.getValue().equals(g.leaderRole) && !e.getKey().equals(leader)) e.setValue(g.defaultRole);
            if (leader != null && t.members.containsKey(leader)) t.members.put(leader, g.leaderRole);
        }
        t.leader = leader;
    }

    public void setLeader(Town t, UUID leader) {
        setLeaderRaw(t, reg().government(t.govId), leader);
        plugin.towns().save(t);
    }

    /** Civilizations saved before governments existed get an owner, the default government and economy. */
    public void migrateLegacy(Town t) {
        if (t.owner != null && t.govId != null && t.econId != null) return;
        if (t.owner == null) {
            UUID best = null;
            int w = -1;
            for (UUID u : t.members.keySet()) if (t.weightOf(u) > w) { w = t.weightOf(u); best = u; }
            t.owner = best;
            t.leader = best;
        }
        if (t.econId == null) t.econId = reg().settings.defaultEconomy;
        if (t.govId == null || reg().governments.get(t.govId) == null) applyGovernment(t, reg().government(reg().settings.defaultGovernment));
        plugin.towns().save(t);
        plugin.getLogger().info("Migrated civilization '" + t.name + "' to governments/economies (owner and roles assigned).");
    }

    private boolean ageOk(Town t, String minAge) {
        if (minAge == null) return true;
        AgeDef cur = reg().age(t.ageId);
        return cur != null && reg().ageOrder(minAge) <= cur.order;
    }

    private String cooldown(long changedAt, int hours) {
        long left = changedAt + hours * 3_600_000L - System.currentTimeMillis();
        return left > 0 ? "On cooldown for another " + Text.remaining(left) + "." : null;
    }

    /** Null if the player could change to this government right now; otherwise why not. */
    public String govBlocker(Player p, Town t, GovernmentDef g) {
        if (!t.can(p.getUniqueId(), Perm.CHANGE_GOVERNMENT)) return "Your role cannot change the government.";
        if (g.id.equals(t.govId)) return "This is already your government.";
        GovernmentDef cur = reg().government(t.govId);
        if (cur != null && cur.exitOnlyByRevolution)
            return "Your " + Text.plain(cur.name) + " can only be changed through revolution (civil war), not by decree.";
        if (!ageOk(t, g.minAge)) return "Requires the " + Text.plain(reg().age(g.minAge).name) + ".";
        String cd = cooldown(t.govChangedAt, cur != null ? cur.changeCooldownHours : 24);
        if (cd != null) return cd;
        return plugin.finance().civProblem(t, g.changeCost);
    }

    public String changeGovernment(Player p, Town t, GovernmentDef g) {
        String b = govBlocker(p, t, g);
        if (b != null) return b;
        plugin.finance().payCiv(t, p.getUniqueId(), g.changeCost, "GOVERNMENT", "Changed government to " + Text.plain(g.name));
        applyGovernment(t, g);
        t.govChangedAt = System.currentTimeMillis();
        pruneGovernmentPolicies(t, g);
        plugin.towns().save(t);
        return null;
    }

    private void pruneGovernmentPolicies(Town t, GovernmentDef g) {
        List<String> keep = new ArrayList<>();
        for (String pid : t.policies) {
            PolicyDef p = reg().policy(pid);
            if (p != null && p.kind.equals("government") && !g.policies.contains(pid)) continue;
            keep.add(pid);
        }
        t.policies.clear();
        t.policies.addAll(keep);
    }

    // ------------------------------------------------------------------ economy

    public String econBlocker(Player p, Town t, EconomyDef e) {
        if (!t.can(p.getUniqueId(), Perm.CHANGE_ECONOMY)) return "Your role cannot change the economic system.";
        if (e.id.equals(t.econId)) return "This is already your economic system.";
        if (!ageOk(t, e.minAge)) return "Requires the " + Text.plain(reg().age(e.minAge).name) + ".";
        String cd = cooldown(t.econChangedAt, reg().economy(t.econId).changeCooldownHours);
        if (cd != null) return cd;
        return plugin.finance().civProblem(t, e.changeCost);
    }

    public String changeEconomy(Player p, Town t, EconomyDef e) {
        String b = econBlocker(p, t, e);
        if (b != null) return b;
        plugin.finance().payCiv(t, p.getUniqueId(), e.changeCost, "ECONOMY", "Changed economy to " + Text.plain(e.name));
        t.econId = e.id;
        t.econChangedAt = System.currentTimeMillis();
        List<String> keep = new ArrayList<>();
        for (String pid : t.policies) {
            PolicyDef pol = reg().policy(pid);
            if (pol != null && pol.kind.equals("economy") && !e.policies.contains(pid)) continue;
            keep.add(pid);
        }
        t.policies.clear();
        t.policies.addAll(keep);
        plugin.towns().save(t);
        return null;
    }

    // ------------------------------------------------------------------ policies

    public boolean offered(Town t, PolicyDef pol) {
        return pol.kind.equals("government") ? reg().government(t.govId).policies.contains(pol.id) : reg().economy(t.econId).policies.contains(pol.id);
    }

    public int slots(Town t, String kind) {
        return kind.equals("government") ? reg().government(t.govId).policySlots : reg().economy(t.econId).policySlots;
    }

    public long active(Town t, String kind) {
        return t.policies.stream().map(id -> reg().policy(id)).filter(p -> p != null && p.kind.equals(kind)).count();
    }

    /** Why this policy cannot be adopted (null = it can). Revoking is always allowed with the permission. */
    public String policyBlocker(Player p, Town t, PolicyDef pol) {
        if (!t.can(p.getUniqueId(), Perm.MANAGE_POLICIES)) return "Your role cannot manage policies.";
        if (t.policies.contains(pol.id)) return null;
        if (!offered(t, pol)) return "Your " + pol.kind + " does not offer this policy.";
        if (!ageOk(t, pol.minAge)) return "Requires the " + Text.plain(reg().age(pol.minAge).name) + ".";
        if (active(t, pol.kind) >= slots(t, pol.kind)) return "All " + slots(t, pol.kind) + " " + pol.kind + " policy slots are in use.";
        if (pol.exclusiveGroup != null) for (String id : t.policies) {
            PolicyDef o = reg().policy(id);
            if (o != null && pol.exclusiveGroup.equals(o.exclusiveGroup)) return "Conflicts with the active policy " + Text.plain(o.name) + ".";
        }
        return plugin.finance().civProblem(t, pol.cost);
    }

    /** Toggles: revokes if active, adopts otherwise. Returns an error or null. */
    public String togglePolicy(Player p, Town t, PolicyDef pol) {
        String b = policyBlocker(p, t, pol);
        if (b != null) return b;
        if (t.policies.remove(pol.id)) {
            plugin.finance().record(t, p.getUniqueId(), "POLICY", "POINTS", 0, "Revoked " + Text.plain(pol.name));
        } else {
            plugin.finance().payCiv(t, p.getUniqueId(), pol.cost, "POLICY", "Adopted " + Text.plain(pol.name));
            t.policies.add(pol.id);
        }
        plugin.towns().save(t);
        return null;
    }

    // ------------------------------------------------------------------ leadership & ownership

    public boolean isElected(Town t) {
        return reg().government(t.govId).leaderSelection.equals("elected");
    }

    /** Voting window is open. */
    public boolean electionOpen(Town t) {
        return isElected(t) && t.electionEndsAt > System.currentTimeMillis();
    }

    public String vote(Player p, Town t, UUID candidate) {
        GovernmentDef g = reg().government(t.govId);
        if (!g.leaderSelection.equals("elected")) return "Your " + Text.plain(g.name) + " does not hold elections.";
        if (!t.can(p.getUniqueId(), Perm.VOTE)) return "Your role cannot vote.";
        if (!electionOpen(t)) return "There is no election open right now. Next: " + nextElectionHint(t);
        if (!t.members.containsKey(candidate)) return "That player is not a member.";
        t.votes.put(p.getUniqueId(), candidate);
        plugin.towns().save(t);
        return null; // tallied when the voting window ends
    }

    public String nextElectionHint(Town t) {
        long at = t.electionEndsAt > System.currentTimeMillis() ? t.electionEndsAt
                : (t.nextElectionAt > 0 ? t.nextElectionAt : 0);
        if (at <= 0) return "scheduling…";
        return Text.remaining(at - System.currentTimeMillis());
    }

    /** Open a voting window for an elected government. */
    public void openElection(Town t) {
        if (!isElected(t)) return;
        int voteDays = reg().settings.electionVotingDays;
        t.votes.clear();
        t.electionEndsAt = System.currentTimeMillis() + voteDays * 86_400_000L;
        t.nextElectionAt = 0;
        plugin.towns().save(t);
        broadcast(t, "&6Election open for " + voteDays + " day(s). Use &e/ages vote <member>&6.");
    }

    /** Count votes, install leader, schedule next cycle. */
    public void closeElection(Town t) {
        if (!isElected(t)) return;
        GovernmentDef g = reg().government(t.govId);
        Map<UUID, Integer> tally = new HashMap<>();
        for (UUID c : t.votes.values()) if (t.members.containsKey(c)) tally.merge(c, 1, Integer::sum);
        UUID best = t.leader;
        int bestN = -1;
        for (Map.Entry<UUID, Integer> e : tally.entrySet()) {
            if (e.getValue() > bestN) { best = e.getKey(); bestN = e.getValue(); }
            else if (e.getValue() == bestN && t.leader != null && e.getKey().equals(t.leader)) best = t.leader; // ties keep incumbent
        }
        if (best != null && t.members.containsKey(best) && !best.equals(t.leader)) {
            setLeaderRaw(t, g, best);
            broadcast(t, "&aElection result: &f" + name(best) + " &ais the new " + g.leaderTitle + "&a.");
        } else {
            broadcast(t, "&7Election ended. " + g.leaderTitle + " remains &f" + name(t.leader) + "&7."
                    + (bestN <= 0 ? " (no valid votes)" : " (tie or majority retained)"));
        }
        t.votes.clear();
        t.electionEndsAt = 0;
        int cycle = reg().settings.electionCycleDays;
        int voteDays = reg().settings.electionVotingDays;
        // Next open after the remainder of the cycle past this voting window
        long quiet = Math.max(0, cycle - voteDays) * 86_400_000L;
        t.nextElectionAt = System.currentTimeMillis() + Math.max(86_400_000L, quiet); // at least 1 day quiet
        plugin.towns().save(t);
    }

    /** Ensure elected civs have a schedule; close windows that expired. Called each tick. */
    public void tickElections() {
        long now = System.currentTimeMillis();
        for (Town t : plugin.towns().all()) {
            if (!isElected(t)) {
                if (t.electionEndsAt != 0 || t.nextElectionAt != 0) {
                    t.electionEndsAt = 0;
                    t.nextElectionAt = 0;
                    t.votes.clear();
                    plugin.towns().markTownDirty(t);
                }
                continue;
            }
            if (t.electionEndsAt > 0 && now >= t.electionEndsAt) {
                closeElection(t);
            } else if (t.electionEndsAt <= 0) {
                if (t.nextElectionAt <= 0) {
                    // First schedule: open soon (1 hour grace after adopt) or open immediately if long-lived
                    t.nextElectionAt = now + 3_600_000L;
                    plugin.towns().markTownDirty(t);
                } else if (now >= t.nextElectionAt) {
                    openElection(t);
                }
            }
        }
    }

    private void broadcast(Town t, String msg) {
        for (UUID u : t.members.keySet()) {
            Player pl = org.bukkit.Bukkit.getPlayer(u);
            if (pl != null) Text.msg(pl, msg);
        }
    }

    private static String name(UUID u) {
        if (u == null) return "?";
        var op = org.bukkit.Bukkit.getOfflinePlayer(u);
        return op.getName() != null ? op.getName() : u.toString().substring(0, 8);
    }


    public String appointLeader(Player p, Town t, UUID target) {
        GovernmentDef g = reg().government(t.govId);
        if (g.leaderSelection.equals("none")) return "This government has no leader.";
        if (g.leaderSelection.equals("elected")) return "Your leader is elected: use /ages vote.";
        if (g.leaderSelection.equals("owner")) return "In a " + Text.plain(g.name) + " the owner is the leader.";
        if (!t.can(p.getUniqueId(), Perm.APPOINT_OFFICIALS)) return "Your role cannot appoint officials.";
        if (!t.members.containsKey(target)) return "That player is not a member.";
        setLeader(t, target);
        return null;
    }

    public String transferOwnership(Player p, Town t, UUID target) {
        if (!t.can(p.getUniqueId(), Perm.TRANSFER_OWNERSHIP)) return "Only the technical owner can transfer ownership.";
        if (!t.members.containsKey(target)) return "That player is not a member.";
        t.owner = target;
        GovernmentDef g = reg().government(t.govId);
        if (g.leaderSelection.equals("owner")) setLeaderRaw(t, g, target);
        plugin.towns().save(t);
        return null;
    }

    /** Assign a role to a member. The leader role is set by the government (appointment/election), not here. */
    public String assignRole(Player p, Town t, UUID target, String roleName) {
        UUID me = p.getUniqueId();
        if (!t.can(me, Perm.APPOINT_OFFICIALS)) return "Your role cannot appoint officials.";
        Rank r = t.ranks.get(roleName);
        if (r == null) return "Unknown role.";
        if (!t.members.containsKey(target)) return "That player is not a member.";
        GovernmentDef g = reg().government(t.govId);
        if (roleName.equals(g.leaderRole)) return "The " + g.leaderTitle + " is chosen by the government (" + g.leaderSelection + ").";
        if (target.equals(t.leader)) return "The " + g.leaderTitle + "'s role is set by the government.";
        if (!target.equals(me) && t.weightOf(target) >= t.weightOf(me)) return "You can only assign roles to members ranked below you.";
        if (r.weight >= t.weightOf(me)) return "You can only assign roles ranked below your own.";
        t.members.put(target, roleName);
        plugin.towns().save(t);
        return null;
    }
}
