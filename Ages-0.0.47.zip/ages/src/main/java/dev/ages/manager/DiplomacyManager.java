package dev.ages.manager;

import dev.ages.AgesPlugin;
import dev.ages.config.EconomyDef;
import dev.ages.config.GovernmentDef;
import dev.ages.model.Relation;
import dev.ages.model.Relation.State;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Town;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

/**
 * Civilization relations, war goals, tribute, and alliance hooks.
 * Persisted under plugins/Ages/diplomacy.yml
 */
public final class DiplomacyManager implements Runnable {
    private final AgesPlugin plugin;
    private final Map<String, Relation> byPair = new HashMap<>();
    private final List<String> log = new ArrayList<>();
    private final List<String> warLog = new ArrayList<>();
    /** Pending mutual actions: key = pair key, value = "TYPE:fromTownId:payload" */
    private final Map<String, String> proposals = new HashMap<>();
    private int tick;

    public DiplomacyManager(AgesPlugin plugin) {
        this.plugin = plugin;
    }

    private static String key(UUID a, UUID b) {
        return a.compareTo(b) <= 0 ? a + ":" + b : b + ":" + a;
    }

    public Relation get(UUID a, UUID b) {
        return byPair.computeIfAbsent(key(a, b), k -> new Relation(a, b));
    }

    public Relation get(Town a, Town b) {
        if (a == null || b == null || a.id.equals(b.id)) return null;
        return get(a.id, b.id);
    }

    public Collection<Relation> all() { return byPair.values(); }

    public List<Relation> of(Town t) {
        List<Relation> out = new ArrayList<>();
        for (Relation r : byPair.values()) if (r.involves(t.id)) out.add(r);
        return out;
    }

    public java.util.Collection<Relation> allRelations() {
        return java.util.Collections.unmodifiableCollection(byPair.values());
    }

    public boolean enabled() {
        return plugin.reg().settings.diplomacyEnabled;
    }

    public boolean atWar(Town a, Town b) {
        Relation r = get(a, b);
        return r != null && r.state == State.WAR;
    }

    public boolean hostileOrWar(Town a, Town b) {
        Relation r = get(a, b);
        if (r == null) return false;
        return r.state == State.WAR || r.state == State.HOSTILE;
    }

    // ------------------------------------------------------------------ state changes

    public String setState(Player actor, Town from, Town to, State state, String warGoal) {
        if (!enabled()) return "Diplomacy is disabled on this server.";
        if (from == null || to == null || from.id.equals(to.id)) return "Invalid civilizations.";
        Relation r = get(from, to);
        State prev = r.state;
        r.state = state;
        r.since = System.currentTimeMillis();
        normalize(r, from, state, warGoal);
        String msg = prev + " -> " + state + (warGoal != null ? " (" + warGoal + ")" : "");
        log(actor, from, to, msg);
        if (state == State.WAR || prev == State.WAR) warLog(actor, from, to, msg);
        broadcast(from, to, "&7[Diplomacy] &f" + from.name + " &7/ &f" + to.name + "&7: &e" + state
                + (warGoal != null && state == State.WAR ? " &8(" + warGoal + ")" : ""));
        proposals.remove(key(from.id, to.id));
        save();
        return null;
    }

    /** Clear fields that do not apply to the new state (admin and normal paths). */
    private void normalize(Relation r, Town actorCiv, State state, String warGoal) {
        switch (state) {
            case WAR -> {
                r.aggressor = actorCiv != null ? actorCiv.id : r.aggressor;
                r.warGoal = warGoal != null ? warGoal.toLowerCase(Locale.ROOT) : (r.warGoal != null ? r.warGoal : "none");
                r.warScore = Math.max(0, Math.min(1000, r.warScore));
                r.overlord = null;
                r.tributeRate = 0;
                r.allianceId = null;
                r.truceUntil = 0;
            }
            case TRUCE -> {
                int hours = plugin.reg().settings.truceMinHours;
                r.truceUntil = System.currentTimeMillis() + hours * 3_600_000L;
                r.aggressor = null;
                r.warGoal = "none";
                r.warScore = 0;
                r.overlord = null;
                r.tributeRate = 0;
                r.allianceId = null;
            }
            case TRIBUTARY, SETTLEMENT -> {
                if (actorCiv != null) r.overlord = actorCiv.id;
                r.aggressor = null;
                r.warGoal = "none";
                r.warScore = 0;
                r.allianceId = null;
                r.truceUntil = 0;
                if (r.tributeRate <= 0) r.tributeRate = 0.1;
            }
            case ALLIED, ALLIED_DEFENSIVE -> {
                r.overlord = null;
                r.aggressor = null;
                r.warGoal = "none";
                r.warScore = 0;
                r.tributeRate = 0;
                r.truceUntil = 0;
                if (r.allianceId == null) r.allianceId = UUID.randomUUID().toString().substring(0, 8);
            }
            case HOSTILE, NEUTRAL -> {
                r.overlord = null;
                r.aggressor = null;
                r.warGoal = "none";
                r.warScore = 0;
                r.allianceId = null;
                r.tributeRate = 0;
                r.truceUntil = 0;
            }
        }
    }

    // ---- admin ----

    public String adminSetRelation(Town a, Town b, State state, String warGoal, String adminName) {
        if (a == null || b == null || a.id.equals(b.id)) return "Invalid civilizations.";
        Relation r = get(a, b);
        State prev = r.state;
        r.state = state;
        r.since = System.currentTimeMillis();
        Town actor = (state == State.TRIBUTARY || state == State.SETTLEMENT) ? a : a;
        if (state == State.WAR && r.aggressor == null) r.aggressor = a.id;
        normalize(r, actor, state, warGoal);
        String msg = "ADMIN " + adminName + ": " + prev + " -> " + state;
        log(null, a, b, msg);
        if (state == State.WAR || prev == State.WAR) warLog(null, a, b, msg);
        broadcast(a, b, "&c[Admin] &7Relation set: &f" + a.name + " &7/ &f" + b.name + " &e" + state);
        proposals.remove(key(a.id, b.id));
        save();
        return null;
    }

    public String adminSetWarScore(Town a, Town b, int score, String adminName) {
        Relation r = get(a, b);
        if (r.state != State.WAR) return "Those civilizations are not at war.";
        r.warScore = Math.max(0, Math.min(1000, score));
        warLog(null, a, b, "ADMIN " + adminName + " warscore=" + r.warScore);
        save();
        if (r.warScore >= 1000) {
            Town winner = r.aggressor != null && r.aggressor.equals(a.id) ? a : b;
            Town loser = winner.id.equals(a.id) ? b : a;
            // prefer aggressor as winner when score maxed by admin
            if (r.aggressor != null) {
                winner = plugin.towns().byId(r.aggressor);
                loser = winner != null && winner.id.equals(a.id) ? b : a;
            }
            if (winner != null) resolveWar(winner, loser, r);
        }
        return null;
    }

    /** Force end war into a truce (admin). */
    public String adminEndWar(Town a, Town b, String adminName) {
        Relation r = get(a, b);
        if (r.state != State.WAR) return "Not at war.";
        return adminSetRelation(a, b, State.TRUCE, null, adminName);
    }

    public String adminTribute(Town overlord, Town subject, double rate, String adminName) {
        if (rate <= 0) {
            Relation r = get(overlord, subject);
            if (r.state != State.TRIBUTARY && r.state != State.SETTLEMENT) return "Not a tributary/settlement.";
            return adminSetRelation(overlord, subject, State.NEUTRAL, null, adminName);
        }
        Relation r = get(overlord, subject);
        r.state = State.TRIBUTARY;
        r.overlord = overlord.id;
        r.tributeRate = Math.max(0.05, Math.min(0.5, rate));
        normalize(r, overlord, State.TRIBUTARY, null);
        r.tributeRate = Math.max(0.05, Math.min(0.5, rate));
        log(null, overlord, subject, "ADMIN " + adminName + " tribute rate=" + r.tributeRate);
        broadcast(overlord, subject, "&c[Admin] &6" + subject.name + " &7tributary of &f" + overlord.name
                + " &7(" + (int) (r.tributeRate * 100) + "%)");
        save();
        return null;
    }

    // ---- proposals (mutual confirm) ----

    public String propose(Player p, Town from, Town to, String type, String payload) {
        if (!enabled()) return "Diplomacy is disabled.";
        if (!from.can(p.getUniqueId(), dev.ages.model.Perm.MANAGE_DIPLOMACY)
                && !from.can(p.getUniqueId(), dev.ages.model.Perm.DECLARE_WAR)
                && !from.can(p.getUniqueId(), dev.ages.model.Perm.CHANGE_SETTINGS))
            return "Your role cannot manage diplomacy.";
        String k = key(from.id, to.id);
        proposals.put(k, type.toUpperCase(Locale.ROOT) + ":" + from.id + ":" + (payload == null ? "" : payload));
        broadcast(from, to, "&e" + from.name + " proposes &f" + type + " &eto " + to.name
                + "&e. Accept: &f/ages accept_diplo " + from.name);
        save();
        return null;
    }

    public String acceptProposal(Player p, Town accepter, Town other) {
        if (!accepter.can(p.getUniqueId(), dev.ages.model.Perm.MANAGE_DIPLOMACY)
                && !accepter.can(p.getUniqueId(), dev.ages.model.Perm.DECLARE_WAR)
                && !accepter.can(p.getUniqueId(), dev.ages.model.Perm.CHANGE_SETTINGS))
            return "Your role cannot manage diplomacy.";
        String k = key(accepter.id, other.id);
        String raw = proposals.get(k);
        if (raw == null) return "No pending proposal with that civilization.";
        String[] parts = raw.split(":", 3);
        String type = parts[0];
        UUID fromId = UUID.fromString(parts[1]);
        if (fromId.equals(accepter.id)) return "You sent this proposal; the other side must accept.";
        String payload = parts.length > 2 ? parts[2] : "";
        proposals.remove(k);
        return switch (type) {
            case "TRUCE" -> setState(p, accepter, other, State.TRUCE, null);
            case "ALLIED" -> setState(p, accepter, other, State.ALLIED, null);
            case "ALLIED_DEFENSIVE" -> setState(p, accepter, other, State.ALLIED_DEFENSIVE, null);
            case "SETTLEMENT" -> {
                Town over = plugin.towns().byId(fromId);
                if (over == null) yield "Proposer gone.";
                yield setState(p, over, accepter, State.SETTLEMENT, null);
            }
            default -> "Unknown proposal type.";
        };
    }

    public void warLog(Player actor, Town from, Town to, String msg) {
        String line = System.currentTimeMillis() + "|" + (actor != null ? actor.getName() : "admin")
                + "|" + from.name + "|" + to.name + "|" + msg;
        warLog.add(0, line);
        while (warLog.size() > 300) warLog.remove(warLog.size() - 1);
    }

    public List<String> recentWarLog(int n) {
        return warLog.subList(0, Math.min(n, warLog.size()));
    }


    public String declareWar(Player p, Town from, Town to, String goal) {
        if (!enabled()) return "Diplomacy is disabled on this server.";
        if (!from.can(p.getUniqueId(), dev.ages.model.Perm.DECLARE_WAR)
                && !from.can(p.getUniqueId(), dev.ages.model.Perm.CHANGE_SETTINGS))
            return "Your role cannot declare war.";
        Relation r = get(from, to);
        if (r.state == State.WAR) return "Already at war.";
        if (r.state == State.TRUCE && System.currentTimeMillis() < r.truceUntil)
            return "Truce is still in effect.";
        if (r.state == State.ALLIED || r.state == State.ALLIED_DEFENSIVE)
            return "Break the alliance first.";
        if (r.state == State.TRIBUTARY || r.state == State.SETTLEMENT) {
            if (r.overlord != null && r.overlord.equals(to.id) && !"revolt".equalsIgnoreCase(goal))
                return "Tributaries must use the revolt goal to fight their overlord.";
        }
        String g = goal == null ? "none" : goal.toLowerCase(Locale.ROOT);
        if (!Set.of("none", "tributary", "conquest", "total_war", "political", "raid", "revolt", "revolution").contains(g))
            return "Unknown war goal.";
        String err = setState(p, from, to, State.WAR, g);
        if (err != null) return err;
        // Defensive allies of the defender auto-join war against the aggressor
        callDefensiveAllies(to, from);
        broadcast(from, to, "&c" + from.name + " declared war on " + to.name + " &7(" + g + ")");
        return null;
    }

    private void callDefensiveAllies(Town defender, Town aggressor) {
        for (Relation r : of(defender)) {
            if (r.state != State.ALLIED_DEFENSIVE && r.state != State.ALLIED) continue;
            Town ally = plugin.towns().byId(r.other(defender.id));
            if (ally == null || ally.id.equals(aggressor.id)) continue;
            Relation vs = get(ally, aggressor);
            if (vs.state == State.WAR) continue;
            vs.state = State.WAR;
            vs.aggressor = aggressor.id;
            vs.warGoal = "none";
            vs.since = System.currentTimeMillis();
            log(null, ally, aggressor, "defensive auto-join vs " + aggressor.name);
            broadcast(ally, aggressor, "&e" + ally.name + " joined the war against " + aggressor.name + " &7(defensive alliance)");
        }
        save();
    }

    public String proposeAlliance(Player p, Town from, Town to, boolean defensive) {
        if (!enabled()) return "Diplomacy is disabled on this server.";
        Relation r = get(from, to);
        if (r.state == State.WAR) return "Cannot ally while at war.";
        return propose(p, from, to, defensive ? "ALLIED_DEFENSIVE" : "ALLIED", "");
    }

    public String offerTruce(Player p, Town from, Town to, Integer hours) {
        Relation r = get(from, to);
        if (r.state != State.WAR) return "Not at war.";
        return propose(p, from, to, "TRUCE", hours == null ? "" : String.valueOf(hours));
    }

    public String demandTributary(Player p, Town overlord, Town subject) {
        if (!overlord.can(p.getUniqueId(), dev.ages.model.Perm.MANAGE_DIPLOMACY)
                && !overlord.can(p.getUniqueId(), dev.ages.model.Perm.CHANGE_SETTINGS))
            return "Your role cannot demand tribute.";
        Relation r = get(overlord, subject);
        // Victory shortcut if war score high enough on tributary goal
        if (r.state == State.WAR && "tributary".equals(r.warGoal) && r.warScore >= 600
                && overlord.id.equals(r.aggressor)) {
            return enforceTributary(overlord, subject, 0.1);
        }
        if (r.state != State.WAR && r.state != State.HOSTILE)
            return "Subject must be at war (tributary goal, score >= 600) or accept peacefully as Settlement.";
        return "War score too low (need 600+) or wrong goal.";
    }

    public String releaseTributary(Player p, Town overlord, Town subject) {
        if (!overlord.can(p.getUniqueId(), dev.ages.model.Perm.MANAGE_DIPLOMACY)
                && !overlord.can(p.getUniqueId(), dev.ages.model.Perm.CHANGE_SETTINGS))
            return "Your role cannot release a tributary.";
        Relation r = get(overlord, subject);
        if (r.state != State.TRIBUTARY && r.state != State.SETTLEMENT)
            return "They are not your tributary or settlement.";
        if (r.overlord == null || !r.overlord.equals(overlord.id))
            return "You are not the overlord.";
        r.state = State.NEUTRAL;
        r.overlord = null;
        r.tributeRate = 0;
        r.since = System.currentTimeMillis();
        log(p, overlord, subject, "released tributary");
        broadcast(overlord, subject, "&a" + subject.name + " was released by " + overlord.name);
        save();
        return null;
    }

    public String enforceTributary(Town overlord, Town subject, double rate) {
        Relation r = get(overlord, subject);
        r.state = State.TRIBUTARY;
        r.overlord = overlord.id;
        r.tributeRate = Math.max(0.05, Math.min(0.5, rate <= 0 ? 0.1 : rate));
        r.warGoal = "none";
        r.aggressor = null;
        r.warScore = 0;
        r.since = System.currentTimeMillis();
        log(null, overlord, subject, "tributary rate=" + r.tributeRate);
        broadcast(overlord, subject, "&6" + subject.name + " is now a tributary of " + overlord.name);
        save();
        return null;
    }

    // ------------------------------------------------------------------ war score & victory

    public void addWarScore(Town attacker, Town defender, int amount) {
        Relation r = get(attacker, defender);
        if (r.state != State.WAR) return;
        r.warScore = Math.max(0, Math.min(1000, r.warScore + amount));
        save();
        if (r.warScore >= 1000) {
            resolveWar(attacker, defender, r);
        }
    }

    /** Resolve war when score hits 1000 (or total_war special cases). */
    public void resolveWar(Town winner, Town loser, Relation r) {
        if (r.state != State.WAR) return;
        String goal = r.warGoal == null ? "none" : r.warGoal;
        switch (goal) {
            case "tributary", "conquest" -> enforceTributary(winner, loser, 0.15);
            case "total_war" -> {
                broadcast(winner, loser, "&4" + loser.name + " was destroyed by total war (" + winner.name + ")");
                if (isOpposition(loser)) {
                    plugin.towns().disband(loser);
                } else {
                    for (var b : new ArrayList<>(loser.buildings)) {
                        plugin.buildings().setDisabled(b, false);
                    }
                    plugin.towns().disband(loser);
                }
                byPair.remove(key(r.a, r.b));
                save();
            }
            case "political" -> {
                // Force default gov/econ from settings? Use winner's types as pressure: set loser's gov/econ to winner's
                GovernmentDef g = plugin.reg().government(winner.govId);
                EconomyDef e = plugin.reg().economy(winner.econId);
                if (g != null) {
                    loser.govId = g.id;
                    plugin.governance().applyGovernment(loser, g);
                }
                if (e != null) loser.econId = e.id;
                if (winner.leader != null) plugin.governance().setLeader(loser, winner.leader);
                r.state = State.TRUCE;
                r.truceUntil = System.currentTimeMillis() + plugin.reg().settings.truceMaxHours * 3_600_000L;
                r.warScore = 0;
                r.warGoal = "none";
                r.aggressor = null;
                plugin.towns().save(loser);
                broadcast(winner, loser, "&ePolitical victory: " + loser.name + " government/economy reshaped by " + winner.name);
                save();
            }
            case "raid" -> {
                double rp = loser.points * 0.5;
                double mon = loser.money * 0.5;
                loser.points -= rp;
                loser.money -= mon;
                winner.points += rp;
                winner.money += mon;
                plugin.finance().record(loser, null, "RAID", "POINTS", -rp, "Raided by " + winner.name);
                plugin.finance().record(winner, null, "RAID", "POINTS", rp, "Raided " + loser.name);
                plugin.towns().save(loser);
                plugin.towns().save(winner);
                r.state = State.TRUCE;
                r.truceUntil = System.currentTimeMillis() + plugin.reg().settings.truceMinHours * 3_600_000L;
                r.warScore = 0;
                r.warGoal = "none";
                r.aggressor = null;
                broadcast(winner, loser, "&6Raid complete: " + winner.name + " took 50% of " + loser.name + "'s stores");
                save();
            }
            case "revolt" -> {
                // Tributary breaks free, or civil-war style if opposition involved
                Town opposition = isOpposition(winner) ? winner : (isOpposition(loser) ? loser : null);
                if (opposition != null) {
                    Town loyal = parentOf(opposition);
                    if (loyal != null && winner.id.equals(opposition.id)) {
                        for (UUID u : new ArrayList<>(opposition.members.keySet())) {
                            if (!loyal.members.containsKey(u))
                                plugin.towns().addMember(loyal, u, plugin.reg().government(loyal.govId).defaultRole);
                        }
                        plugin.governance().setLeader(loyal, opposition.leader);
                        broadcast(loyal, opposition, "&aRevolt succeeded.");
                        plugin.towns().disband(opposition);
                    } else if (loyal != null) {
                        broadcast(loyal, opposition, "&cRevolt crushed.");
                        plugin.towns().disband(opposition);
                    }
                    byPair.remove(key(r.a, r.b));
                    save();
                } else {
                    Relation over = get(winner, loser);
                    if (over.overlord != null && over.overlord.equals(loser.id)) {
                        over.state = State.NEUTRAL;
                        over.overlord = null;
                        over.tributeRate = 0;
                    }
                    r.state = State.NEUTRAL;
                    r.warScore = 0;
                    r.warGoal = "none";
                    r.aggressor = null;
                    broadcast(winner, loser, "&a" + winner.name + " won independence from " + loser.name);
                    save();
                }
            }
            case "revolution" -> {
                Town opposition = isOpposition(winner) ? winner : (isOpposition(loser) ? loser : null);
                Town loyal = opposition == null ? null : parentOf(opposition);
                if (opposition != null && loyal != null) {
                    if (winner.id.equals(opposition.id)) {
                        for (UUID u : new ArrayList<>(opposition.members.keySet())) {
                            if (!loyal.members.containsKey(u))
                                plugin.towns().addMember(loyal, u, plugin.reg().government(loyal.govId).defaultRole);
                        }
                        plugin.governance().setLeader(loyal, opposition.leader);
                        broadcast(loyal, opposition, "&aRevolution succeeded. &f" + nameOf(opposition.leader) + " &arules " + loyal.name);
                        plugin.towns().disband(opposition);
                    } else {
                        broadcast(loyal, opposition, "&cRevolution failed. Opposition disbanded.");
                        plugin.towns().disband(opposition);
                    }
                    byPair.remove(key(r.a, r.b));
                    save();
                } else {
                    r.state = State.NEUTRAL;
                    r.warScore = 0;
                    r.warGoal = "none";
                    r.aggressor = null;
                    save();
                }
            }
            default -> {
                r.state = State.TRUCE;
                r.truceUntil = System.currentTimeMillis() + plugin.reg().settings.truceMinHours * 3_600_000L;
                r.warScore = 0;
                r.warGoal = "none";
                r.aggressor = null;
                broadcast(winner, loser, "&7War between " + winner.name + " and " + loser.name + " ended (no goal)");
                save();
            }
        }
    }

    // ------------------------------------------------------------------ tick: truce expiry + tribute

    @Override
    public void run() {
        if (!enabled()) return;
        tick++;
        long now = System.currentTimeMillis();
        boolean dirty = false;
        for (Relation r : new ArrayList<>(byPair.values())) {
            if (r.state == State.TRUCE && r.truceUntil > 0 && now >= r.truceUntil) {
                r.state = State.NEUTRAL;
                r.truceUntil = 0;
                dirty = true;
            }
        }
        // Tribute every 60s of plugin tick if this runs every second
        if (tick % 60 == 0) {
            for (Relation r : byPair.values()) {
                if (r.state != State.TRIBUTARY && r.state != State.SETTLEMENT) continue;
                if (r.overlord == null || r.tributeRate <= 0) continue;
                Town subject = plugin.towns().byId(r.other(r.overlord));
                Town over = plugin.towns().byId(r.overlord);
                if (subject == null || over == null) continue;
                // approximate tax interval skim: take rate of 1% of current points/money stores per minute as soft tribute
                double rp = subject.points * r.tributeRate * 0.01;
                double mon = subject.money * r.tributeRate * 0.01;
                if (rp > 0) {
                    subject.points = Math.max(0, subject.points - rp);
                    over.points += rp;
                }
                if (mon > 0) {
                    subject.money = Math.max(0, subject.money - mon);
                    over.money += mon;
                }
                if (rp > 0 || mon > 0) {
                    plugin.towns().markTownDirty(subject);
                    plugin.towns().markTownDirty(over);
                }
            }
        }
        if (dirty) save();
    }


    // ------------------------------------------------------------------ civil war / revolt / revolution

    public boolean isOpposition(Town t) {
        return t != null && t.shadowOf != null;
    }

    public Town parentOf(Town opposition) {
        return opposition == null || opposition.shadowOf == null ? null : plugin.towns().byId(opposition.shadowOf);
    }

    /**
     * Start an internal civil war: creates an opposition "shadow" town (no core), moves the declarer,
     * Internal civil war only (revolution goal). Creates opposition shadow town.
     */
    /**
     * Tributary/settlement breakaway: war on overlord with goal revolt.
     * Does not create a shadow town.
     */
    public String startRevolt(Player p, Town subject) {
        if (!enabled()) return "Diplomacy is disabled.";
        if (subject == null) return "No civilization.";
        if (isOpposition(subject)) return "Opposition forces use civil war tools, not revolt.";
        if (!subject.can(p.getUniqueId(), dev.ages.model.Perm.DECLARE_WAR)
                && !subject.can(p.getUniqueId(), dev.ages.model.Perm.CHANGE_SETTINGS)
                && !subject.can(p.getUniqueId(), dev.ages.model.Perm.MANAGE_DIPLOMACY))
            return "Your role cannot declare a revolt.";
        Town overlord = null;
        for (Relation r : of(subject)) {
            if ((r.state == State.TRIBUTARY || r.state == State.SETTLEMENT)
                    && r.overlord != null && !r.overlord.equals(subject.id)) {
                overlord = plugin.towns().byId(r.overlord);
                break;
            }
        }
        if (overlord == null) return "You are not a tributary or settlement of anyone.";
        return declareWar(p, subject, overlord, "revolt");
    }

    public String startCivilWar(Player p, Town parent, String goal) {
        if (!enabled()) return "Diplomacy is disabled.";
        if (parent == null) return "No civilization.";
        if (isOpposition(parent)) return "Already an opposition force.";
        if (parent.members.size() < 2) return "Need at least two members for a civil war.";
        UUID uid = p.getUniqueId();
        if (!parent.members.containsKey(uid)) return "You are not a member.";
        for (Town o : plugin.towns().all()) {
            if (parent.id.equals(o.shadowOf) && atWar(parent, o)) return "A civil war is already underway.";
        }
        String g = "revolution"; // internal only — use startRevolt for tributary breakaway

        String oppName = "Rebels of " + parent.name;
        int n = 2;
        while (plugin.towns().byName(oppName) != null) {
            oppName = "Rebels of " + parent.name + " " + (n++);
        }
        Town opp = new Town(UUID.randomUUID(), oppName, parent.ageId, parent.center, System.currentTimeMillis());
        opp.core = parent.core;
        opp.shadowOf = parent.id;
        opp.owner = uid;
        opp.leader = uid;
        opp.govId = parent.govId != null ? parent.govId : plugin.reg().settings.defaultGovernment;
        opp.econId = parent.econId != null ? parent.econId : plugin.reg().settings.defaultEconomy;
        plugin.governance().applyGovernment(opp, plugin.reg().government(opp.govId));

        plugin.towns().removeMember(parent, uid, true);
        opp.members.put(uid, plugin.reg().government(opp.govId).leaderRole);
        opp.leader = uid;
        opp.owner = uid;
        plugin.towns().registerExisting(opp);

        Relation r = get(parent, opp);
        r.state = State.WAR;
        r.aggressor = opp.id;
        r.warGoal = g;
        r.warScore = 0;
        r.since = System.currentTimeMillis();
        normalize(r, opp, State.WAR, g);
        warLog(p, opp, parent, "civil war started (" + g + ")");
        broadcast(parent, opp, "&cCivil war: &f" + p.getName() + " &cleads &f" + opp.name + " &cagainst &f" + parent.name);
        save();
        return null;
    }

    /** A member of the parent (or already free) joins the opposition side. */
    public String joinOpposition(Player p, Town parent) {
        UUID uid = p.getUniqueId();
        Town opp = null;
        for (Town o : plugin.towns().all()) {
            if (parent.id.equals(o.shadowOf) && atWar(parent, o)) { opp = o; break; }
        }
        if (opp == null) return "There is no active civil war for that civilization.";
        if (opp.members.containsKey(uid)) return "You are already on the opposition.";
        if (!parent.members.containsKey(uid)) return "You must be a member of the loyalists to defect.";
        if (parent.isOwner(uid)) return "The technical owner cannot defect; transfer ownership first.";
        plugin.towns().removeMember(parent, uid, true);
        String def = plugin.reg().government(opp.govId).defaultRole;
        plugin.towns().addMember(opp, uid, def);
        broadcast(parent, opp, "&e" + p.getName() + " &7joined the opposition (&f" + opp.name + "&7).");
        return null;
    }

    /** War-score helper for PvP kills between warring civs. */
    public void onPlayerKill(Player killer, Player victim) {
        if (killer == null || victim == null) return;
        Town ak = plugin.towns().of(killer.getUniqueId());
        Town av = plugin.towns().of(victim.getUniqueId());
        if (ak == null || av == null || !atWar(ak, av)) return;
        int pts = 15;
        // Leader kill
        if (victim.getUniqueId().equals(av.leader)) pts = 40;
        addWarScore(ak, av, pts);
        warLog(killer, ak, av, "kill +" + pts + " (" + victim.getName() + ")");
    }

    /** Extra score when opposition disables a loyalist building (core structure hit). */
    public void onBuildingDisabled(Town ownerOfBuilding, PlacedBuilding pb, Town byAttacker) {
        if (ownerOfBuilding == null || byAttacker == null) return;
        if (!atWar(ownerOfBuilding, byAttacker)) return;
        int pts = 25;
        if (isOpposition(byAttacker) && ownerOfBuilding.id.equals(byAttacker.shadowOf)) {
            pts = 60; // large bonus for rebels disabling loyalist buildings
        }
        addWarScore(byAttacker, ownerOfBuilding, pts);
        warLog(null, byAttacker, ownerOfBuilding, "building disabled +" + pts);
    }

    private static String nameOf(UUID u) {
        if (u == null) return "?";
        var op = Bukkit.getOfflinePlayer(u);
        return op.getName() != null ? op.getName() : u.toString().substring(0, 8);
    }

    private void broadcast(Town a, Town b, String msg) {
        for (UUID u : a.members.keySet()) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) Text.msg(p, msg);
        }
        for (UUID u : b.members.keySet()) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) Text.msg(p, msg);
        }
    }

    private void log(Player actor, Town from, Town to, String msg) {
        String line = System.currentTimeMillis() + "|" + (actor != null ? actor.getName() : "-")
                + "|" + from.name + "|" + to.name + "|" + msg;
        log.add(0, line);
        int keep = Math.max(50, plugin.reg().settings.diplomacyLogRetentionDays * 5);
        while (log.size() > keep) log.remove(log.size() - 1);
    }

    public List<String> recentLog(int n) {
        return log.subList(0, Math.min(n, log.size()));
    }

    public void load() {
        byPair.clear();
        log.clear();
        File f = new File(plugin.getDataFolder(), "diplomacy.yml");
        if (!f.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        for (String k : y.getKeys(false)) {
            if (k.equals("log") || k.equals("war_log") || k.equals("proposals")) continue;
            if (!y.isConfigurationSection(k) && y.get(k + ".a") == null) continue;
            try {
                UUID a = UUID.fromString(y.getString(k + ".a"));
                UUID b = UUID.fromString(y.getString(k + ".b"));
                Relation r = new Relation(a, b);
                r.state = State.valueOf(y.getString(k + ".state", "NEUTRAL"));
                String ov = y.getString(k + ".overlord");
                if (ov != null) r.overlord = UUID.fromString(ov);
                String ag = y.getString(k + ".aggressor");
                if (ag != null) r.aggressor = UUID.fromString(ag);
                r.warGoal = y.getString(k + ".war_goal", "none");
                r.warScore = y.getInt(k + ".war_score", 0);
                r.since = y.getLong(k + ".since", System.currentTimeMillis());
                r.truceUntil = y.getLong(k + ".truce_until", 0);
                r.allianceId = y.getString(k + ".alliance_id");
                r.tributeRate = y.getDouble(k + ".tribute_rate", 0);
                byPair.put(key(a, b), r);
            } catch (Exception ex) {
                plugin.getLogger().warning("Bad diplomacy entry " + k + ": " + ex.getMessage());
            }
        }
        for (String line : y.getStringList("log")) log.add(line);
        for (String line : y.getStringList("war_log")) warLog.add(line);
        if (y.getConfigurationSection("proposals") != null) {
            for (String pk : y.getConfigurationSection("proposals").getKeys(false)) {
                proposals.put(pk.replace("_", ":"), y.getString("proposals." + pk));
            }
        }
        plugin.getLogger().info("Diplomacy: loaded " + byPair.size() + " relation(s).");
    }

    public void save() {
        File f = new File(plugin.getDataFolder(), "diplomacy.yml");
        YamlConfiguration y = new YamlConfiguration();
        int i = 0;
        for (Relation r : byPair.values()) {
            if (r.state == State.NEUTRAL && r.warScore == 0 && r.allianceId == null) continue;
            String k = "r" + (i++);
            y.set(k + ".a", r.a.toString());
            y.set(k + ".b", r.b.toString());
            y.set(k + ".state", r.state.name());
            if (r.overlord != null) y.set(k + ".overlord", r.overlord.toString());
            if (r.aggressor != null) y.set(k + ".aggressor", r.aggressor.toString());
            y.set(k + ".war_goal", r.warGoal);
            y.set(k + ".war_score", r.warScore);
            y.set(k + ".since", r.since);
            y.set(k + ".truce_until", r.truceUntil);
            if (r.allianceId != null) y.set(k + ".alliance_id", r.allianceId);
            y.set(k + ".tribute_rate", r.tributeRate);
        }
        y.set("log", log.size() > 200 ? log.subList(0, 200) : log);
        y.set("war_log", warLog.size() > 200 ? warLog.subList(0, 200) : warLog);
        for (var e : proposals.entrySet()) y.set("proposals." + e.getKey().replace(":", "_"), e.getValue());
        try {
            y.save(f);
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Could not save diplomacy.yml", e);
        }
    }
}
