package dev.ages.util;

import org.bukkit.Bukkit;

/**
 * Runtime environment facts. Ages stays on the Bukkit/Paper API only (no NMS),
 * so most version bumps only need material/entity alias updates and a recompile
 * against a newer paper-api.
 */
public final class ServerCompat {
    private static String mcVersion = "?";
    private static int dataVersion = -1;
    private static boolean paper;

    private ServerCompat() {}

    public static void init() {
        try {
            mcVersion = Bukkit.getMinecraftVersion();
        } catch (Throwable t) {
            try { mcVersion = Bukkit.getBukkitVersion(); } catch (Throwable ignored) {}
        }
        try {
            // Paper exposes getUnsafe / data version indirectly via Bukkit
            dataVersion = Bukkit.getUnsafe().getDataVersion();
        } catch (Throwable ignored) {
            dataVersion = -1;
        }
        try {
            Class.forName("io.papermc.paper.configuration.Configuration");
            paper = true;
        } catch (Throwable t) {
            paper = Bukkit.getName().toLowerCase().contains("paper")
                    || Bukkit.getVersion().toLowerCase().contains("paper");
        }
    }

    public static String minecraftVersion() { return mcVersion; }
    public static int dataVersion() { return dataVersion; }
    public static boolean isPaper() { return paper; }

    public static String summary() {
        return "MC " + mcVersion + (dataVersion > 0 ? " (data " + dataVersion + ")" : "")
                + (paper ? " Paper" : " " + Bukkit.getName());
    }
}
