package dev.ages.util;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Tag;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Resolves material names from config in a version-tolerant way.
 * Prefer this over {@link Material#valueOf} — that throws when Mojang renames items.
 */
public final class Materials {
    private static final Map<String, String> ALIASES = new HashMap<>();
    private static Logger log;

    static {
        // Historical renames (1.20+) and common config mistakes
        alias("GRASS", "SHORT_GRASS");
        alias("GRASS_PATH", "DIRT_PATH");
        alias("SIGN", "OAK_SIGN");
        alias("WALL_SIGN", "OAK_WALL_SIGN");
        alias("WORKBENCH", "CRAFTING_TABLE");
        alias("PISTON_BASE", "PISTON");
        alias("PISTON_STICKY_BASE", "STICKY_PISTON");
        alias("SULPHUR", "GUNPOWDER");
        alias("SULFUR", "GUNPOWDER");
        alias("WOOD_SWORD", "WOODEN_SWORD");
        alias("WOOD_PICKAXE", "WOODEN_PICKAXE");
        alias("WOOD_AXE", "WOODEN_AXE");
        alias("WOOD_HOE", "WOODEN_HOE");
        alias("WOOD_SPADE", "WOODEN_SHOVEL");
        alias("WOOD_SHOVEL", "WOODEN_SHOVEL");
        alias("IRON_SPADE", "IRON_SHOVEL");
        alias("STONE_SPADE", "STONE_SHOVEL");
        alias("GOLD_SWORD", "GOLDEN_SWORD");
        alias("GOLD_PICKAXE", "GOLDEN_PICKAXE");
        alias("GOLD_AXE", "GOLDEN_AXE");
        alias("GOLD_HOE", "GOLDEN_HOE");
        alias("GOLD_SPADE", "GOLDEN_SHOVEL");
        alias("GOLD_SHOVEL", "GOLDEN_SHOVEL");
        alias("GOLD_HELMET", "GOLDEN_HELMET");
        alias("GOLD_CHESTPLATE", "GOLDEN_CHESTPLATE");
        alias("GOLD_LEGGINGS", "GOLDEN_LEGGINGS");
        alias("GOLD_BOOTS", "GOLDEN_BOOTS");
        alias("GOLD_INGOT", "GOLD_INGOT");
        alias("COMMAND", "COMMAND_BLOCK");
        alias("WATCH", "CLOCK");
        alias("CARPET", "WHITE_CARPET");
        alias("WOOL", "WHITE_WOOL");
        alias("STAINED_GLASS", "WHITE_STAINED_GLASS");
        alias("THIN_GLASS", "GLASS_PANE");
        alias("PORTAL", "NETHER_PORTAL");
        alias("FIREBALL", "FIRE_CHARGE");
        alias("SKULL_ITEM", "PLAYER_HEAD");
        alias("SKULL", "SKELETON_SKULL");
        alias("EXP_BOTTLE", "EXPERIENCE_BOTTLE");
        alias("BREWING_STAND_ITEM", "BREWING_STAND");
        alias("CAULDRON_ITEM", "CAULDRON");
        alias("SPECKLED_MELON", "GLISTERING_MELON_SLICE");
        alias("RAW_FISH", "COD");
        alias("COOKED_FISH", "COOKED_COD");
        alias("FISHING_ROD", "FISHING_ROD");
        alias("MUSHROOM_SOUP", "MUSHROOM_STEW");
        alias("SNOW_BALL", "SNOWBALL");
        alias("STORAGE_MINECART", "CHEST_MINECART");
        alias("POWERED_MINECART", "FURNACE_MINECART");
        alias("EXPLOSIVE_MINECART", "TNT_MINECART");
        alias("HOPPER_MINECART", "HOPPER_MINECART");
        alias("REDSTONE_COMPARATOR", "COMPARATOR");
        alias("DIODE", "REPEATER");
        alias("IRON_FENCE", "IRON_BARS");
        alias("FENCE", "OAK_FENCE");
        alias("FENCE_GATE", "OAK_FENCE_GATE");
        alias("WOOD_STEP", "OAK_SLAB");
        alias("WOOD_DOUBLE_STEP", "OAK_SLAB");
        alias("STEP", "SMOOTH_STONE_SLAB");
        alias("LOG", "OAK_LOG");
        alias("LOG_2", "ACACIA_LOG");
        alias("LEAVES", "OAK_LEAVES");
        alias("LEAVES_2", "ACACIA_LEAVES");
        alias("SAPLING", "OAK_SAPLING");
        alias("WATER_LILY", "LILY_PAD");
        alias("CROPS", "WHEAT");
        alias("SOIL", "FARMLAND");
        alias("BED", "RED_BED");
        alias("ENDER_PORTAL_FRAME", "END_PORTAL_FRAME");
        alias("ENDER_PORTAL", "END_PORTAL");
        alias("ENDER_STONE", "END_STONE");
        alias("NETHER_WARTS", "NETHER_WART");
        alias("NETHER_FENCE", "NETHER_BRICK_FENCE");
        alias("SMOOTH_BRICK", "STONE_BRICKS");
        alias("SMOOTH_STAIRS", "STONE_BRICK_STAIRS");
        alias("BRICK_STAIRS", "BRICK_STAIRS");
        alias("COBBLE_WALL", "COBBLESTONE_WALL");
        alias("COBBLESTONE_WALL", "COBBLESTONE_WALL");
        alias("WOOD_DOOR", "OAK_DOOR");
        alias("IRON_DOOR_BLOCK", "IRON_DOOR");
        alias("TRAP_DOOR", "OAK_TRAPDOOR");
        alias("BOAT", "OAK_BOAT");
        alias("BANNER", "WHITE_BANNER");
        alias("STANDING_BANNER", "WHITE_BANNER");
        alias("WALL_BANNER", "WHITE_WALL_BANNER");
        // 1.21+ style ids sometimes written without underscore consistency
        alias("CRAFTINGTABLE", "CRAFTING_TABLE");
        alias("ENCHANTINGTABLE", "ENCHANTING_TABLE");
    }

    private Materials() {}

    public static void init(Logger logger) {
        log = logger;
    }

    /** Load optional plugins/Ages/materials-aliases.yml (OLD: NEW). Safe no-op if missing. */
    public static void loadExtraAliases(java.io.File file) {
        if (file == null || !file.isFile()) return;
        try {
            org.bukkit.configuration.file.YamlConfiguration y =
                    org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(file);
            int n = 0;
            for (String k : y.getKeys(false)) {
                String v = y.getString(k);
                if (v == null || v.isBlank()) continue;
                alias(k, v);
                n++;
            }
            if (log != null && n > 0) log.info("Loaded " + n + " material alias(es) from " + file.getName());
        } catch (Throwable t) {
            if (log != null) log.warning("Could not read material aliases: " + t.getMessage());
        }
    }

    private static void alias(String from, String to) {
        ALIASES.put(from.toUpperCase(Locale.ROOT), to.toUpperCase(Locale.ROOT));
    }

    /**
     * Resolve a material name from YAML/config.
     * Tries: exact matchMaterial → alias → matchMaterial again → null.
     */
    public static Material match(String name) {
        if (name == null || name.isBlank()) return null;
        String raw = name.trim();
        Material m = Material.matchMaterial(raw);
        if (m != null) return m;
        String upper = raw.toUpperCase(Locale.ROOT).replace(' ', '_').replace('-', '_');
        m = Material.matchMaterial(upper);
        if (m != null) return m;
        String mapped = ALIASES.get(upper);
        if (mapped != null) {
            m = Material.matchMaterial(mapped);
            if (m != null) return m;
        }
        // Last resort: strip minecraft: namespace
        if (upper.startsWith("MINECRAFT:")) {
            m = Material.matchMaterial(upper.substring("MINECRAFT:".length()));
            if (m != null) return m;
        }
        return null;
    }

    /** Like match, but logs once when unknown (does not throw). */
    public static Material matchOrWarn(String name, String context) {
        Material m = match(name);
        if (m == null && log != null) {
            log.warning("Unknown material '" + name + "'" + (context != null ? " (" + context + ")" : "")
                    + " on " + Bukkit.getMinecraftVersion() + " — entry skipped. Update the name or add an alias.");
        }
        return m;
    }

    public static boolean isItem(Material m) {
        return m != null && m.isItem();
    }

    public static boolean isBlock(Material m) {
        return m != null && m.isBlock();
    }

    /** Safe tag check — false if the tag key is unknown on this version. */
    public static boolean isTagged(Material m, Tag<Material> tag) {
        try {
            return m != null && tag != null && tag.isTagged(m);
        } catch (Throwable t) {
            return false;
        }
    }
}
