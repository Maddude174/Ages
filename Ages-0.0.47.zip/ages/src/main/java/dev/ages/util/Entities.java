package dev.ages.util;

import org.bukkit.entity.EntityType;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

/** Version-tolerant entity type resolution for config (spawners, etc.). */
public final class Entities {
    private static final Map<String, String> ALIASES = new HashMap<>();
    private static Logger log;

    static {
        alias("PIG_ZOMBIE", "ZOMBIFIED_PIGLIN");
        alias("ZOMBIE_PIGMAN", "ZOMBIFIED_PIGLIN");
        alias("ENDERMAN", "ENDERMAN");
        alias("MUSHROOM_COW", "MOOSHROOM");
        alias("SNOWMAN", "SNOW_GOLEM");
        alias("VILLAGER_GOLEM", "IRON_GOLEM");
    }

    private Entities() {}

    public static void init(Logger logger) { log = logger; }

    private static void alias(String from, String to) {
        ALIASES.put(from.toUpperCase(Locale.ROOT), to.toUpperCase(Locale.ROOT));
    }

    public static EntityType match(String name) {
        if (name == null || name.isBlank()) return null;
        String upper = name.trim().toUpperCase(Locale.ROOT).replace(' ', '_').replace('-', '_');
        if (upper.startsWith("MINECRAFT:")) upper = upper.substring("MINECRAFT:".length());
        try {
            return EntityType.valueOf(upper);
        } catch (IllegalArgumentException ignored) {}
        String mapped = ALIASES.get(upper);
        if (mapped != null) {
            try { return EntityType.valueOf(mapped); } catch (IllegalArgumentException ignored) {}
        }
        // Enum names sometimes differ from key - try fromName if available
        try {
            EntityType byName = EntityType.fromName(upper.toLowerCase(Locale.ROOT));
            if (byName != null) return byName;
        } catch (Throwable ignored) {}
        return null;
    }

    public static EntityType matchOrWarn(String name, String context) {
        EntityType t = match(name);
        if (t == null && log != null) {
            log.warning("Unknown entity '" + name + "'" + (context != null ? " (" + context + ")" : "")
                    + " — entry skipped.");
        }
        return t;
    }
}
