package dev.ages.hook;

import dev.ages.AgesPlugin;
import dev.ages.config.BuildingDef;
import dev.ages.config.Registries;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Relation;
import dev.ages.model.Town;
import dev.ages.util.ServerCompat;
import org.bstats.bukkit.Metrics;
import org.bstats.charts.AdvancedPie;
import org.bstats.charts.DrilldownPie;
import org.bstats.charts.MultiLineChart;
import org.bstats.charts.SimpleBarChart;
import org.bstats.charts.SimplePie;
import org.bstats.charts.SingleLineChart;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Full bStats integration for Ages.
 * <p>
 * Only anonymous aggregates are submitted (counts and category labels). No player names,
 * UUIDs, civilization names, or coordinates.
 * <p>
 * Register the plugin at <a href="https://bstats.org/add-plugin">bstats.org</a> and set
 * {@link #PLUGIN_ID} to the id they assign. Global opt-out: {@code plugins/bStats/config.yml}.
 * Per-plugin toggle: {@code settings.yml → metrics.enabled}.
 */
public final class MetricsHook {
    /**
     * Replace with your bStats plugin id after registering at https://bstats.org/add-plugin
     */
    public static final int PLUGIN_ID = 35023;

    private static Metrics metrics;

    private MetricsHook() {}

    public static void start(AgesPlugin plugin) {
        if (metrics != null) return; // already started this session
        if (plugin.reg() == null || !plugin.reg().settings.metricsEnabled) {
            plugin.getLogger().info("Metrics disabled (settings.yml metrics.enabled: false).");
            return;
        }
        try {
            metrics = new Metrics(plugin, PLUGIN_ID);
            registerCharts(plugin, metrics);
            plugin.getLogger().info("bStats metrics started (id " + PLUGIN_ID + ").");
        } catch (Throwable t) {
            metrics = null;
            plugin.getLogger().warning("bStats failed to start: " + t.getMessage());
        }
    }

    private static void registerCharts(AgesPlugin plugin, Metrics m) {
        // ===== Environment =====
        m.addCustomChart(new SimplePie("plugin_version", () -> {
            String v = plugin.getDescription().getVersion();
            return v == null || v.isBlank() ? "unknown" : v;
        }));
        m.addCustomChart(new SimplePie("minecraft_version", () -> majorMinor(ServerCompat.minecraftVersion())));
        m.addCustomChart(new SimplePie("server_software", () ->
                ServerCompat.isPaper() ? "Paper" : safe(() -> plugin.getServer().getName(), "Unknown")));
        m.addCustomChart(new SimplePie("java_version", () -> {
            String v = System.getProperty("java.specification.version", "?");
            return v.startsWith("1.") ? v.substring(2) : v;
        }));

        // ===== Soft-depends (installed on this server) =====
        m.addCustomChart(new AdvancedPie("soft_depends_installed", () -> {
            Map<String, Integer> out = new LinkedHashMap<>();
            putIfPresent(out, plugin, "Vault");
            putIfPresent(out, plugin, "WorldGuard");
            putIfPresent(out, plugin, "dynmap");
            putIfPresent(out, plugin, "BlueMap");
            putIfPresent(out, plugin, "PlaceholderAPI");
            if (out.isEmpty()) out.put("none", 1);
            return out;
        }));

        // ===== Scale =====
        m.addCustomChart(new SingleLineChart("civilizations", () -> civCount(plugin)));
        m.addCustomChart(new SingleLineChart("civ_members_total", () -> {
            int n = 0;
            for (Town t : civs(plugin)) n += t.members.size();
            return n;
        }));
        m.addCustomChart(new SingleLineChart("buildings_total", () -> {
            int n = 0;
            for (Town t : civs(plugin)) n += t.buildings.size();
            return n;
        }));
        m.addCustomChart(new SingleLineChart("buildings_disabled", () -> {
            int n = 0;
            for (Town t : civs(plugin))
                for (PlacedBuilding b : t.buildings) if (b.damaged) n++;
            return n;
        }));
        m.addCustomChart(new SingleLineChart("online_civ_members", () -> {
            int n = 0;
            for (Town t : civs(plugin))
                for (var u : t.members.keySet())
                    if (plugin.getServer().getPlayer(u) != null) n++;
            return n;
        }));

        m.addCustomChart(new MultiLineChart("server_scale", () -> {
            Map<String, Integer> map = new LinkedHashMap<>();
            map.put("civilizations", civCount(plugin));
            int buildings = 0, members = 0;
            for (Town t : civs(plugin)) {
                buildings += t.buildings.size();
                members += t.members.size();
            }
            map.put("buildings", buildings);
            map.put("members", members);
            map.put("wars", warCount(plugin));
            return map;
        }));

        // ===== Distributions =====
        m.addCustomChart(new AdvancedPie("ages", () -> countBy(plugin, t -> label(t.ageId))));
        m.addCustomChart(new AdvancedPie("governments", () -> countBy(plugin, t -> label(t.govId))));
        m.addCustomChart(new AdvancedPie("economies", () -> countBy(plugin, t -> label(t.econId))));

        m.addCustomChart(new SimpleBarChart("civs_per_age", () -> countBy(plugin, t -> label(t.ageId))));

        m.addCustomChart(new AdvancedPie("building_categories", () -> {
            Map<String, Integer> map = new HashMap<>();
            Registries reg = plugin.reg();
            if (reg == null) return map;
            for (Town t : civs(plugin)) {
                for (PlacedBuilding b : t.buildings) {
                    BuildingDef d = reg.building(b.defId);
                    String cat = d == null || blank(d.category) ? "other" : d.category.toLowerCase();
                    map.merge(cat, 1, Integer::sum);
                }
            }
            return map;
        }));

        // Top building types (capped labels only — ids, not display names with colors)
        m.addCustomChart(new AdvancedPie("building_types_top", () -> {
            Map<String, Integer> raw = new HashMap<>();
            for (Town t : civs(plugin))
                for (PlacedBuilding b : t.buildings)
                    raw.merge(label(b.defId), 1, Integer::sum);
            return topEntries(raw, 15);
        }));

        // Age × government drilldown
        m.addCustomChart(new DrilldownPie("age_by_government", () -> {
            Map<String, Map<String, Integer>> root = new HashMap<>();
            for (Town t : civs(plugin)) {
                String age = label(t.ageId);
                String gov = label(t.govId);
                root.computeIfAbsent(age, k -> new HashMap<>()).merge(gov, 1, Integer::sum);
            }
            return root;
        }));

        // ===== Diplomacy =====
        m.addCustomChart(new SingleLineChart("wars_active", () -> warCount(plugin)));
        m.addCustomChart(new SingleLineChart("alliances_active", () -> {
            if (plugin.diplomacy() == null) return 0;
            int n = 0;
            for (Relation r : plugin.diplomacy().all()) {
                if (r.state == Relation.State.ALLIED || r.state == Relation.State.ALLIED_DEFENSIVE) n++;
            }
            return n;
        }));
        m.addCustomChart(new AdvancedPie("relation_states", () -> {
            Map<String, Integer> map = new HashMap<>();
            if (plugin.diplomacy() == null) return map;
            for (Relation r : plugin.diplomacy().all()) {
                if (r.state == Relation.State.NEUTRAL) continue;
                map.merge(r.state.name(), 1, Integer::sum);
            }
            if (map.isEmpty()) map.put("none_active", 1);
            return map;
        }));
        m.addCustomChart(new AdvancedPie("war_goals", () -> {
            Map<String, Integer> map = new HashMap<>();
            if (plugin.diplomacy() == null) return map;
            for (Relation r : plugin.diplomacy().all()) {
                if (r.state != Relation.State.WAR) continue;
                String g = r.warGoal == null || r.warGoal.isBlank() ? "none" : r.warGoal.toLowerCase();
                map.merge(g, 1, Integer::sum);
            }
            if (map.isEmpty()) map.put("no_wars", 1);
            return map;
        }));

        // ===== Policies in use (across all civs) =====
        m.addCustomChart(new AdvancedPie("active_policies", () -> {
            Map<String, Integer> map = new HashMap<>();
            for (Town t : civs(plugin))
                for (String pol : t.policies)
                    map.merge(label(pol), 1, Integer::sum);
            if (map.isEmpty()) map.put("none", 1);
            return topEntries(map, 20);
        }));

        // ===== Feature flags =====
        m.addCustomChart(new SimplePie("diplomacy_enabled", () -> flag(plugin, s -> s.diplomacyEnabled)));
        m.addCustomChart(new SimplePie("deny_creative_purchase", () -> flag(plugin, s -> s.denyCreativePurchase)));
        m.addCustomChart(new SimplePie("tnt_requires_online", () -> flag(plugin, s -> s.tntRequiresOnline)));
        m.addCustomChart(new SimplePie("conflict_scope", () ->
                plugin.reg() == null ? "unknown" : plugin.reg().settings.conflictScope));
        m.addCustomChart(new SimplePie("charge_style_sample", () -> {
            // Rough signal: whether any loaded economy charges civ by default
            if (plugin.reg() == null) return "unknown";
            int civ = 0, player = 0;
            for (var e : plugin.reg().economies.values()) {
                if (e.chargePurchasesToCiv) civ++;
                else player++;
            }
            if (civ == 0 && player == 0) return "none";
            if (civ > player) return "mostly_civ";
            if (player > civ) return "mostly_player";
            return "mixed";
        }));
    }

    // ------------------------------------------------------------------ helpers

    private static Iterable<Town> civs(AgesPlugin plugin) {
        if (plugin.towns() == null) return java.util.List.of();
        java.util.List<Town> list = new java.util.ArrayList<>();
        for (Town t : plugin.towns().all()) {
            if (t.shadowOf == null) list.add(t); // skip civil-war opposition shells
        }
        return list;
    }

    private static int civCount(AgesPlugin plugin) {
        int n = 0;
        for (Town ignored : civs(plugin)) n++;
        return n;
    }

    private static int warCount(AgesPlugin plugin) {
        if (plugin.diplomacy() == null) return 0;
        int n = 0;
        for (Relation r : plugin.diplomacy().all())
            if (r.state == Relation.State.WAR) n++;
        return n;
    }

    private static Map<String, Integer> countBy(AgesPlugin plugin, java.util.function.Function<Town, String> keyFn) {
        Map<String, Integer> map = new HashMap<>();
        for (Town t : civs(plugin)) map.merge(keyFn.apply(t), 1, Integer::sum);
        return map;
    }

    private static String label(String id) {
        return blank(id) ? "unknown" : id.toLowerCase();
    }

    private static boolean blank(String s) {
        return s == null || s.isBlank();
    }

    private static String flag(AgesPlugin plugin, java.util.function.Predicate<dev.ages.config.Settings> p) {
        if (plugin.reg() == null) return "unknown";
        return p.test(plugin.reg().settings) ? "yes" : "no";
    }

    private static void putIfPresent(Map<String, Integer> out, AgesPlugin plugin, String name) {
        if (plugin.getServer().getPluginManager().getPlugin(name) != null) out.put(name, 1);
    }

    private static String majorMinor(String v) {
        if (v == null || v.isBlank() || "?".equals(v)) return "unknown";
        // 1.21.8 -> 1.21.x
        int first = v.indexOf('.');
        if (first < 0) return v;
        int second = v.indexOf('.', first + 1);
        if (second < 0) return v;
        return v.substring(0, second) + ".x";
    }

    private static Map<String, Integer> topEntries(Map<String, Integer> raw, int limit) {
        return raw.entrySet().stream()
                .sorted((a, b) -> Integer.compare(b.getValue(), a.getValue()))
                .limit(limit)
                .collect(java.util.stream.Collectors.toMap(
                        Map.Entry::getKey, Map.Entry::getValue,
                        (a, b) -> a, LinkedHashMap::new));
    }

    private static String safe(java.util.concurrent.Callable<String> c, String def) {
        try {
            String s = c.call();
            return s == null || s.isBlank() ? def : s;
        } catch (Exception e) {
            return def;
        }
    }
}
