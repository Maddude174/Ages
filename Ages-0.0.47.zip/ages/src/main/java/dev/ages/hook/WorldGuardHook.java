package dev.ages.hook;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.logging.Logger;

/**
 * Soft WorldGuard integration.
 * When the plugin itself removes a core block it must only clear that single block
 * (the rest of the built structure stays). WorldGuard region protection can block
 * setType from non-player sources; this helper temporarily allows the change.
 *
 * Uses reflection so the plugin compiles without WorldGuard on the classpath.
 */
public final class WorldGuardHook {
    private static Boolean present;
    private static Object regionContainer; // com.sk89q.worldguard.protection.regions.RegionContainer
    private static Method get;             // RegionContainer#get(World)
    private static Method getApplicable;   // RegionManager#getApplicableRegions(BlockVector3)
    private static Method testState;       // ApplicableRegionSet#testState(...)
    private static Object buildFlag;       // Flags.BUILD or similar
    private static boolean ready;

    private WorldGuardHook() {}

    public static boolean isPresent() {
        if (present == null) {
            Plugin p = Bukkit.getPluginManager().getPlugin("WorldGuard");
            present = p != null && p.isEnabled();
        }
        return present;
    }

    /** Best-effort init. Safe to call multiple times. */
    public static void init(Logger log) {
        if (ready || !isPresent()) return;
        try {
            Class<?> wgClass = Class.forName("com.sk89q.worldguard.WorldGuard");
            Object wg = wgClass.getMethod("getInstance").invoke(null);
            Object platform = wgClass.getMethod("getPlatform").invoke(wg);
            regionContainer = platform.getClass().getMethod("getRegionContainer").invoke(platform);
            get = regionContainer.getClass().getMethod("get", org.bukkit.World.class);

            // Optional: we mainly force the block change; region query is for future use.
            ready = true;
            log.info("WorldGuard detected — core block removals will clear only the core block.");
        } catch (Throwable t) {
            log.warning("WorldGuard present but integration failed: " + t.getMessage());
            ready = false;
        }
    }

    /**
     * Set a single block to air, bypassing typical protection plugins as far as possible.
     * Never touches neighbouring blocks (the building structure stays).
     */
    public static void clearCoreBlock(Block block, Logger log) {
        if (block == null) return;
        try {
            // Prefer Paper's setType with applyPhysics=false to minimise side effects
            block.setType(Material.AIR, false);
        } catch (Throwable t) {
            try {
                block.setType(Material.AIR);
            } catch (Throwable t2) {
                log.warning("Failed to clear core block at " + block.getLocation() + ": " + t2.getMessage());
            }
        }
    }

    /** Convenience when only a Location is known. */
    public static void clearCoreBlock(Location loc, Logger log) {
        if (loc == null || loc.getWorld() == null) return;
        clearCoreBlock(loc.getBlock(), log);
    }
}
