package dev.ages.hook;

import dev.ages.AgesPlugin;
import dev.ages.config.AgeDef;
import dev.ages.config.EconomyDef;
import dev.ages.config.GovernmentDef;
import dev.ages.model.Rank;
import dev.ages.model.Town;
import dev.ages.util.Text;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.UUID;

/**
 * PlaceholderAPI expansion — identifier {@code ages}.
 *
 * <p>Player placeholders (use on a player):
 * <ul>
 *   <li>{@code %ages_town%} / {@code %ages_name%} — civilization name</li>
 *   <li>{@code %ages_tag%} — short tag for chat (name, or empty if none)</li>
 *   <li>{@code %ages_age%} — age display name (colours stripped)</li>
 *   <li>{@code %ages_age_id%} — age id</li>
 *   <li>{@code %ages_rank%} — rank title</li>
 *   <li>{@code %ages_rank_id%} — rank id/name key</li>
 *   <li>{@code %ages_leader%} — leader player name</li>
 *   <li>{@code %ages_owner%} — technical owner name</li>
 *   <li>{@code %ages_members%} — member count</li>
 *   <li>{@code %ages_buildings%} — building count</li>
 *   <li>{@code %ages_points%} — shared resource points</li>
 *   <li>{@code %ages_treasury%} / {@code %ages_money%} — treasury money</li>
 *   <li>{@code %ages_government%} / {@code %ages_gov%} — government display name</li>
 *   <li>{@code %ages_economy%} / {@code %ages_econ%} — economy display name</li>
 *   <li>{@code %ages_is_leader%} — yes/no</li>
 *   <li>{@code %ages_is_owner%} — yes/no</li>
 *   <li>{@code %ages_in_town%} — yes/no</li>
 *   <li>{@code %ages_has_town%} — alias of in_town</li>
 * </ul>
 *
 * <p>Location (online player only):
 * <ul>
 *   <li>{@code %ages_here_town%} — civ claiming the block the player stands on</li>
 *   <li>{@code %ages_here_age%} — that civ's age display name</li>
 * </ul>
 *
 * <p>Relational (online player):
 * <ul>
 *   <li>{@code %ages_is_member_<townName>%} — yes/no if player is in that civ</li>
 * </ul>
 */
public final class AgesExpansion extends PlaceholderExpansion {
    private final AgesPlugin plugin;

    public AgesExpansion(AgesPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        return "ages";
    }

    @Override
    public String getAuthor() {
        return String.join(", ", plugin.getDescription().getAuthors().isEmpty()
                ? java.util.List.of("Ages")
                : plugin.getDescription().getAuthors());
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true; // survive /papi reload
    }

    @Override
    public boolean canRegister() {
        return plugin.isEnabled();
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (params == null || params.isBlank()) return "";
        String key = params.toLowerCase(Locale.ROOT).trim();

        // No player context still allows a few globals later if needed
        Town town = player != null ? plugin.towns().of(player.getUniqueId()) : null;

        // Relational: is_member_<name>
        if (key.startsWith("is_member_")) {
            String name = params.substring("is_member_".length()).trim();
            if (player == null) return "no";
            Town target = plugin.towns().byName(name);
            if (target == null) return "no";
            return target.members.containsKey(player.getUniqueId()) ? "yes" : "no";
        }

        // Location-based (needs online player)
        if (key.startsWith("here_")) {
            if (!(player instanceof Player p) || !p.isOnline()) return "";
            Town here = plugin.towns().at(p.getLocation());
            return switch (key) {
                case "here_town", "here_name" -> here == null ? "" : here.name;
                case "here_age" -> here == null ? "" : ageName(here);
                case "here_age_id" -> here == null ? "" : nullToEmpty(here.ageId);
                default -> null;
            };
        }

        return switch (key) {
            case "town", "name", "civ", "civilization" -> town == null ? "" : town.name;
            case "tag" -> town == null ? "" : town.name; // chat-friendly; empty when none
            case "age" -> town == null ? "" : ageName(town);
            case "age_id" -> town == null ? "" : nullToEmpty(town.ageId);
            case "rank" -> rankTitle(town, player);
            case "rank_id" -> rankId(town, player);
            case "leader" -> playerName(town == null ? null : town.leader);
            case "owner" -> playerName(town == null ? null : town.owner);
            case "members", "member_count" -> town == null ? "0" : String.valueOf(town.members.size());
            case "buildings", "building_count" -> town == null ? "0" : String.valueOf(town.buildings.size());
            case "points" -> town == null ? "0" : Text.num(town.points);
            case "treasury", "money" -> town == null ? "0" : Text.num(town.money);
            case "government", "gov" -> town == null ? "" : govName(town);
            case "economy", "econ" -> town == null ? "" : econName(town);
            case "is_leader" -> yesNo(town != null && player != null && player.getUniqueId().equals(town.leader));
            case "is_owner" -> yesNo(town != null && player != null && player.getUniqueId().equals(town.owner));
            case "in_town", "has_town" -> yesNo(town != null);
            default -> null; // unknown → let PAPI show the raw placeholder
        };
    }

    private String ageName(Town t) {
        AgeDef a = plugin.reg().age(t.ageId);
        if (a == null) return nullToEmpty(t.ageId);
        return Text.plain(a.name);
    }

    private String govName(Town t) {
        if (t.govId == null || t.govId.isBlank()) return "";
        GovernmentDef g = plugin.reg().government(t.govId);
        if (g == null) return t.govId;
        return Text.plain(g.name != null ? g.name : t.govId);
    }

    private String econName(Town t) {
        if (t.econId == null || t.econId.isBlank()) return "";
        EconomyDef e = plugin.reg().economy(t.econId);
        if (e == null) return t.econId;
        return Text.plain(e.name != null ? e.name : t.econId);
    }

    private String rankTitle(Town town, OfflinePlayer player) {
        if (town == null || player == null) return "";
        Rank r = town.rankOf(player.getUniqueId());
        if (r == null) return "";
        String title = r.title != null && !r.title.isBlank() ? r.title : r.name;
        return Text.plain(title);
    }

    private String rankId(Town town, OfflinePlayer player) {
        if (town == null || player == null) return "";
        String id = town.members.get(player.getUniqueId());
        return id == null ? "" : id;
    }

    private static String playerName(UUID id) {
        if (id == null) return "";
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "" : n;
    }

    private static String yesNo(boolean v) { return v ? "yes" : "no"; }
    private static String nullToEmpty(String s) { return s == null ? "" : s; }
}
