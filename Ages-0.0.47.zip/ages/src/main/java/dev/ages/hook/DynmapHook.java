package dev.ages.hook;

import dev.ages.AgesPlugin;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Town;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Soft Dynmap integration: marker set {@code ages.towns} with a claim outline + core pin per civilization.
 * Reflection-only so Dynmap is not required at compile time.
 *
 * <p>Dynmap's MarkerAPI is often {@code null} for several ticks after enable; we retry until it is ready.
 * Borders are redrawn from {@link #update(Town)} (called on claim recompute and town save).
 */
public final class DynmapHook {
    private static final String SET_ID = "ages.towns";
    private static final String SET_LABEL = "Ages Civilizations";
    private static final int MAX_INIT_ATTEMPTS = 30;
    private static final long RETRY_TICKS = 20L;

    private final AgesPlugin plugin;
    private final Logger log;
    private boolean ready;
    private int attempts;

    private Object markerApi;
    private Object markerSet;
    private Method createAreaMarker;
    private Method findAreaMarker;
    private Method createMarker;
    private Method findMarker;
    private Method getMarkerIcon;
    private Method setLabel;
    private Method setDescription;
    private Method setCornerLocations;
    private Method setFillStyle;
    private Method setLineStyle;
    private Method deleteMarker;
    private Method deletePointMarker;
    private Object defaultIcon;

    public DynmapHook(AgesPlugin plugin) {
        this.plugin = plugin;
        this.log = plugin.getLogger();
    }

    public void start() {
        attempts = 0;
        ready = false;
        tryInit();
    }

    private void tryInit() {
        Plugin dm = Bukkit.getPluginManager().getPlugin("dynmap");
        if (dm == null) dm = Bukkit.getPluginManager().getPlugin("Dynmap");
        if (dm == null || !dm.isEnabled()) {
            log.info("Dynmap not found — map markers disabled.");
            return;
        }

        try {
            Object api = dm.getClass().getMethod("getMarkerAPI").invoke(dm);
            if (api == null) {
                attempts++;
                if (attempts <= MAX_INIT_ATTEMPTS) {
                    if (attempts == 1 || attempts % 5 == 0) {
                        log.info("Dynmap MarkerAPI not ready yet (attempt " + attempts + "/" + MAX_INIT_ATTEMPTS + ") — retrying…");
                    }
                    Bukkit.getScheduler().runTaskLater(plugin, this::tryInit, RETRY_TICKS);
                } else {
                    log.warning("Dynmap MarkerAPI stayed null after " + MAX_INIT_ATTEMPTS
                            + "s. Enable the markers component in Dynmap config.");
                }
                return;
            }
            markerApi = api;

            Method getSet = api.getClass().getMethod("getMarkerSet", String.class);
            Method createSet = api.getClass().getMethod(
                    "createMarkerSet", String.class, String.class, java.util.Set.class, boolean.class);

            markerSet = getSet.invoke(api, SET_ID);
            if (markerSet == null) {
                markerSet = createSet.invoke(api, SET_ID, SET_LABEL, null, false);
            }
            if (markerSet == null) {
                log.warning("Dynmap: could not create marker set '" + SET_ID + "'.");
                return;
            }

            Class<?> setCl = markerSet.getClass();
            Class<?> setIface = findIface(setCl, "org.dynmap.markers.MarkerSet");
            Class<?> methodsOn = setIface != null ? setIface : setCl;

            createAreaMarker = methodsOn.getMethod(
                    "createAreaMarker",
                    String.class, String.class, boolean.class,
                    String.class, double[].class, double[].class, boolean.class);
            findAreaMarker = methodsOn.getMethod("findAreaMarker", String.class);

            Class<?> areaCl = Class.forName("org.dynmap.markers.AreaMarker");
            setLabel = areaCl.getMethod("setLabel", String.class);
            setDescription = areaCl.getMethod("setDescription", String.class);
            setCornerLocations = areaCl.getMethod("setCornerLocations", double[].class, double[].class);
            setFillStyle = areaCl.getMethod("setFillStyle", double.class, int.class);
            setLineStyle = areaCl.getMethod("setLineStyle", int.class, double.class, int.class);
            deleteMarker = areaCl.getMethod("deleteMarker");

            // Optional center pin
            try {
                Class<?> iconCl = Class.forName("org.dynmap.markers.MarkerIcon");
                getMarkerIcon = api.getClass().getMethod("getMarkerIcon", String.class);
                defaultIcon = getMarkerIcon.invoke(api, "default");
                if (defaultIcon == null) defaultIcon = getMarkerIcon.invoke(api, "marker");
                createMarker = methodsOn.getMethod(
                        "createMarker",
                        String.class, String.class, boolean.class,
                        String.class, double.class, double.class, double.class,
                        iconCl, boolean.class);
                findMarker = methodsOn.getMethod("findMarker", String.class);
                Class<?> markerCl = Class.forName("org.dynmap.markers.Marker");
                deletePointMarker = markerCl.getMethod("deleteMarker");
            } catch (Throwable t) {
                log.info("Dynmap: point markers unavailable (" + t.getMessage() + "); area borders only.");
                createMarker = null;
            }

            try {
                methodsOn.getMethod("setHideByDefault", boolean.class).invoke(markerSet, false);
            } catch (Throwable ignored) {}
            try {
                methodsOn.getMethod("setLayerPriority", int.class).invoke(markerSet, 10);
            } catch (Throwable ignored) {}
            try {
                methodsOn.getMethod("setMarkerSetLabel", String.class).invoke(markerSet, SET_LABEL);
            } catch (Throwable ignored) {}

            ready = true;
            int towns = plugin.towns().all().size();
            log.info("Dynmap integration ready (marker set: " + SET_ID + "). Drawing " + towns + " civilization(s).");
            refreshAll();
        } catch (Throwable t) {
            log.log(Level.WARNING, "Dynmap integration failed — map markers disabled.", t);
            ready = false;
        }
    }

    private static Class<?> findIface(Class<?> cl, String name) {
        for (Class<?> i : cl.getInterfaces()) {
            if (name.equals(i.getName())) return i;
            Class<?> nested = findIface(i, name);
            if (nested != null) return nested;
        }
        Class<?> s = cl.getSuperclass();
        return s == null ? null : findIface(s, name);
    }

    public boolean isReady() { return ready; }

    public void refreshAll() {
        if (!ready) return;
        int n = 0;
        for (Town t : plugin.towns().all()) {
            update(t);
            n++;
        }
        log.info("Dynmap: refreshed " + n + " civilization marker(s).");
    }

    public void update(Town t) {
        if (!ready || t == null || t.center == null) return;
        try {
            String areaId = "town-" + t.id;
            String pinId = "core-" + t.id;
            World w = Bukkit.getWorld(t.center.world());
            if (w == null) return;
            String dynWorld = w.getName();

            AgeDef age = plugin.reg().age(t.ageId);
            int radius = claimRadius(t, age);
            if (radius < 4) radius = 4;

            // Square outline matching Ages claim math (center ± radius)
            double minX = t.center.x() - radius;
            double maxX = t.center.x() + radius + 1;
            double minZ = t.center.z() - radius;
            double maxZ = t.center.z() + radius + 1;
            double[] xs = {minX, maxX, maxX, minX};
            double[] zs = {minZ, minZ, maxZ, maxZ};

            String label = plain(t.name);
            String desc = description(t, age, radius);

            Object area = findAreaMarker.invoke(markerSet, areaId);
            if (area == null) {
                // non-persistent runtime markers are more reliable on some Dynmap builds
                area = createAreaMarker.invoke(markerSet, areaId, label, true, dynWorld, xs, zs, false);
                if (area == null) {
                    log.warning("Dynmap: createAreaMarker returned null for '" + t.name + "' world=" + dynWorld
                            + " radius=" + radius + " center=" + t.center.x() + "," + t.center.z());
                    return;
                }
                log.info("Dynmap: created border for '" + t.name + "' on " + dynWorld
                        + " at " + t.center.x() + "," + t.center.z() + " r=" + radius);
            } else {
                setCornerLocations.invoke(area, xs, zs);
                setLabel.invoke(area, label);
            }
            setDescription.invoke(area, desc);
            setFillStyle.invoke(area, 0.35, 0x3B82F6);
            setLineStyle.invoke(area, 4, 1.0, 0x1D4ED8);

            // Center pin so something is visible even when zoomed out
            if (createMarker != null && defaultIcon != null) {
                double y = t.center.y() + 1;
                Object pin = findMarker != null ? findMarker.invoke(markerSet, pinId) : null;
                if (pin == null) {
                    pin = createMarker.invoke(markerSet, pinId, label, true, dynWorld,
                            t.center.x() + 0.5, y, t.center.z() + 0.5, defaultIcon, false);
                }
                if (pin != null) {
                    try {
                        pin.getClass().getMethod("setDescription", String.class).invoke(pin, desc);
                        pin.getClass().getMethod("setLabel", String.class).invoke(pin, label);
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable t2) {
            log.log(Level.WARNING, "Dynmap update failed for '" + t.name + "'", t2);
        }
    }

    public void remove(Town t) {
        if (!ready || t == null) return;
        try {
            Object area = findAreaMarker.invoke(markerSet, "town-" + t.id);
            if (area != null) deleteMarker.invoke(area);
            if (findMarker != null) {
                Object pin = findMarker.invoke(markerSet, "core-" + t.id);
                if (pin != null && deletePointMarker != null) deletePointMarker.invoke(pin);
            }
        } catch (Throwable ignored) {}
    }

    private int claimRadius(Town t, AgeDef age) {
        int base = age != null ? age.claimBase : 24;
        int per = age != null ? age.claimPerBuilding : 3;
        int max = age != null ? age.claimMax : 64;
        int inside = 0;
        double bonus = 0;
        try {
            bonus = plugin.governance().effects(t).add("claim_radius_add");
        } catch (Throwable ignored) {}
        for (PlacedBuilding b : t.buildings) {
            BuildingDef d = plugin.reg().effective(b);
            if (d == null || d.anywhere) continue;
            inside++;
            if (!b.damaged) {
                try { bonus += d.provide("claim_bonus"); } catch (Throwable ignored) {}
            }
        }
        int r = (int) Math.min(max, base + per * inside + bonus);
        return Math.max(8, r);
    }

    private String description(Town t, AgeDef age, int radius) {
        String ageName = age != null ? plain(age.name) : (t.ageId == null ? "?" : t.ageId);
        return "<div style=\"font-weight:bold;font-size:14px\">" + esc(plain(t.name)) + "</div>"
                + "Age: " + esc(ageName) + "<br/>"
                + "Members: " + t.members.size() + "<br/>"
                + "Buildings: " + t.buildings.size() + "<br/>"
                + "Claim radius: ~" + radius + " blocks<br/>"
                + "Points: " + (int) t.points + " · Treasury: " + (int) t.money;
    }

    private static String plain(String s) {
        if (s == null) return "";
        return s.replaceAll("(?i)[§&][0-9a-fk-or]", "");
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
