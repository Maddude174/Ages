package dev.ages.gui;

import dev.ages.AgesPlugin;
import dev.ages.building.Scanner;
import dev.ages.config.AgeDef;
import dev.ages.config.BuildingDef;
import dev.ages.config.BuildingDef.Recipe;
import dev.ages.hook.Eco;
import dev.ages.model.Perm;
import dev.ages.model.PlacedBuilding;
import dev.ages.model.Town;
import dev.ages.util.Containers;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Core building GUI (structure, upgrade, storage, income, relocate) plus a separate Production menu
 * (recipes, timing, status) opened from a dedicated slot.
 */
public final class BuildingMenu {
    private final AgesPlugin plugin;

    public BuildingMenu(AgesPlugin plugin) { this.plugin = plugin; }

    public void open(Player p, Town t, PlacedBuilding pb) { openCore(p, t, pb, false); }

    // ------------------------------------------------------------------ core GUI

    private void openCore(Player p, Town t, PlacedBuilding pb, boolean confirmRemove) {
        BuildingDef base = plugin.reg().building(pb.defId);
        if (base == null) { Text.msg(p, "&cThis building's definition no longer exists in the configuration."); return; }
        BuildingDef cur = base.at(pb.level);
        UUID uid = p.getUniqueId();
        boolean mine = pb.owner.equals(uid) || t.can(uid, Perm.MANAGE_BUILDINGS);

        List<String> problems = List.of();
        if (pb.damaged && mine) {
            Scanner.Result r = plugin.buildings().revalidate(pb, true);
            if (r != null) problems = r.problems();
        }
        final List<String> damageProblems = problems;

        Menu m = new Menu(27, "&8" + Text.plain(cur.name));
        m.set(10, coreInfo(t, pb, cur, base, damageProblems));

        // Production panel (separate menu)
        if (hasProduction(cur)) {
            m.set(12, Gui.item(Material.CRAFTING_TABLE, "&eProduction",
                    "&7Recipes, timing, and status.",
                    "",
                    "&a> Click to open"), pl -> openProduction(pl, t, pb));
        }

        // Upgrade
        BuildingDef.Upgrade u = plugin.buildings().nextUpgrade(pb);
        if (u == null) {
            m.set(13, Gui.item(Material.NETHER_STAR, "&6Maximum level",
                    base.maxLevel() > 1 ? "&7This building is fully upgraded." : "&7This building cannot be upgraded."));
        } else {
            BuildingDef next = base.at(pb.level + 1);
            List<String> up = new ArrayList<>();
            for (String d : u.description()) up.add("&7" + d);
            AgeDef need = plugin.reg().age(u.ageId());
            up.add("");
            up.add("&6Requires: &f" + (need == null ? u.ageId() : Text.plain(need.name)));
            BuildingDef.Cost cost = plugin.buildings().upgradeCost(t, pb);
            up.add("&6Cost: &f" + Describe.cost(cost));
            List<String> newReqs = Describe.newRequirements(cur, next);
            if (!newReqs.isEmpty()) { up.add("&6Extra building requirements:"); for (String r : newReqs) up.add("  &7" + r); }
            if (next.rx != cur.rx || next.rz != cur.rz || next.up != cur.up || next.down != cur.down)
                up.add("&6Area grows to &f" + (2 * next.rx + 1) + "x" + (2 * next.rz + 1) + " &6wide, &f" + (next.up + next.down + 1) + " &6tall");
            List<String> gain = new ArrayList<>(Describe.function(next));
            gain.removeAll(Describe.function(cur));
            if (!gain.isEmpty()) { up.add(""); up.add("&6Unlocks:"); up.addAll(gain); }
            up.add("");
            up.add(Gui.action(plugin.buildings().upgradeBlocker(p, t, pb), "Click to upgrade"));
            up.add("&8The building is re-checked first; nothing is charged if it fails.");
            m.set(13, Gui.item(Material.ANVIL, "&eUpgrade to " + Text.plain(next.name), up), pl -> {
                List<String> errs = plugin.buildings().tryUpgrade(pl, t, pb);
                if (errs.isEmpty()) Text.msg(pl, "&aUpgraded to " + plugin.reg().effective(pb).name + "&a!");
                else { pl.sendMessage(Text.c("&cCannot upgrade yet:")); for (String s : errs) pl.sendMessage(Text.c("  &c- &7" + s)); }
                openCore(pl, t, pb, false);
            });
        }

        // Storage
        boolean same = pb.input != null && pb.input.equals(pb.output);
        if (pb.input != null)
            m.set(14, storageButton(p, pb, same ? "Open storage" : "Open input", pb.input, Material.HOPPER,
                    same ? "&7Inputs go in, products come out here." : "&7Put ingredients and tools here."),
                    pl -> openStorage(pl, pb, pb.input));
        if (pb.output != null && !same)
            m.set(15, storageButton(p, pb, "Open output", pb.output, Material.CHEST, "&7Finished goods appear here."),
                    pl -> openStorage(pl, pb, pb.output));

        // Collect income — owner only
        Eco eco = plugin.eco();
        boolean canCollect = pb.owner.equals(p.getUniqueId());
        if (pb.stored > 0.009) {
            if (eco == null) {
                m.set(16, Gui.item(Material.GOLD_INGOT, "&6Uncollected income",
                        "&7Waiting: &f" + Text.num(pb.stored),
                        "&cNo economy plugin (Vault) — cannot collect."));
            } else if (canCollect) {
                double amt = pb.stored;
                m.set(16, Gui.item(Material.GOLD_INGOT, "&6Collect income",
                        "&7Waiting: &f" + eco.fmt(amt),
                        "&7Paid to your personal balance.",
                        "&a> Click to collect"), pl -> {
                    double take = pb.stored;
                    if (take <= 0) { openCore(pl, t, pb, false); return; }
                    Eco e2 = plugin.eco();
                    if (e2 == null) { Text.msg(pl, "&cNo economy plugin."); return; }
                    e2.give(pl, take);
                    pb.stored = 0;
                    plugin.db().saveBuilding(pb);
                    plugin.finance().record(t, pl.getUniqueId(), "COLLECT", "MONEY", take, Text.plain(base.root().name) + " core");
                    Text.msg(pl, "&6Collected &f" + e2.fmt(take) + "&6.");
                    openCore(pl, t, pb, false);
                });
            } else {
                m.set(16, Gui.item(Material.GOLD_INGOT, "&6Uncollected income",
                        "&7Waiting: &f" + eco.fmt(pb.stored),
                        "&cOnly the building owner can collect."));
            }
        }

        // Relocate
        String rb = plugin.buildings().removeBlocker(p, t, pb);
        List<String> rl = new ArrayList<>();
        rl.add("&7Picks the core up so you can place it elsewhere.");
        rl.add("&7It keeps its level" + (cur.inputCore || cur.outputCore ? " and the core's contents come back to you." : "."));
        rl.add("");
        if (rb != null) rl.add("&c✘ " + rb);
        else if (!confirmRemove) rl.add("&a> Click to remove (asks to confirm)");
        else rl.add("&c> Click again to confirm removal");
        m.set(18, Gui.item(confirmRemove ? Material.TNT : Material.BARREL,
                confirmRemove ? "&cConfirm: remove this building?" : "&eRemove / relocate", rl), pl -> {
            if (rb != null) return;
            if (!confirmRemove) { openCore(pl, t, pb, true); return; }
            String err = plugin.buildings().removeCore(pl, t, pb, false);
            if (err != null) Text.msg(pl, "&c" + err);
            else { Text.msg(pl, "&7Building removed. The core is in your inventory (level " + pb.level + " kept)."); pl.closeInventory(); }
        });

        m.set(22, Gui.item(Material.BARRIER, "&cClose"), Player::closeInventory);
        m.open(p);
    }

    // ------------------------------------------------------------------ production GUI

    private void openProduction(Player p, Town t, PlacedBuilding pb) {
        BuildingDef base = plugin.reg().building(pb.defId);
        if (base == null) return;
        BuildingDef cur = base.at(pb.level);
        var f = cur.function;
        if (f == null) return;
        boolean mine = pb.owner.equals(p.getUniqueId()) || t.can(p.getUniqueId(), Perm.MANAGE_BUILDINGS);

        Menu m = new Menu(27, "&8Production · " + Text.plain(cur.name));

        // Status + timing (live)
        m.set(10, productionStatus(pb, cur));
        m.onRefresh(() -> m.set(10, productionStatus(pb, cur)));

        List<Recipe> unlocked = unlockedRecipes(t, pb, f.recipes);
        if (f.type.equals("processor") && !f.recipes.isEmpty()) {
            List<String> lore = new ArrayList<>();
            lore.add("&7Mode: &f" + f.mode);
            lore.add("&7Unlocked: &f" + unlocked.size() + "&7/&f" + f.recipes.size());
            lore.add("");
            if (f.mode.equals("selected")) {
                Recipe active = findActive(unlocked, pb);
                if (active != null) {
                    lore.add("&aSelected: &f" + Describe.recipeLabel(active));
                    lore.add("  &8" + Describe.recipeLine(active));
                } else {
                    lore.add("&cNo recipe selected");
                }
                lore.add("");
                // List ALL unlocked recipes (every tier), not only best per select_as
                int n = 0;
                for (Recipe r : unlocked) {
                    if (n++ >= 12) { lore.add("&8  …"); break; }
                    boolean on = active != null && r.id().equals(active.id());
                    lore.add((on ? "&a> " : "&7  ") + Describe.recipeLabel(r));
                    lore.add("    &8" + Describe.recipeLine(r));
                }
                lore.add("");
                String why = mine ? null : "Only the owner or a manager can change the recipe.";
                lore.add(Gui.action(why, "Click to choose a recipe"));
                m.set(12, Gui.item(Material.WRITABLE_BOOK, "&eRecipes", lore),
                        pl -> openRecipePicker(pl, t, pb, mine));
            } else {
                int n = 0;
                for (Recipe r : unlocked) {
                    if (n++ >= 12) { lore.add("&8  …"); break; }
                    lore.add("&7• &f" + Describe.recipeLabel(r));
                    lore.add("    &8" + Describe.recipeLine(r));
                }
                m.set(12, Gui.item(Material.BOOK, "&eRecipes", lore));
            }
        } else if (!f.always.isEmpty()) {
            m.set(12, Gui.item(Material.BOOK, "&ePassive output", Describe.function(cur)));
        }

        m.set(18, Gui.item(Material.ARROW, "&7Back to building"), pl -> openCore(pl, t, pb, false));
        m.set(22, Gui.item(Material.BARRIER, "&cClose"), Player::closeInventory);
        m.open(p);
    }

    /** All unlocked recipes as individual slots (every tier shown). */
    private void openRecipePicker(Player p, Town t, PlacedBuilding pb, boolean canEdit) {
        BuildingDef base = plugin.reg().building(pb.defId);
        if (base == null) return;
        BuildingDef cur = base.at(pb.level);
        if (cur.function == null) return;
        List<Recipe> unlocked = unlockedRecipes(t, pb, cur.function.recipes);
        int rows = Math.min(6, Math.max(3, (unlocked.size() + 8) / 9 + 1));
        Menu m = new Menu(rows * 9, "&8Choose recipe");
        String activeId = pb.recipe;
        int slot = 0;
        for (Recipe r : unlocked) {
            if (slot >= rows * 9 - 9) break;
            boolean on = r.id().equals(activeId) || (activeId != null && r.selectKey().equals(activeId) && findActive(unlocked, pb) == r);
            Material icon = Material.PAPER;
            for (var ing : r.consume()) {
                if (!ing.anyOf().isEmpty()) { icon = ing.anyOf().iterator().next(); break; }
            }
            List<String> lore = new ArrayList<>();
            lore.add(on ? "&aSelected" : "&7Click to select");
            lore.add("&8" + Describe.recipeLine(r));
            if (r.requireLevel() > 1) lore.add("&7Requires building level &f" + r.requireLevel() + "+");
            if (r.requireAge() != null) lore.add("&7Requires age: &f" + r.requireAge());
            final String rid = r.id();
            m.set(slot++, Gui.item(icon, (on ? "&a> " : "&e") + Describe.recipeLabel(r), lore), pl -> {
                if (!canEdit) { Text.msg(pl, "&cOnly the owner or a manager can change the recipe."); return; }
                String err = plugin.buildings().selectRecipe(pl, t, pb, rid);
                if (err != null) Text.msg(pl, "&c" + err);
                else Text.msg(pl, "&aRecipe set to &f" + Describe.recipeLabel(r) + "&a.");
                openProduction(pl, t, pb);
            });
        }
        m.set(rows * 9 - 5, Gui.item(Material.ARROW, "&7Back"), pl -> openProduction(pl, t, pb));
        m.set(rows * 9 - 4, Gui.item(Material.BARRIER, "&cClose"), Player::closeInventory);
        m.open(p);
    }

    // ------------------------------------------------------------------ helpers

    private static boolean hasProduction(BuildingDef cur) {
        if (cur.function == null) return false;
        var f = cur.function;
        if (f.type.equals("none") && f.always.isEmpty()) return false;
        return true;
    }

    private List<Recipe> unlockedRecipes(Town t, PlacedBuilding pb, List<Recipe> recipes) {
        var reg = plugin.reg();
        var age = reg.age(t.ageId);
        int ageOrder = age != null ? age.order : 0;
        List<Recipe> out = new ArrayList<>();
        for (Recipe r : recipes) {
            if (r.requireLevel() > pb.level) continue;
            if (r.requireAge() != null) {
                var need = reg.age(r.requireAge());
                if (need != null && need.order > ageOrder) continue;
            }
            out.add(r);
        }
        return out;
    }

    private Recipe findActive(List<Recipe> unlocked, PlacedBuilding pb) {
        if (unlocked.isEmpty()) return null;
        String key = pb.recipe;
        if (key != null) {
            for (Recipe r : unlocked) if (r.id().equals(key)) return r;
            // fall back: best tier for select_as key
            Recipe best = null;
            for (Recipe r : unlocked) {
                if (!r.selectKey().equals(key) && !r.id().equals(key)) continue;
                if (best == null || r.requireLevel() > best.requireLevel()) best = r;
            }
            if (best != null) return best;
        }
        return unlocked.get(0);
    }

    private ItemStack coreInfo(Town t, PlacedBuilding pb, BuildingDef cur, BuildingDef base, List<String> problems) {
        List<String> lore = new ArrayList<>();
        String owner = Bukkit.getOfflinePlayer(pb.owner).getName();
        lore.add("&7Owner: &f" + (owner == null ? "?" : owner));
        lore.add("&7Level: &f" + pb.level + "&7/" + base.maxLevel());
        if (pb.damaged) {
            lore.add("&cStatus: damaged");
            for (String s : problems) lore.add("  &c- &7" + s);
            lore.add("&8Fix the structure, then reopen this menu.");
        } else {
            lore.add("&aStatus: Normal");
        }
        return Gui.item(cur.icon, cur.name, lore);
    }

    private ItemStack productionStatus(PlacedBuilding pb, BuildingDef cur) {
        List<String> lore = new ArrayList<>();
        if (pb.damaged) {
            lore.add("&cPaused — building is damaged");
        } else {
            long now = System.currentTimeMillis();
            lore.add("&aRunning" + (pb.lastStatus.isEmpty() || pb.lastStatus.equals("Running") ? "" : " &8- &e" + pb.lastStatus));
            if (pb.nextRun > 0)
                lore.add("&6Next cycle: &f" + (pb.nextRun <= now ? "due now" : "in " + Text.remaining(pb.nextRun - now)));
            else
                lore.add("&6Next cycle: &7scheduling…");
            if (cur.function != null)
                lore.add("&7Interval: &f" + Text.duration(cur.function.interval));
        }
        return Gui.item(Material.CLOCK, "&eStatus", lore);
    }

    private ItemStack storageButton(Player p, PlacedBuilding pb, String name, dev.ages.model.BlockPos pos, Material icon, String desc) {
        String why = reachBlocker(p, pos);
        return Gui.item(icon, "&e" + name, desc, "", Gui.action(why, "Click to open"));
    }

    private String reachBlocker(Player p, dev.ages.model.BlockPos pos) {
        if (!p.getWorld().getName().equals(pos.world())) return "Not in the same world.";
        Location l = pos.toLocation();
        if (l == null || l.distanceSquared(p.getLocation()) > 20 * 20) return "Too far away (stand within 20 blocks).";
        return null;
    }

    private void openStorage(Player p, PlacedBuilding pb, dev.ages.model.BlockPos pos) {
        String why = reachBlocker(p, pos);
        if (why != null) { Text.msg(p, "&c" + why); return; }
        Block b = pos.block();
        if (b == null || !Containers.isContainer(b.getType()) || !(b.getState(false) instanceof Container c)) {
            Text.msg(p, "&cThat container is gone.");
            return;
        }
        p.openInventory(c.getInventory());
    }
}
