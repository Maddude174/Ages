package dev.ages.gui;

import dev.ages.AgesPlugin;
import dev.ages.model.Relation;
import dev.ages.model.Relation.State;
import dev.ages.model.Town;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Diplomacy hub: list civs, manage relations, war/revolt/revolution entry points.
 * Mirrors the main /ages diplomacy commands.
 */
public final class DiplomacyMenu {
    private final AgesPlugin plugin;

    public DiplomacyMenu(AgesPlugin plugin) { this.plugin = plugin; }

    public void open(Player p, Town self) {
        if (!plugin.reg().settings.diplomacyEnabled) {
            Text.msg(p, "&cDiplomacy is disabled.");
            return;
        }
        Menu m = new Menu(54, "&8Diplomacy — " + Text.plain(self.name));

        // Row 1: status / actions for self
        m.set(4, Gui.item(Material.BOOK, "&6Your relations",
                "&7Click a civilization below to manage.",
                "&7Commands: &f/ages ally, breakally, hostile,",
                "&f/ages war, truce, tributary, release,",
                "&f/ages accept_diplo, revolt, civilwar, rebel"));

        boolean isOpp = plugin.diplomacy().isOpposition(self);
        Town overlord = findOverlord(self);
        boolean inCivilWar = hasActiveCivilWar(self);

        m.set(0, Gui.item(Material.IRON_SWORD, "&cRevolution (civil war)",
                "&7Split your civilization: you lead rebels.",
                "&7Others: &f/ages rebel &7to defect.",
                "&8Internal only — not for tributaries.",
                isOpp ? "&cAlready opposition." : (inCivilWar ? "&cCivil war already active." : "&eClick to start")),
                pl -> {
                    String err = plugin.diplomacy().startCivilWar(pl, self, "revolution");
                    Text.msg(pl, err == null ? "&cRevolution started." : "&c" + err);
                    pl.closeInventory();
                });

        m.set(1, Gui.item(Material.SHIELD, "&6Revolt (break tributary)",
                "&7Declare war on your overlord.",
                "&7Only if you are a tributary/settlement.",
                overlord == null ? "&8You have no overlord." : "&7Overlord: &f" + overlord.name,
                overlord == null ? "&cUnavailable" : "&eClick to revolt"),
                pl -> {
                    String err = plugin.diplomacy().startRevolt(pl, self);
                    Text.msg(pl, err == null ? "&cRevolt declared." : "&c" + err);
                    pl.closeInventory();
                });

        m.set(2, Gui.item(Material.WHITE_BANNER, "&eJoin rebels",
                "&7If a civil war is active on your civ,",
                "&7defect to the opposition.",
                "&8/ages rebel",
                inCivilWar ? "&eClick to defect" : "&cNo active civil war"),
                pl -> {
                    String err = plugin.diplomacy().joinOpposition(pl, self);
                    Text.msg(pl, err == null ? "&eYou joined the opposition." : "&c" + err);
                    pl.closeInventory();
                });

        m.set(8, Gui.item(Material.PAPER, "&7Pending tips",
                "&7Ally/truce need the other side to",
                "&f/ages accept_diplo <your civ>",
                "&7War goals: none, tributary, conquest,",
                "&7total_war, political, raid, revolt"));

        // Other civs
        List<Town> others = new ArrayList<>();
        for (Town t : plugin.towns().all()) {
            if (t.id.equals(self.id)) continue;
            if (plugin.diplomacy().isOpposition(t) && self.shadowOf == null
                    && t.shadowOf != null && !t.shadowOf.equals(self.id)) continue;
            others.add(t);
        }
        others.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        int slot = 18;
        for (Town o : others) {
            if (slot >= 45) break;
            Relation r = plugin.diplomacy().get(self, o);
            List<String> lore = new ArrayList<>();
            lore.add("&7Leader: &f" + name(o.leader));
            lore.add("&7Relation: &f" + (r == null ? "NEUTRAL" : r.state.name()));
            if (r != null && r.state == State.WAR) {
                lore.add("&7Goal: &f" + r.warGoal + "  &7Score: &f" + r.warScore + "/1000");
            }
            if (r != null && (r.state == State.TRIBUTARY || r.state == State.SETTLEMENT)) {
                lore.add("&7Tribute: &f" + (int) (r.tributeRate * 100) + "%");
                if (r.overlord != null && r.overlord.equals(self.id)) lore.add("&8You are overlord");
                if (r.overlord != null && r.overlord.equals(o.id)) lore.add("&8They are overlord");
            }
            if (plugin.diplomacy().isOpposition(o)) lore.add("&8Civil-war opposition");
            lore.add("");
            lore.add("&eClick to manage");
            m.set(slot++, head(o, lore), pl -> manage(pl, self, o));
        }

        m.set(49, Gui.item(Material.ARROW, "&eBack"), pl -> plugin.civMenu().open(pl));
        m.set(53, Gui.item(Material.BARRIER, "&cClose"), Player::closeInventory);
        m.open(p);
    }

    private void manage(Player p, Town self, Town other) {
        Relation r = plugin.diplomacy().get(self, other);
        State st = r.state;
        Menu m = new Menu(45, "&8" + Text.plain(other.name));
        m.set(4, head(other, List.of("&7Current: &f" + st.name())));

        // Diplomacy
        m.set(10, Gui.item(Material.DIAMOND, "&aPropose alliance",
                "&7Full alliance (needs accept)",
                "&eShift-click: defensive only",
                "&8/ages ally <civ> [defensive]"), pl -> {
            String err = plugin.diplomacy().proposeAlliance(pl, self, other, pl.isSneaking());
            Text.msg(pl, err == null ? "&aAlliance proposed." : "&c" + err);
            pl.closeInventory();
        });
        m.set(11, Gui.item(Material.BARRIER, "&cBreak alliance",
                "&8/ages breakally <civ>"), pl -> {
            String err = plugin.diplomacy().setState(pl, self, other, State.NEUTRAL, null);
            Text.msg(pl, err == null ? "&7Cleared to Neutral." : "&c" + err);
            pl.closeInventory();
        });
        m.set(12, Gui.item(Material.IRON_BARS, "&6Set Hostile",
                "&7Enables wartime TNT/cannon rules",
                "&8/ages hostile <civ>"), pl -> {
            String err = plugin.diplomacy().setState(pl, self, other, State.HOSTILE, null);
            Text.msg(pl, err == null ? "&cNow Hostile." : "&c" + err);
            pl.closeInventory();
        });
        m.set(13, Gui.item(Material.SHIELD, "&eOffer truce",
                "&7Needs the other side to accept",
                "&8/ages truce <civ>"), pl -> {
            String err = plugin.diplomacy().offerTruce(pl, self, other, null);
            Text.msg(pl, err == null ? "&aTruce proposed." : "&c" + err);
            pl.closeInventory();
        });
        m.set(14, Gui.item(Material.WRITABLE_BOOK, "&aAccept proposal",
                "&7If they sent ally/truce to you",
                "&8/ages accept_diplo <civ>"), pl -> {
            String err = plugin.diplomacy().acceptProposal(pl, self, other);
            Text.msg(pl, err == null ? "&aAccepted." : "&c" + err);
            pl.closeInventory();
        });

        // War
        m.set(19, Gui.item(Material.IRON_SWORD, "&cDeclare war (tributary goal)",
                "&eShift: total_war",
                "&8/ages war <civ> <goal>"), pl -> {
            String err = plugin.diplomacy().declareWar(pl, self, other, pl.isSneaking() ? "total_war" : "tributary");
            Text.msg(pl, err == null ? "&cWar declared." : "&c" + err);
            pl.closeInventory();
        });
        m.set(20, Gui.item(Material.GOLDEN_SWORD, "&6War: raid",
                "&7Goal raid (50% stores if you win)"), pl -> {
            String err = plugin.diplomacy().declareWar(pl, self, other, "raid");
            Text.msg(pl, err == null ? "&cWar declared (raid)." : "&c" + err);
            pl.closeInventory();
        });
        m.set(21, Gui.item(Material.GOLD_INGOT, "&6Demand tributary",
                "&7Requires war goal tributary + score 600+",
                "&8/ages tributary <civ>"), pl -> {
            String err = plugin.diplomacy().demandTributary(pl, self, other);
            Text.msg(pl, err == null ? "&6Tributary enforced." : "&c" + err);
            pl.closeInventory();
        });
        m.set(22, Gui.item(Material.LEAD, "&7Release tributary/settlement",
                "&8/ages release <civ>"), pl -> {
            String err = plugin.diplomacy().releaseTributary(pl, self, other);
            Text.msg(pl, err == null ? "&aReleased." : "&c" + err);
            pl.closeInventory();
        });

        // Revolt against this civ if they are overlord
        if (r.overlord != null && r.overlord.equals(other.id)
                && (st == State.TRIBUTARY || st == State.SETTLEMENT)) {
            m.set(24, Gui.item(Material.TNT, "&cRevolt against overlord",
                    "&7War goal: revolt",
                    "&8/ages revolt"), pl -> {
                String err = plugin.diplomacy().startRevolt(pl, self);
                Text.msg(pl, err == null ? "&cRevolt declared." : "&c" + err);
                pl.closeInventory();
            });
        }

        m.set(36, Gui.item(Material.ARROW, "&eBack"), pl -> open(pl, self));
        m.set(40, Gui.item(Material.BARRIER, "&cClose"), Player::closeInventory);
        m.open(p);
    }

    private Town findOverlord(Town self) {
        for (Relation r : plugin.diplomacy().of(self)) {
            if ((r.state == State.TRIBUTARY || r.state == State.SETTLEMENT)
                    && r.overlord != null && !r.overlord.equals(self.id))
                return plugin.towns().byId(r.overlord);
        }
        return null;
    }

    private boolean hasActiveCivilWar(Town self) {
        for (Town o : plugin.towns().all()) {
            if (self.id.equals(o.shadowOf) && plugin.diplomacy().atWar(self, o)) return true;
        }
        return false;
    }

    private ItemStack head(Town t, List<String> lore) {
        ItemStack stack = Gui.item(Material.PLAYER_HEAD, "&6" + t.name, lore.toArray(new String[0]));
        if (t.leader != null && stack.getItemMeta() instanceof SkullMeta m2) {
            m2.setOwningPlayer(Bukkit.getOfflinePlayer(t.leader));
            stack.setItemMeta(m2);
        }
        return stack;
    }

    private static String name(UUID u) {
        if (u == null) return "?";
        var op = Bukkit.getOfflinePlayer(u);
        return op.getName() != null ? op.getName() : u.toString().substring(0, 8);
    }
}
