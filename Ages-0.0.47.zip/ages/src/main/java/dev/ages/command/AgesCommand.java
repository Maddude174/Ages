package dev.ages.command;

import dev.ages.AgesPlugin;
import dev.ages.config.*;
import dev.ages.item.Items;
import dev.ages.manager.Progress;
import dev.ages.model.*;
import dev.ages.util.InvUtil;
import dev.ages.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/** /ages with no arguments opens the civilization GUI; subcommands mirror what the GUI can do. */
public final class AgesCommand implements CommandExecutor, TabCompleter {
    private final AgesPlugin plugin;
    private final Map<UUID, Long> pendingDisband = new HashMap<>();
    private final Map<UUID, Long> pendingTransfer = new HashMap<>();

    public AgesCommand(AgesPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            if (s instanceof Player p) plugin.civMenu().open(p); else help(s);
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "menu", "gui" -> { if (s instanceof Player p) plugin.civMenu().open(p); }
            case "help" -> help(s);
            case "info" -> info(s, a);
            case "buildings" -> buildings(s);
            case "logistics" -> logistics(s);
            case "invite" -> invite(s, a);
            case "accept" -> accept(s);
            case "leave" -> leave(s);
            case "kick" -> kick(s, a);
            case "rank", "role" -> rank(s, a);
            case "contribute" -> contribute(s, a);
            case "withdraw" -> money(s, a, "withdraw");
            case "convert" -> money(s, a, "convert");
            case "treasury" -> treasury(s);
            case "government", "gov" -> government(s, a);
            case "economy", "econ" -> economy(s, a);
            case "policy" -> policy(s, a);
            case "vote" -> vote(s, a);
            case "leader" -> leader(s, a);
            case "owner" -> owner(s, a);
            case "disband" -> disband(s, a);
            case "core" -> give(s, plugin.reg().foundingBuilding(), a.length > 1 ? a[1] : null);
            case "fireplace" -> give(s, plugin.reg().building("fireplace"), a.length > 1 ? a[1] : null);
            case "give" -> {
                if (a.length < 2) { Text.msg(s, "&cUsage: /ages give <building> [player]"); return true; }
                give(s, plugin.reg().building(a[1].toLowerCase()), a.length > 2 ? a[2] : null);
            }
            case "diplomacy", "diplo" -> diplomacy(s, a);
            case "war" -> war(s, a);
            case "ally" -> ally(s, a);
            case "truce" -> truce(s, a);
            case "tributary" -> tributary(s, a);
            case "release" -> release(s, a);
            case "accept_diplo" -> acceptDiplo(s, a);
            case "civilwar", "revolution" -> civilWar(s, a);
            case "revolt" -> revoltCmd(s, a);
            case "rebel", "defect" -> rebel(s, a);
            case "breakally", "unally" -> breakAlly(s, a);
            case "hostile" -> setHostile(s, a);
            case "admin" -> admin(s, a);
            case "reload" -> {
                if (!s.hasPermission("ages.admin")) { Text.msg(s, "&cNo permission."); return true; }
                if (plugin.reloadAll(s)) Text.msg(s, "&aConfiguration reloaded.");
            }
            default -> help(s);
        }
        return true;
    }

    private void help(CommandSender s) {
        Text.msg(s, "&6Ages commands:");
        for (String l : new String[]{
                "/ages &8- open the civilization menu",
                "/ages info [civilization] &8- summary and advancement checklist",
                "/ages buildings | logistics | treasury",
                "/ages invite <player> | accept | leave | kick <player>",
                "/ages contribute hand|all|money <n>   /ages withdraw <n>   /ages convert <n>",
                "/ages government [list|set <id>]   /ages economy [list|set <id>]",
                "/ages policy [list|<id>] &8- adopt or revoke   /ages vote <player>   /ages leader <player>",
                "/ages rank list|create <name> [weight]|delete <name>|perm <name> <PERM> <true|false>|set <player> <role>",
                "/ages owner transfer <player> &8- technical ownership   /ages disband",
                "/ages core [player] &8- (admin) founding core   /ages fireplace [player] &8- (admin) fireplace core",
                "/ages give <building> [player]   /ages reload",
                "/ages admin &8- admin tools (points, money, gov, disband, …)"})
            s.sendMessage(Text.c("  &e" + l));
    }

    // ------------------------------------------------------------------ helpers

    private Player player(CommandSender s) {
        if (s instanceof Player p) return p;
        Text.msg(s, "&cPlayers only.");
        return null;
    }

    private Town townOf(Player p) {
        Town t = plugin.towns().of(p.getUniqueId());
        if (t == null) Text.msg(p, "&cYou are not in a civilization.");
        return t;
    }

    private boolean need(Player p, Town t, Perm perm) {
        if (t.can(p.getUniqueId(), perm)) return true;
        Rank r = t.rankOf(p.getUniqueId());
        Text.msg(p, "&cYour role (" + (r == null ? "none" : r.title) + ") cannot: " + perm.description.toLowerCase() + ".");
        return false;
    }

    private String name(UUID u) { String n = u == null ? null : Bukkit.getOfflinePlayer(u).getName(); return n == null ? "?" : n; }

    private UUID memberByName(Town t, String name) {
        for (UUID u : t.members.keySet()) if (name.equalsIgnoreCase(Bukkit.getOfflinePlayer(u).getName())) return u;
        return null;
    }

    private double amount(CommandSender s, String[] a, int idx) {
        try { return Double.parseDouble(a[idx]); } catch (RuntimeException e) { Text.msg(s, "&cEnter a number."); return -1; }
    }

    // ------------------------------------------------------------------ info

    private void give(CommandSender s, BuildingDef d, String target) {
        if (!s.hasPermission("ages.admin")) { Text.msg(s, "&cNo permission."); return; }
        if (d == null) { Text.msg(s, "&cUnknown building."); return; }
        Player p = target != null ? Bukkit.getPlayerExact(target) : s instanceof Player pl ? pl : null;
        if (p == null) { Text.msg(s, "&cPlayer not found."); return; }
        InvUtil.give(p, Items.core(d));
        Text.msg(s, "&7Gave &f" + Text.plain(d.name) + " &7to " + p.getName() + ".");
    }

    private void info(CommandSender s, String[] a) {
        Town t = a.length > 1 ? plugin.towns().byName(String.join(" ", Arrays.copyOfRange(a, 1, a.length)))
                : s instanceof Player p ? plugin.towns().of(p.getUniqueId()) : null;
        if (t == null) { Text.msg(s, "&cCivilization not found."); return; }
        Registries reg = plugin.reg();
        AgeDef age = reg.age(t.ageId);
        GovernmentDef gov = reg.government(t.govId);
        s.sendMessage(Text.c("&6&l" + t.name + " &8- &7" + Text.plain(age.name) + " &8- &7" + Text.plain(gov.name) + " / " + Text.plain(reg.economy(t.econId).name)));
        s.sendMessage(Text.c("&7" + gov.leaderTitle + ": &f" + name(t.leader) + " &7Owner: &f" + name(t.owner) + " &7Members: &f" + t.members.size()
                + " &7Villagers: &f" + t.villagers + " &7Housing: &f" + plugin.towns().housing(t) + " &7Buildings: &f" + t.buildings.size()));
        s.sendMessage(Text.c("&7Resource points: &f" + Text.num(t.points)));
        AgeDef next = reg.nextAge(age);
        if (next == null) { s.sendMessage(Text.c("&aFinal age reached.")); return; }
        Progress.Node n = plugin.progress().eval(t, next.requirements);
        s.sendMessage(Text.c("&7To reach the " + Text.plain(next.name) + ":" + (n.met() ? " &a(requirements met: buy its core in the catalogue)" : "")));
        for (String l : plugin.progress().lines(n, 0)) s.sendMessage(Text.c("  " + l));
    }

    private void buildings(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Map<String, int[]> counts = new TreeMap<>();
        for (PlacedBuilding b : t.buildings) {
            int[] c = counts.computeIfAbsent(b.defId + "#" + b.level, k -> new int[2]);
            c[0]++;
            if (b.damaged) c[1]++;
        }
        counts.forEach((key, c) -> {
            String[] kv = key.split("#");
            BuildingDef d = plugin.reg().building(kv[0]);
            String nm = d == null ? kv[0] : d.at(Integer.parseInt(kv[1])).name;
            p.sendMessage(Text.c("  &f" + c[0] + "x " + nm + (c[1] > 0 ? " &c(" + c[1] + " damaged)" : "")));
        });
    }

    private void logistics(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        List<String> lines = plugin.logistics().describe(t);
        if (lines.isEmpty()) Text.msg(p, "&7No rail network links two of your buildings yet (rail logistics unlock in the " + plugin.reg().settings.logisticsMinAge + " age).");
        else for (String l : lines) p.sendMessage(Text.c("  &f" + l));
    }

    private void treasury(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null || !need(p, t, Perm.VIEW_FINANCES)) return;
        p.sendMessage(Text.c("&6Treasury: &f" + Text.num(t.money) + " &6Resource points: &f" + Text.num(t.points)));
        long now = System.currentTimeMillis();
        int n = 0;
        for (Tx x : t.ledger) {
            if (n++ >= 12) break;
            p.sendMessage(Text.c("  &8" + Text.remaining(now - x.ts) + " ago &7" + (x.actor == null ? "Civilization" : name(x.actor)) + " &f" + x.type.toLowerCase().replace('_', ' ')
                    + " " + (x.amount >= 0 ? "&a+" : "&c") + Text.num(x.amount) + (x.currency.equals("POINTS") ? " pts" : " $") + " &8" + x.note));
        }
    }

    // ------------------------------------------------------------------ membership

    private void invite(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null || !need(p, t, Perm.INVITE)) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages invite <player>"); return; }
        Player target = Bukkit.getPlayerExact(a[1]);
        if (target == null) { Text.msg(p, "&cPlayer not online."); return; }
        if (plugin.towns().of(target.getUniqueId()) != null) { Text.msg(p, "&cThey already belong to a civilization."); return; }
        if (t.members.size() >= plugin.reg().settings.maxMembers) { Text.msg(p, "&cThe civilization is full."); return; }
        t.invites.add(target.getUniqueId());
        Text.msg(p, "&7Invited " + target.getName() + ".");
        Text.msg(target, "&6" + p.getName() + " &7invited you to join &f" + t.name + "&7. Type &e/ages accept&7.");
    }

    private void accept(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        if (plugin.towns().of(p.getUniqueId()) != null) { Text.msg(p, "&cYou already belong to a civilization."); return; }
        for (Town t : plugin.towns().all()) {
            if (t.invites.contains(p.getUniqueId())) {
                plugin.towns().addMember(t, p.getUniqueId(), plugin.reg().government(t.govId).defaultRole);
                Text.msg(p, "&aYou joined " + t.name + "!");
                return;
            }
        }
        Text.msg(p, "&cNo pending invitation.");
    }

    private void leave(CommandSender s) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (t.members.size() == 1) { Text.msg(p, "&cYou are the last member. Use &e/ages disband&c to dissolve the civilization."); return; }
        if (t.isOwner(p.getUniqueId())) { Text.msg(p, "&cYou are the technical owner: transfer ownership first (/ages owner transfer <player>)."); return; }
        if (p.getUniqueId().equals(t.leader)) { Text.msg(p, "&cYou are the " + plugin.reg().government(t.govId).leaderTitle + ": hand over leadership first."); return; }
        plugin.towns().removeMember(t, p.getUniqueId());
        Text.msg(p, "&7You left " + t.name + ". Your buildings passed to the civilization's highest rank.");
    }

    private void kick(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null || !need(p, t, Perm.KICK)) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages kick <player>"); return; }
        UUID u = memberByName(t, a[1]);
        if (u == null) { Text.msg(p, "&cNot a member."); return; }
        if (t.isOwner(u)) { Text.msg(p, "&cThe technical owner cannot be removed."); return; }
        if (t.weightOf(u) >= t.weightOf(p.getUniqueId())) { Text.msg(p, "&cYou can only remove members ranked below you."); return; }
        plugin.towns().removeMember(t, u);
        Text.msg(p, "&7Removed " + a[1] + ".");
    }

    // ------------------------------------------------------------------ money

    private void contribute(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages contribute hand|all|money <amount>"); return; }
        switch (a[1].toLowerCase()) {
            case "hand" -> Text.msg(p, plugin.finance().contributeItems(p, t, false));
            case "all" -> Text.msg(p, plugin.finance().contributeItems(p, t, true));
            case "money" -> { if (a.length < 3) { Text.msg(p, "&cUsage: /ages contribute money <amount>"); return; } double v = amount(p, a, 2); if (v > 0) Text.msg(p, plugin.finance().contributeMoney(p, t, v)); }
            default -> Text.msg(p, "&cUsage: /ages contribute hand|all|money <amount>");
        }
    }

    private void money(CommandSender s, String[] a, String what) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages " + what + " <amount>"); return; }
        double v = amount(p, a, 1);
        if (v <= 0) return;
        Text.msg(p, what.equals("withdraw") ? plugin.finance().withdraw(p, t, v) : plugin.finance().convert(p, t, v));
    }

    // ------------------------------------------------------------------ government, economy, policies

    private void government(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Registries reg = plugin.reg();
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            Text.msg(p, "&7Current: &f" + Text.plain(reg.government(t.govId).name));
            for (GovernmentDef g : reg.governments.values()) {
                String why = plugin.governance().govBlocker(p, t, g);
                p.sendMessage(Text.c("  &e" + g.id + " &7- " + Text.plain(g.name) + (g.id.equals(t.govId) ? " &a(current)" : why == null ? " &a(available)" : " &c" + why)));
            }
            return;
        }
        if (a.length < 3 || !a[1].equalsIgnoreCase("set")) { Text.msg(p, "&cUsage: /ages government [list|set <id>]"); return; }
        GovernmentDef g = reg.governments.get(a[2].toLowerCase());
        if (g == null) { Text.msg(p, "&cUnknown government."); return; }
        String e = plugin.governance().changeGovernment(p, t, g);
        Text.msg(p, e == null ? "&aThe civilization is now a " + Text.plain(g.name) + "&a." : "&c" + e);
    }

    private void economy(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Registries reg = plugin.reg();
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            Text.msg(p, "&7Current: &f" + Text.plain(reg.economy(t.econId).name));
            for (EconomyDef e : reg.economies.values()) {
                String why = plugin.governance().econBlocker(p, t, e);
                p.sendMessage(Text.c("  &e" + e.id + " &7- " + Text.plain(e.name) + (e.id.equals(t.econId) ? " &a(current)" : why == null ? " &a(available)" : " &c" + why)));
            }
            return;
        }
        if (a.length < 3 || !a[1].equalsIgnoreCase("set")) { Text.msg(p, "&cUsage: /ages economy [list|set <id>]"); return; }
        EconomyDef e = reg.economies.get(a[2].toLowerCase());
        if (e == null) { Text.msg(p, "&cUnknown economic system."); return; }
        String err = plugin.governance().changeEconomy(p, t, e);
        Text.msg(p, err == null ? "&aThe economy is now " + Text.plain(e.name) + "&a." : "&c" + err);
    }

    private void policy(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Registries reg = plugin.reg();
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            for (PolicyDef pd : reg.policies.values()) {
                if (!plugin.governance().offered(t, pd)) continue;
                String why = plugin.governance().policyBlocker(p, t, pd);
                p.sendMessage(Text.c("  &e" + pd.id + " &7(" + pd.kind + ") " + Text.plain(pd.name) + (t.policies.contains(pd.id) ? " &a[active]" : why == null ? " &7[available]" : " &c" + why)));
            }
            return;
        }
        PolicyDef pd = reg.policy(a[1].toLowerCase());
        if (pd == null) { Text.msg(p, "&cUnknown policy."); return; }
        String err = plugin.governance().togglePolicy(p, t, pd);
        Text.msg(p, err == null ? "&a" + Text.plain(pd.name) + (t.policies.contains(pd.id) ? " adopted." : " revoked.") : "&c" + err);
    }

    private void vote(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages vote <member>"); return; }
        UUID u = memberByName(t, a[1]);
        if (u == null) { Text.msg(p, "&cNot a member."); return; }
        String e = plugin.governance().vote(p, t, u);
        Text.msg(p, e == null ? "&aVote recorded. Results when the election closes." : "&c" + e);
    }

    private void leader(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages leader <member>"); return; }
        UUID u = memberByName(t, a[1]);
        if (u == null) { Text.msg(p, "&cNot a member."); return; }
        String e = plugin.governance().appointLeader(p, t, u);
        Text.msg(p, e == null ? "&a" + name(u) + " now leads the civilization." : "&c" + e);
    }

    private void owner(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 3 || !a[1].equalsIgnoreCase("transfer")) { Text.msg(p, "&cUsage: /ages owner transfer <member> [confirm]   (owner = technical ownership; the leader is separate)"); return; }
        UUID u = memberByName(t, a[2]);
        if (u == null) { Text.msg(p, "&cNot a member."); return; }
        if (a.length < 4 || !a[3].equalsIgnoreCase("confirm")) {
            pendingTransfer.put(p.getUniqueId(), System.currentTimeMillis());
            Text.msg(p, "&eThis hands disband and ownership rights to " + a[2] + ". Run &f/ages owner transfer " + a[2] + " confirm &ewithin 30 seconds.");
            return;
        }
        Long at = pendingTransfer.remove(p.getUniqueId());
        if (at == null || System.currentTimeMillis() - at > 30_000) { Text.msg(p, "&cConfirmation expired. Start again."); return; }
        String e = plugin.governance().transferOwnership(p, t, u);
        Text.msg(p, e == null ? "&aOwnership transferred to " + name(u) + "." : "&c" + e);
    }

    private void disband(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null || !need(p, t, Perm.DISBAND)) return;
        if (a.length < 2 || !a[1].equalsIgnoreCase("confirm")) {
            pendingDisband.put(p.getUniqueId(), System.currentTimeMillis());
            Text.msg(p, "&c&lThis permanently removes " + t.name + ": building records, ledger, villagers. Blocks stay.");
            Text.msg(p, "&cType &f/ages disband confirm &cwithin 30 seconds to continue.");
            return;
        }
        Long at = pendingDisband.remove(p.getUniqueId());
        if (at == null || System.currentTimeMillis() - at > 30_000) { Text.msg(p, "&cConfirmation expired. Run /ages disband again."); return; }
        String e = plugin.towns().disbandBy(p, t);
        if (e != null) Text.msg(p, "&c" + e);
    }

    // ------------------------------------------------------------------ roles

    private void rank(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages rank list|create|delete|perm|set"); return; }
        UUID me = p.getUniqueId();
        Rank mine = t.rankOf(me);
        GovernmentDef gov = plugin.reg().government(t.govId);
        String sub = a[1].toLowerCase();
        if (sub.equals("list")) {
            for (Rank r : t.ranks.values().stream().sorted(Comparator.comparingInt((Rank r) -> -r.weight)).toList())
                p.sendMessage(Text.c("  &e" + r.name + " &8(" + r.weight + ") &7" + r.perms.stream().map(Enum::name).collect(Collectors.joining(", "))));
            return;
        }
        if (sub.equals("set")) {
            if (!need(p, t, Perm.APPOINT_OFFICIALS)) return;
            if (a.length < 4) { Text.msg(p, "&cUsage: /ages rank set <player> <role>"); return; }
            UUID u = memberByName(t, a[2]);
            Rank r = t.ranks.get(a[3].toLowerCase());
            if (u == null || r == null) { Text.msg(p, "&cUnknown member or role."); return; }
            if (r.name.equals(gov.leaderRole) || u.equals(t.leader)) { Text.msg(p, "&cThe " + gov.leaderTitle + " is set through leadership rules (/ages leader or /ages vote)."); return; }
            if (t.weightOf(u) >= mine.weight || r.weight >= mine.weight) { Text.msg(p, "&cYou can only manage members and roles below your own."); return; }
            if (mine != null && !mine.canAppoint && r.weight > 40) { Text.msg(p, "&cYour role cannot appoint officers."); return; }
            if (r.maxHolders >= 0) {
                long held = t.members.values().stream().filter(x -> x.equals(r.name)).count();
                if (!r.name.equals(t.members.get(u)) && held >= r.maxHolders) {
                    Text.msg(p, "&cThat role is full (" + r.maxHolders + ")."); return;
                }
            }
            t.members.put(u, r.name);
            plugin.towns().save(t);
            Text.msg(p, "&7" + a[2] + " is now &f" + r.title + "&7.");
            return;
        }
        if (!need(p, t, Perm.MANAGE_RANKS)) return;
        if (!gov.allowCustomRoles && !sub.equals("perm")) { Text.msg(p, "&cYour government does not allow custom roles."); return; }
        switch (sub) {
            case "create" -> {
                if (a.length < 3) { Text.msg(p, "&cUsage: /ages rank create <name> [weight]"); return; }
                String name = a[2].toLowerCase();
                int w = a.length > 3 ? parseInt(a[3], 10) : 10;
                if (t.ranks.containsKey(name)) { Text.msg(p, "&cThat role exists."); return; }
                if (w >= mine.weight) { Text.msg(p, "&cNew roles must be below your own weight (" + mine.weight + ")."); return; }
                t.ranks.put(name, new Rank(name, w));
                plugin.towns().save(t);
                Text.msg(p, "&7Created role &f" + name + "&7. Give it permissions with /ages rank perm.");
            }
            case "delete" -> {
                Rank r = a.length > 2 ? t.ranks.get(a[2].toLowerCase()) : null;
                if (r == null) { Text.msg(p, "&cUnknown role."); return; }
                if (r.weight >= mine.weight) { Text.msg(p, "&cYou can only delete roles below yours."); return; }
                if (t.members.containsValue(r.name)) { Text.msg(p, "&cMembers still hold that role."); return; }
                if (r.name.equals(gov.defaultRole) || r.name.equals(gov.leaderRole)) { Text.msg(p, "&cThat role is required by your government."); return; }
                t.ranks.remove(r.name);
                plugin.towns().save(t);
                Text.msg(p, "&7Deleted role " + r.name + ".");
            }
            case "perm" -> {
                if (a.length < 5) { Text.msg(p, "&cUsage: /ages rank perm <role> <PERMISSION> <true|false>"); return; }
                Rank r = t.ranks.get(a[2].toLowerCase());
                Perm perm = Perm.parse(a[3]);
                if (r == null || perm == null) { Text.msg(p, "&cUnknown role or permission."); return; }
                if (r.weight >= mine.weight) { Text.msg(p, "&cYou can only edit roles below yours."); return; }
                if (perm.ownerOnly && !t.isOwner(me)) { Text.msg(p, "&cOnly the technical owner can grant " + perm + "."); return; }
                if (!perm.ownerOnly && !mine.perms.contains(perm)) { Text.msg(p, "&cYou cannot grant a permission you do not have."); return; }
                if (Boolean.parseBoolean(a[4])) r.perms.add(perm); else r.perms.remove(perm);
                plugin.towns().save(t);
                Text.msg(p, "&7" + perm + " is now " + (r.perms.contains(perm) ? "&aenabled" : "&cdisabled") + " &7for " + r.name + ".");
            }
            default -> Text.msg(p, "&cUnknown role command.");
        }
    }



    private void civilWar(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        // Revolution = internal civil war only
        String err = plugin.diplomacy().startCivilWar(p, t, "revolution");
        Text.msg(p, err == null ? "&cRevolution (civil war) started. Loyalists can &e/ages rebel&c to join the opposition." : "&c" + err);
    }

    private void revoltCmd(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        String err = plugin.diplomacy().startRevolt(p, t);
        Text.msg(p, err == null ? "&cRevolt declared against your overlord." : "&c" + err);
    }

    private void rebel(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        Town parent = plugin.diplomacy().isOpposition(t) ? null : t;
        if (parent == null) { Text.msg(p, "&cYou are already opposition or have no civilization."); return; }
        String err = plugin.diplomacy().joinOpposition(p, parent);
        Text.msg(p, err == null ? "&eYou joined the opposition." : "&c" + err);
    }

    private void breakAlly(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages breakally <civilization>"); return; }
        Town other = plugin.towns().byName(a[1]);
        if (other == null) { Text.msg(p, "&cUnknown civilization."); return; }
        var r = plugin.diplomacy().get(t, other);
        if (r.state != dev.ages.model.Relation.State.ALLIED && r.state != dev.ages.model.Relation.State.ALLIED_DEFENSIVE) {
            Text.msg(p, "&cYou are not allied."); return;
        }
        String err = plugin.diplomacy().setState(p, t, other, dev.ages.model.Relation.State.NEUTRAL, null);
        Text.msg(p, err == null ? "&7Alliance broken." : "&c" + err);
    }

    private void setHostile(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages hostile <civilization>"); return; }
        Town other = plugin.towns().byName(a[1]);
        if (other == null) { Text.msg(p, "&cUnknown civilization."); return; }
        String err = plugin.diplomacy().setState(p, t, other, dev.ages.model.Relation.State.HOSTILE, null);
        Text.msg(p, err == null ? "&cRelations set to Hostile." : "&c" + err);
    }

    private void acceptDiplo(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages accept_diplo <civilization>"); return; }
        Town other = plugin.towns().byName(a[1]);
        if (other == null) { Text.msg(p, "&cUnknown civilization."); return; }
        String err = plugin.diplomacy().acceptProposal(p, t, other);
        Text.msg(p, err == null ? "&aProposal accepted." : "&c" + err);
    }

    private boolean adminPerm(CommandSender s) {
        if (s.hasPermission("ages.admin")) return true;
        Text.msg(s, "&cNo permission. (ages.admin)");
        return false;
    }

    private Town adminTown(CommandSender s, String[] a, int idx) {
        if (a.length <= idx) { Text.msg(s, "&cSpecify a civilization name."); return null; }
        // join remaining tokens for multi-word names when last arg is the name
        Town t = plugin.towns().byName(a[idx]);
        if (t == null && a.length > idx + 1) {
            t = plugin.towns().byName(String.join(" ", java.util.Arrays.copyOfRange(a, idx, a.length)));
        }
        if (t == null) Text.msg(s, "&cUnknown civilization '" + a[idx] + "'.");
        return t;
    }

    private void admin(CommandSender s, String[] a) {
        if (!adminPerm(s)) return;
        if (a.length < 2) {
            Text.msg(s, "&6Ages admin:");
            Text.msg(s, "&e/ages admin list");
            Text.msg(s, "&e/ages admin info <civ>");
            Text.msg(s, "&e/ages admin points <civ> <amount> &8(can be negative)");
            Text.msg(s, "&e/ages admin money <civ> <amount> &8(can be negative)");
            Text.msg(s, "&e/ages admin setpoints <civ> <amount> &8(absolute)");
            Text.msg(s, "&e/ages admin setmoney <civ> <amount> &8(absolute)");
            Text.msg(s, "&e/ages admin gov <civ> <governmentId>");
            Text.msg(s, "&e/ages admin econ <civ> <economyId>");
            Text.msg(s, "&e/ages admin age <civ> <ageId>");
            Text.msg(s, "&e/ages admin leader <civ> <player>");
            Text.msg(s, "&e/ages admin owner <civ> <player>");
            Text.msg(s, "&e/ages admin disband <civ> confirm");
            Text.msg(s, "&e/ages admin repair <civ> &8(clear disabled on all buildings)");
            Text.msg(s, "&e/ages admin tp <civ> [player] &8(core location)");
            Text.msg(s, "&e/ages admin election <civ> open|close|status");
            Text.msg(s, "&e/ages admin relation <civA> <civB> <state> [goal]");
            Text.msg(s, "&e/ages admin warscore <civA> <civB> <0-1000>");
            Text.msg(s, "&e/ages admin endwar <civA> <civB>");
            Text.msg(s, "&e/ages admin tribute <overlord> <subject> <rate|clear>");
            Text.msg(s, "&e/ages admin warlog [n]");
            return;
        }
        String sub = a[1].toLowerCase();
        switch (sub) {
            case "list" -> {
                var all = plugin.towns().all();
                if (all.isEmpty()) { Text.msg(s, "&7No civilizations."); return; }
                Text.msg(s, "&6Civilizations &7(" + all.size() + "):");
                for (Town t : all) {
                    Text.msg(s, "&e" + t.name + " &8- &7" + t.ageId + " · " + t.members.size() + " members · "
                            + Text.num(t.points) + " RP · " + Text.num(t.money) + " coin");
                }
            }
            case "info" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                Text.msg(s, "&6" + t.name + " &8(" + t.id + ")");
                Text.msg(s, "&7Age: &f" + t.ageId + " &7Gov: &f" + t.govId + " &7Econ: &f" + t.econId);
                Text.msg(s, "&7Points: &f" + Text.num(t.points) + " &7Money: &f" + Text.num(t.money));
                Text.msg(s, "&7Members: &f" + t.members.size() + " &7Buildings: &f" + t.buildings.size());
                Text.msg(s, "&7Leader: &f" + nameOf(t.leader) + " &7Owner: &f" + nameOf(t.owner));
                Text.msg(s, "&7Core: &f" + t.core.world() + " " + t.core.x() + "," + t.core.y() + "," + t.core.z());
            }
            case "points", "rp", "addpoints" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin points <civ> <amount>"); return; }
                double amt = parseDouble(a[3], Double.NaN);
                if (Double.isNaN(amt)) { Text.msg(s, "&cInvalid amount."); return; }
                t.points = Math.max(0, t.points + amt);
                plugin.finance().record(t, null, "ADMIN", "POINTS", amt, "Admin " + s.getName());
                plugin.towns().save(t);
                Text.msg(s, "&a" + t.name + " points now &f" + Text.num(t.points) + " &7(" + (amt >= 0 ? "+" : "") + Text.num(amt) + ")");
            }
            case "money", "addmoney" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin money <civ> <amount>"); return; }
                double amt = parseDouble(a[3], Double.NaN);
                if (Double.isNaN(amt)) { Text.msg(s, "&cInvalid amount."); return; }
                t.money = Math.max(0, t.money + amt);
                plugin.finance().record(t, null, "ADMIN", "MONEY", amt, "Admin " + s.getName());
                plugin.towns().save(t);
                Text.msg(s, "&a" + t.name + " treasury now &f" + Text.num(t.money) + " &7(" + (amt >= 0 ? "+" : "") + Text.num(amt) + ")");
            }
            case "setpoints" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin setpoints <civ> <amount>"); return; }
                double amt = parseDouble(a[3], Double.NaN);
                if (Double.isNaN(amt) || amt < 0) { Text.msg(s, "&cInvalid amount."); return; }
                double delta = amt - t.points;
                t.points = amt;
                plugin.finance().record(t, null, "ADMIN", "POINTS", delta, "Admin set by " + s.getName());
                plugin.towns().save(t);
                Text.msg(s, "&a" + t.name + " points set to &f" + Text.num(t.points));
            }
            case "setmoney" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin setmoney <civ> <amount>"); return; }
                double amt = parseDouble(a[3], Double.NaN);
                if (Double.isNaN(amt) || amt < 0) { Text.msg(s, "&cInvalid amount."); return; }
                double delta = amt - t.money;
                t.money = amt;
                plugin.finance().record(t, null, "ADMIN", "MONEY", delta, "Admin set by " + s.getName());
                plugin.towns().save(t);
                Text.msg(s, "&a" + t.name + " treasury set to &f" + Text.num(t.money));
            }
            case "gov", "government" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin gov <civ> <governmentId>"); return; }
                var g = plugin.reg().government(a[3].toLowerCase());
                if (g == null || !plugin.reg().governments.containsKey(g.id)) {
                    Text.msg(s, "&cUnknown government. Options: " + String.join(", ", plugin.reg().governments.keySet()));
                    return;
                }
                plugin.governance().applyGovernment(t, g);
                t.govId = g.id;
                t.govChangedAt = 0;
                plugin.towns().save(t);
                Text.msg(s, "&a" + t.name + " government set to &f" + Text.plain(g.name));
            }
            case "econ", "economy" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin econ <civ> <economyId>"); return; }
                var e = plugin.reg().economy(a[3].toLowerCase());
                if (e == null || !plugin.reg().economies.containsKey(e.id)) {
                    Text.msg(s, "&cUnknown economy. Options: " + String.join(", ", plugin.reg().economies.keySet()));
                    return;
                }
                t.econId = e.id;
                t.econChangedAt = 0;
                plugin.towns().save(t);
                Text.msg(s, "&a" + t.name + " economy set to &f" + Text.plain(e.name));
            }
            case "age" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin age <civ> <ageId>"); return; }
                var age = plugin.reg().age(a[3].toLowerCase());
                if (age == null) {
                    Text.msg(s, "&cUnknown age. Options: " + String.join(", ", plugin.reg().ages.keySet()));
                    return;
                }
                t.ageId = age.id;
                plugin.towns().recomputeClaims(t);
                plugin.towns().save(t);
                Text.msg(s, "&a" + t.name + " age set to &f" + Text.plain(age.name));
            }
            case "leader" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin leader <civ> <player>"); return; }
                UUID u = memberByName(t, a[3]);
                if (u == null) {
                    var op = Bukkit.getOfflinePlayer(a[3]);
                    u = op.getUniqueId();
                    if (!t.members.containsKey(u)) { Text.msg(s, "&cThat player is not a member of " + t.name + "."); return; }
                }
                plugin.governance().setLeader(t, u);
                Text.msg(s, "&a" + t.name + " leader set to &f" + nameOf(u));
            }
            case "owner" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin owner <civ> <player>"); return; }
                UUID u = memberByName(t, a[3]);
                if (u == null) {
                    var op = Bukkit.getOfflinePlayer(a[3]);
                    u = op.getUniqueId();
                    if (!t.members.containsKey(u)) { Text.msg(s, "&cThat player is not a member of " + t.name + "."); return; }
                }
                t.owner = u;
                plugin.towns().save(t);
                Text.msg(s, "&a" + t.name + " technical owner set to &f" + nameOf(u));
            }
            case "disband" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4 || !a[a.length - 1].equalsIgnoreCase("confirm")) {
                    Text.msg(s, "&cThis cannot be undone. Run: &e/ages admin disband " + t.name + " confirm");
                    return;
                }
                String name = t.name;
                java.util.List<UUID> members = new java.util.ArrayList<>(t.members.keySet());
                if (plugin.dynmap() != null) plugin.dynmap().remove(t);
                if (plugin.townDump() != null) plugin.townDump().delete(t);
                plugin.towns().disband(t);
                for (UUID u : members) {
                    Player m = Bukkit.getPlayer(u);
                    if (m != null) Text.msg(m, "&6" + name + " was force-disbanded by an admin.");
                }
                Text.msg(s, "&aDisbanded &f" + name + "&a.");
                plugin.getLogger().info(s.getName() + " force-disbanded civilization '" + name + "'");
            }
            case "repair" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                int n = 0;
                for (var b : t.buildings) {
                    if (b.damaged) {
                        b.damaged = false;
                        plugin.db().saveBuilding(b);
                        n++;
                    }
                }
                plugin.towns().recomputeClaims(t);
                plugin.towns().save(t);
                Text.msg(s, "&aRepaired &f" + n + " &abuilding(s) in " + t.name + ".");
            }
            case "relation" -> {
                if (a.length < 5) { Text.msg(s, "&cUsage: /ages admin relation <civA> <civB> <state> [goal]"); return; }
                Town aT = plugin.towns().byName(a[2]);
                Town bT = plugin.towns().byName(a[3]);
                if (aT == null || bT == null) { Text.msg(s, "&cUnknown civilization."); return; }
                String stateName = a[4].toUpperCase().replace("-", "_");
                if (stateName.equals("ALLIED_DEFENSIVE") || stateName.equals("DEFENSIVE")) stateName = "ALLIED_DEFENSIVE";
                dev.ages.model.Relation.State st;
                try { st = dev.ages.model.Relation.State.valueOf(stateName); }
                catch (Exception ex) { Text.msg(s, "&cStates: NEUTRAL HOSTILE ALLIED ALLIED_DEFENSIVE WAR TRUCE TRIBUTARY SETTLEMENT"); return; }
                String goal = a.length > 5 ? a[5] : null;
                String err = plugin.diplomacy().adminSetRelation(aT, bT, st, goal, s.getName());
                Text.msg(s, err == null ? "&aRelation set." : "&c" + err);
            }
            case "warscore" -> {
                if (a.length < 5) { Text.msg(s, "&cUsage: /ages admin warscore <civA> <civB> <0-1000>"); return; }
                Town aT = plugin.towns().byName(a[2]);
                Town bT = plugin.towns().byName(a[3]);
                if (aT == null || bT == null) { Text.msg(s, "&cUnknown civilization."); return; }
                int score = parseInt(a[4], -1);
                if (score < 0 || score > 1000) { Text.msg(s, "&cScore must be 0-1000."); return; }
                String err = plugin.diplomacy().adminSetWarScore(aT, bT, score, s.getName());
                Text.msg(s, err == null ? "&aWar score set to " + score + "." : "&c" + err);
            }
            case "endwar" -> {
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin endwar <civA> <civB>"); return; }
                Town aT = plugin.towns().byName(a[2]);
                Town bT = plugin.towns().byName(a[3]);
                if (aT == null || bT == null) { Text.msg(s, "&cUnknown civilization."); return; }
                String err = plugin.diplomacy().adminEndWar(aT, bT, s.getName());
                Text.msg(s, err == null ? "&aWar ended as truce." : "&c" + err);
            }
            case "tribute" -> {
                if (a.length < 5) { Text.msg(s, "&cUsage: /ages admin tribute <overlord> <subject> <rate|clear>"); return; }
                Town ov = plugin.towns().byName(a[2]);
                Town subject = plugin.towns().byName(a[3]);
                if (ov == null || subject == null) { Text.msg(s, "&cUnknown civilization."); return; }
                double rate = a[4].equalsIgnoreCase("clear") ? 0 : parseDouble(a[4], -1);
                if (rate < 0) { Text.msg(s, "&cRate 0.05-0.5 or clear."); return; }
                if (rate > 0 && rate < 0.05) rate = 0.05;
                if (rate > 0.5) rate = 0.5;
                String err = plugin.diplomacy().adminTribute(ov, subject, rate, s.getName());
                Text.msg(s, err == null ? "&aTribute updated." : "&c" + err);
            }
            case "warlog" -> {
                int n = a.length > 2 ? parseInt(a[2], 15) : 15;
                var lines = plugin.diplomacy().recentWarLog(n);
                if (lines.isEmpty()) { Text.msg(s, "&7War log empty."); return; }
                Text.msg(s, "&6War log (newest first):");
                for (String line : lines) Text.msg(s, "&8" + line);
            }
            case "election" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                if (a.length < 4) { Text.msg(s, "&cUsage: /ages admin election <civ> open|close|status"); return; }
                String op = a[3].toLowerCase();
                if (op.equals("open")) {
                    if (!plugin.governance().isElected(t)) { Text.msg(s, "&cGovernment is not elected."); return; }
                    plugin.governance().openElection(t);
                    Text.msg(s, "&aElection opened for " + t.name);
                } else if (op.equals("close")) {
                    plugin.governance().closeElection(t);
                    Text.msg(s, "&aElection closed/tallied for " + t.name);
                } else {
                    Text.msg(s, "&7Open until: &f" + t.electionEndsAt + " &7Next open: &f" + t.nextElectionAt
                            + " &7Votes: &f" + t.votes.size());
                }
            }
            case "tp", "teleport" -> {
                Town t = adminTown(s, a, 2);
                if (t == null) return;
                Player target = s instanceof Player p0 ? p0 : null;
                if (a.length >= 4) {
                    target = Bukkit.getPlayerExact(a[3]);
                    if (target == null) { Text.msg(s, "&cPlayer not online."); return; }
                }
                if (target == null) { Text.msg(s, "&cConsole must specify a player: /ages admin tp <civ> <player>"); return; }
                var w = Bukkit.getWorld(t.core.world());
                if (w == null) { Text.msg(s, "&cWorld not loaded."); return; }
                target.teleport(new org.bukkit.Location(w, t.core.x() + 0.5, t.core.y() + 1, t.core.z() + 0.5));
                Text.msg(s, "&aTeleported to " + t.name + " core.");
            }
            default -> Text.msg(s, "&cUnknown admin subcommand. Try /ages admin");
        }
    }

    private static String nameOf(UUID u) {
        if (u == null) return "?";
        var op = Bukkit.getOfflinePlayer(u);
        return op.getName() != null ? op.getName() : u.toString().substring(0, 8);
    }

    private static double parseDouble(String s, double def) {
        try { return Double.parseDouble(s); } catch (Exception e) { return def; }
    }

    private static int parseInt(String s, int def) {
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return def; }
    }


    private void diplomacy(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (!plugin.reg().settings.diplomacyEnabled) { Text.msg(p, "&cDiplomacy is disabled."); return; }
        var list = plugin.diplomacy().of(t);
        if (list.isEmpty()) { Text.msg(p, "&7No special relations. Everyone else is neutral."); return; }
        Text.msg(p, "&6Relations for " + t.name + ":");
        for (var r : list) {
            Town other = plugin.towns().byId(r.other(t.id));
            String name = other != null ? other.name : r.other(t.id).toString().substring(0, 8);
            Text.msg(p, "&e" + name + " &8- &f" + r.state + (r.state.name().equals("WAR") ? " &7goal=" + r.warGoal + " score=" + r.warScore : ""));
        }
    }

    private void war(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 3) { Text.msg(p, "&cUsage: /ages war <civilization> <goal>"); Text.msg(p, "&7Goals: none, tributary, conquest, total_war, political, raid"); Text.msg(p, "&7Revolt = /ages revolt (tributary). Revolution = /ages civilwar (internal)."); return; }
        Town other = plugin.towns().byName(a[1]);
        if (other == null) { Text.msg(p, "&cUnknown civilization."); return; }
        String err = plugin.diplomacy().declareWar(p, t, other, a[2].toLowerCase());
        Text.msg(p, err == null ? "&cWar declared on " + other.name + " (" + a[2] + ")." : "&c" + err);
    }

    private void ally(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages ally <civilization> [defensive]"); return; }
        Town other = plugin.towns().byName(a[1]);
        if (other == null) { Text.msg(p, "&cUnknown civilization."); return; }
        boolean def = a.length > 2 && a[2].toLowerCase().startsWith("def");
        String err = plugin.diplomacy().proposeAlliance(p, t, other, def);
        Text.msg(p, err == null ? "&aAlliance proposed to " + other.name + "." : "&c" + err);
    }


    private void truce(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages truce <civilization> [hours]"); return; }
        Town other = plugin.towns().byName(a[1]);
        if (other == null) { Text.msg(p, "&cUnknown civilization."); return; }
        Integer hours = a.length > 2 ? parseInt(a[2], plugin.reg().settings.truceMinHours) : null;
        String err = plugin.diplomacy().offerTruce(p, t, other, hours);
        Text.msg(p, err == null ? "&aTruce proposed." : "&c" + err);
    }

    private void tributary(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages tributary <civilization>"); return; }
        Town other = plugin.towns().byName(a[1]);
        if (other == null) { Text.msg(p, "&cUnknown civilization."); return; }
        String err = plugin.diplomacy().demandTributary(p, t, other);
        Text.msg(p, err == null ? "&6Tributary enforced." : "&c" + err);
    }

    private void release(CommandSender s, String[] a) {
        Player p = player(s);
        if (p == null) return;
        Town t = townOf(p);
        if (t == null) return;
        if (a.length < 2) { Text.msg(p, "&cUsage: /ages release <civilization>"); return; }
        Town other = plugin.towns().byName(a[1]);
        if (other == null) { Text.msg(p, "&cUnknown civilization."); return; }
        String err = plugin.diplomacy().releaseTributary(p, t, other);
        Text.msg(p, err == null ? "&aReleased." : "&c" + err);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        Registries reg = plugin.reg();
        if (a.length == 1) out.addAll(List.of("menu", "help", "info", "buildings", "logistics", "treasury", "invite", "accept", "leave", "kick", "rank", "contribute",
                "withdraw", "convert", "government", "economy", "policy", "vote", "leader", "owner", "disband", "core", "fireplace", "give", "diplomacy", "war", "ally", "truce", "tributary", "release", "admin", "reload"));
        else if (a.length == 2) {
            switch (a[0].toLowerCase()) {
                case "give" -> out.addAll(reg.buildings.keySet());
                case "admin" -> out.addAll(List.of("list", "info", "points", "money", "setpoints", "setmoney", "gov", "econ", "age", "leader", "owner", "disband", "repair", "tp", "relation", "warscore", "endwar", "tribute", "warlog", "election"));
                case "rank", "role" -> out.addAll(List.of("list", "create", "delete", "perm", "set"));
                case "contribute" -> out.addAll(List.of("hand", "all", "money"));
                case "government", "gov", "economy", "econ" -> out.addAll(List.of("list", "set"));
                case "policy" -> out.addAll(reg.policies.keySet());
                case "owner" -> out.add("transfer");
                default -> { }
            }
        } else if (a.length == 3) {
            switch (a[0].toLowerCase()) {
                case "government", "gov" -> out.addAll(reg.governments.keySet());
                case "economy", "econ" -> out.addAll(reg.economies.keySet());
                case "admin" -> {
                    String sub = a[1].toLowerCase();
                    if (List.of("info", "points", "money", "setpoints", "setmoney", "gov", "econ", "age", "leader", "owner", "disband", "repair", "tp").contains(sub)) {
                        for (Town t : plugin.towns().all()) out.add(t.name);
                    }
                }
                default -> { }
            }
        } else if (a.length == 4 && a[0].equalsIgnoreCase("admin")) {
            switch (a[1].toLowerCase()) {
                case "gov" -> out.addAll(reg.governments.keySet());
                case "econ" -> out.addAll(reg.economies.keySet());
                case "age" -> out.addAll(reg.ages.keySet());
                case "disband" -> out.add("confirm");
                default -> { }
            }
        } else if (a.length == 4 && a[0].equalsIgnoreCase("rank") && a[1].equalsIgnoreCase("perm")) {
            for (Perm p : Perm.values()) out.add(p.name());
        } else if (a.length == 5 && a[1].equalsIgnoreCase("perm")) out.addAll(List.of("true", "false"));
        String last = a[a.length - 1].toLowerCase();
        return out.stream().filter(x -> x.toLowerCase().startsWith(last)).sorted().collect(Collectors.toList());
    }
}
