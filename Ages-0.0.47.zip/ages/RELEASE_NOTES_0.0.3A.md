# 0.0.3A release notes

See **[CHANGELOG.md](CHANGELOG.md)** (section 0.0.3A) and **[README.md](README.md)** for install, commands, and permissions.

### Quick tester checklist
1. Found with fireplace → advance toward Tribal
2. Creative vs survival catalogue (`deny_creative_purchase`)
3. Elected gov → election window → `/ages vote`
4. Diplomacy GUI: ally proposal, hostile, war, cannon shot (ammo in core)
5. `/ages admin` points / relation / endwar
6. Revolt only as tributary; revolution only as internal civil war
