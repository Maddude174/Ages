# Changelog

## 0.0.3A

### Governments & elections
- Role trees: inherits, bundles, grant/deny, max_holders, can_appoint, authority tags
- Elected governments: cycle + voting window (`governance.election_cycle_days` / `election_voting_days`); tally on close
- `/ages admin election <civ> open|close|status`

### Diplomacy & war
- Relations: Neutral, Hostile, Allied, Allied (Defensive), War, Truce, Tributary, Settlement
- War goals, war score (0–1000), kills/building disables, tributary skim
- Proposals for alliance/truce (`/ages accept_diplo`)
- **Revolution** = internal civil war (shadow opposition town, `/ages civilwar`, `/ages rebel`)
- **Revolt** = tributary/settlement breakaway (`/ages revolt`)
- Admin: relation, warscore, endwar (truce), tribute, warlog
- Diplomacy GUI covers ally, hostile, truce, war, revolt, revolution

### Siege
- Cannons fire propelled TNT; prefer operational targets, allow disabled; slight miss
- Ammo: 3 gunpowder + 1 cobblestone from core inventory
- Long cooldown; siege pressure on defender RP + war score
- Vanilla TNT: peacetime respects settings; Hostile/War can take damage; `tnt_requires_online`

### Buildings & economy
- Building conflicts field (example YAML); `buildings.conflict_scope: town|player`
- Creative buy/place block + `ages.creative.bypass`
- Disabled / Destroyed states; repair costs × `repair_cost_mult`
- Item groups (`groups.yml`); policy effect catalog (`policies/_effects.yml`)
- War repair policies: scorched_earth, sappers_corps, war_taxes

### Admin
- `/ages admin` list, info, points/money, gov/econ/age, leader/owner, disband, repair, tp, election, diplomacy tools

### Compatibility
- No NMS; material/entity resolution with aliases; optional `materials-aliases.yml`
- See `COMPATIBILITY.md`

---

## 0.0.2A

- Age requirements: list + `any_of` / `all_of`
- Neolithic age; fireplace founding → Tribal (chief’s hut) → Village…
- Buildings load recursively from category folders
- Unified progressive mine; removed per-ore mine defs (aliases kept)
- Recipe locks: `require_age`, `require_level`
- Town dumps: `plugins/Ages/Towns/` one YAML per civ
- WorldGuard: clear core block only when plugin removes core
- Dynmap borders/markers; PlaceholderAPI expansion
- Config fixes: chiefs_hut alias, woodcutter recipes, age costs

---

## 0.0.1A

- Initial alpha: ages, buildings, production, governments/economies scaffolding, Vault soft-depend
