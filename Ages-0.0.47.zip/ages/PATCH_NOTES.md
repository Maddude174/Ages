# Patch notes

All version history lives in **[CHANGELOG.md](CHANGELOG.md)**.

This file is kept so older links still resolve.
